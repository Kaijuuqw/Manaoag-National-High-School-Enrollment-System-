

## Goal
Hide the admin login behind a secret, unguessable URL and remove every admin-facing link from the student site.

## Changes

### 1. Move admin login to a secret URL
In `src/App.tsx`:
- Remove route `/admin/login` (and any link to it)
- Add new route `/portal-mnhs-staff-9k2x7q` → `<AdminLogin />`
- Keep `/admin/dashboard` (still needed after login, but no public link points to it)

Suggested secret path: `/portal-mnhs-staff-9k2x7q` (you can pick a different string — just tell me).

### 2. Remove admin entry points from the student site
- **`src/pages/LoginSelection.tsx`** — Remove the "Admin Login" card entirely. Page becomes a single centered "Student Login" card (or we redirect `/login` straight to `/student/login`).
- **`src/components/auth/AdminLogin.tsx`** — Update the "Back to Home" link target if needed; remove any text that exposes the admin path.
- **Search & remove** any other `navigate('/admin/login')` or `<Link to="/admin/login">` references across the codebase.

### 3. Update post-logout redirect
- When an admin logs out, redirect to `/` (home) — NOT back to the secret URL, so the path stays hidden.
- Admins must bookmark or remember the secret URL to log in again.

### 4. Block accidental discovery
- Add a catch route: visiting old `/admin/login` shows the 404 page (handled automatically by the existing `*` route once we remove the entry).

## What stays the same
- `admin_users` table, authentication logic, admin dashboard — all unchanged.
- Both existing admins (`admin`, `admin.admin`) continue using the same shared login form, just at the new URL.

## Files affected
- `src/App.tsx` (route change)
- `src/pages/LoginSelection.tsx` (remove admin card)
- `src/components/auth/AdminLogin.tsx` (minor cleanup, post-logout target)
- Any other file linking to `/admin/login` (will grep and update)

## Important caveats
- This is **security through obscurity** — anyone who learns the URL can attempt to log in. The real protection remains the admin password + Supabase RLS.
- Save the secret URL somewhere safe. If you forget it, you'll need to ask me to look it up in the code.
- The URL will appear in browser history and any analytics — share it only with admins.

