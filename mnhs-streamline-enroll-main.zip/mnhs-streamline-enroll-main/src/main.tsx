import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'

const clearServiceWorkersAndCaches = async () => {
  const registrations = await navigator.serviceWorker?.getRegistrations();
  await Promise.all((registrations ?? []).map((registration) => registration.unregister()));

  if ('caches' in window) {
    const cacheKeys = await caches.keys();
    await Promise.all(cacheKeys.map((key) => caches.delete(key)));
  }
};

void clearServiceWorkersAndCaches().finally(() => {
  createRoot(document.getElementById('root')!).render(<App />);
});
