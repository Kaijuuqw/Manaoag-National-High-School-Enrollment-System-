import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Header } from '@/components/layout/Header';
import { saveStudent, checkLRNExists, setCurrentUser } from '@/lib/supabase-storage';
import { EnrollmentFormData, Student, STRANDS } from '@/types/enrollment';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

export const StudentRegistration = () => {
  // Test if JavaScript is working
  console.log('🎯 StudentRegistration component loaded - JavaScript is working!');
  console.log('🎯 Current URL:', window.location.href);
  console.log('🎯 Current timestamp:', new Date().toISOString());
  console.log('🎯 User Agent:', navigator.userAgent);
  console.log('🎯 Screen size:', window.screen.width + 'x' + window.screen.height);
  console.log('🎯 Viewport size:', window.innerWidth + 'x' + window.innerHeight);
  console.log('🎯 Touch support:', 'ontouchstart' in window);
  
  const [formData, setFormData] = useState<EnrollmentFormData>({
    lastName: '',
    firstName: '',
    middleName: '',
    lrn: '',
    dateOfBirth: '',
    placeOfBirth: '',
    zone: '',
    street: '',
    barangay: '',
    city: '',
    province: '',
    gender: 'Male',
        gradeLevel: '',
        previousSection: '',
        previousAdviser: '',
        generalAverage: '',
        mothersMaidenName: '',
    fatherName: '',
    contactNumber: '',
        religion: '',
        is4ps: false,
        isBalikAral: false,
        isTransferStudent: false,
        transferSchool: '',
        transferGrade: '',
        transferSection: '',
        transferAdviser: '',
        transferAverage: '',
    fourPsStudentName: '',
    fourPsParentName: '',
    fourPsIdNumber: '',
    fourPsContactNumber: '',
    selectedStrand: '',
    email: '',
    password: '',
    confirmPassword: '',
    birthCertificate: '',
    reportCard: '',
    reportCardFront: '',
    reportCardBack: '',
    birthCertificateName: '',
    reportCardName: '',
    reportCardFrontName: '',
    reportCardBackName: '',
    certificateOfCompletion: '',
    certificateOfCompletionName: ''
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleInputChange = (field: keyof EnrollmentFormData, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleFileChange = async (field: 'birthCertificate' | 'reportCard' | 'certificateOfCompletion', file: File | null) => {
    if (!file) return;
    
    try {
      // Upload file to Supabase Storage
      const fileName = `${Date.now()}_${file.name}`;
      const { data, error } = await supabase.storage
        .from('student-documents')
        .upload(fileName, file);

      if (error) {
        console.error('File upload error:', error);
        toast({
          title: "Upload Error",
          description: "Failed to upload file. Please try again.",
          variant: "destructive",
        });
        return;
      }

      // Get public URL for the uploaded file
      const { data: { publicUrl } } = supabase.storage
        .from('student-documents')
        .getPublicUrl(fileName);

      // Update form data with the storage path and file name
      setFormData(prev => ({ 
        ...prev, 
        [field]: fileName, // Store the storage path
        [`${field}Name`]: file.name // Store original filename
      }));

      toast({
        title: "File Uploaded",
        description: `${file.name} uploaded successfully.`,
      });
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Upload Error",
        description: "Failed to upload file. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log('🚀 FORM SUBMIT BUTTON CLICKED!');
    console.log('Event:', e);
    console.log('Loading state:', isLoading);
    
    setIsLoading(true);
    console.log('=== ENROLLMENT FORM SUBMISSION STARTED ===');
    console.log('Form data before processing:', JSON.stringify(formData, null, 2));

    try {
      // Comprehensive validation
      const requiredFields = [
        'lastName', 'firstName', 'lrn', 'dateOfBirth', 'placeOfBirth',
        'barangay', 'city', 'province', 'gradeLevel', 'previousSection',
        'mothersMaidenName', 'fatherName', 'contactNumber', 'religion', 'password'
      ];

      console.log('Starting field validation...');
      for (const field of requiredFields) {
        const value = formData[field as keyof EnrollmentFormData];
        console.log(`Checking field ${field}:`, value);
        if (!value || (typeof value === 'string' && value.trim() === '')) {
          console.error(`❌ Missing required field: ${field}`);
          toast({
            title: "Missing required field",
            description: `Please fill in the ${field.replace(/([A-Z])/g, ' $1').toLowerCase()} field`,
            variant: "destructive",
          });
          setIsLoading(false);
          return;
        }
      }
      console.log('✅ All required fields validated successfully');

      if (formData.password !== formData.confirmPassword) {
        console.error('❌ Password mismatch');
        toast({
          title: "Password mismatch",
          description: "Passwords do not match",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      if (formData.password.length < 6) {
        console.error('❌ Password too short');
        toast({
          title: "Password too short",
          description: "Password must be at least 6 characters long",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      console.log('Checking if LRN exists:', formData.lrn);
      const lrnExists = await checkLRNExists(formData.lrn);
      console.log('LRN exists check result:', lrnExists);
      if (lrnExists) {
        console.error('❌ LRN already exists:', formData.lrn);
        toast({
          title: "LRN already exists",
          description: "This LRN is already registered",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      if (!formData.selectedStrand) {
        console.error('❌ Missing strand selection');
        toast({
          title: "Missing strand selection",
          description: "Please select your preferred strand",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      // Check COC requirement for Grade 11 students
      if (formData.gradeLevel && formData.gradeLevel.includes('11')) {
        if (!formData.certificateOfCompletion || !formData.certificateOfCompletionName) {
          console.error('❌ Missing Certificate of Completion for Grade 11 student');
          toast({
            title: "Missing Certificate of Completion",
            description: "Certificate of Completion (COC) is required for incoming Grade 11 students",
            variant: "destructive",
          });
          setIsLoading(false);
          return;
        }
      }

      console.log('✅ All validations passed, creating student object...');

      // Convert date format from MM/DD/YYYY to YYYY-MM-DD for database
      let formattedDate = formData.dateOfBirth;
      if (formData.dateOfBirth.includes('/')) {
        const [month, day, year] = formData.dateOfBirth.split('/');
        formattedDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
        console.log('Converted date from', formData.dateOfBirth, 'to', formattedDate);
      }

      // Map strand names to database values
      const strandMapping: { [key: string]: string } = {
        'TVL - ICT': 'ICT',
        'TVL - EPAS': 'EPAS',
        'TVL - COOKERY': 'COOKERY',
        'TVL - BPP': 'BPP',
        'ABM': 'ABM',
        'STEM': 'STEM',
        'HUMSS': 'HUMSS',
        'ALS': 'ALS'
      };
      
      const mappedStrand = strandMapping[formData.selectedStrand] || formData.selectedStrand;
      console.log('Mapped strand from', formData.selectedStrand, 'to', mappedStrand);

      // Ensure all fields have proper values (let database auto-generate UUID)
      const student: Student = {
        lastName: formData.lastName,
        firstName: formData.firstName,
        middleName: formData.middleName || '',
        lrn: formData.lrn,
        dateOfBirth: formattedDate,
        placeOfBirth: formData.placeOfBirth,
        zone: formData.zone || '',
        street: formData.street || '',
        barangay: formData.barangay,
        city: formData.city,
        province: formData.province,
        gender: formData.gender,
        gradeLevel: formData.gradeLevel,
        previousSection: formData.previousSection,
        previousAdviser: formData.previousAdviser || '',
        generalAverage: formData.generalAverage ? parseFloat(formData.generalAverage) : undefined,
        mothersMaidenName: formData.mothersMaidenName,
        fatherName: formData.fatherName,
        contactNumber: formData.contactNumber,
        religion: formData.religion,
        is4ps: formData.is4ps,
        isBalikAral: formData.isBalikAral || false,
        isTransferStudent: formData.isTransferStudent || false,
        transferSchool: formData.transferSchool || '',
        transferGrade: formData.transferGrade || '',
        transferSection: formData.transferSection || '',
        transferAdviser: formData.transferAdviser || '',
        transferAverage: formData.transferAverage ? parseFloat(formData.transferAverage) : undefined,
        fourPsStudentName: formData.is4ps ? (formData.fourPsStudentName || '') : '',
        fourPsParentName: formData.is4ps ? (formData.fourPsParentName || '') : '',
        fourPsIdNumber: formData.is4ps ? (formData.fourPsIdNumber || '') : '',
        fourPsContactNumber: formData.is4ps ? (formData.fourPsContactNumber || '') : '',
        selectedStrand: mappedStrand,
        enrollmentStatus: 'Pending',
        enrollmentDate: new Date().toISOString(),
        email: formData.email,
        password: formData.password,
        birthCertificate: formData.birthCertificate || '',
        reportCard: formData.reportCard || '',
        reportCardFront: '',
        reportCardBack: '',
        birthCertificateName: formData.birthCertificateName || '',
        reportCardName: formData.reportCardName || '',
        reportCardFrontName: '',
        reportCardBackName: '',
        certificateOfCompletion: formData.certificateOfCompletion || '',
        certificateOfCompletionName: formData.certificateOfCompletionName || ''
      };

      console.log('Final student object before save:', JSON.stringify(student, null, 2));
      console.log('About to save student to database...');
      
      try {
        await saveStudent(student);
        console.log('✅ Student saved successfully to database');
      } catch (saveError) {
        console.error('❌ Database save error:', saveError);
        console.error('Error details:', {
          name: saveError instanceof Error ? saveError.name : 'Unknown',
          message: saveError instanceof Error ? saveError.message : String(saveError),
          stack: saveError instanceof Error ? saveError.stack : undefined
        });
        throw new Error(`Database save failed: ${saveError instanceof Error ? saveError.message : 'Unknown database error'}`);
      }
      
      console.log('Setting current user session...');
      try {
        await setCurrentUser(student, 'student');
        console.log('✅ User session set successfully');
      } catch (sessionError) {
        console.error('⚠️ Session error (non-critical):', sessionError);
        // Don't throw here, registration still succeeded
      }
      
      toast({
        title: "Registration successful!",
        description: "Please check your email for a confirmation link to complete your registration.",
      });
      
      console.log('Redirecting to homepage...');
      navigate('/');
      
    } catch (error) {
      console.error('❌ ENROLLMENT SUBMISSION FAILED:', error);
      console.error('Error type:', typeof error);
      console.error('Error details:', {
        name: error instanceof Error ? error.name : 'Unknown',
        message: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : undefined
      });
      
      toast({
        title: "Registration failed",
        description: `An error occurred during registration: ${error instanceof Error ? error.message : 'Unknown error'}. Please try again.`,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
      console.log('=== ENROLLMENT FORM SUBMISSION ENDED ===');
    }
  };

  return (
    <div className="min-h-screen school-bg">
      <Header title="Student Registration Form" subtitle="New Student Enrollment Form" showLogos={false} />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card className="shadow-lg">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Student Enrollment Form</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6" noValidate>
                {/* Personal Information */}
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name *</Label>
                    <Input
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) => handleInputChange('lastName', e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name *</Label>
                    <Input
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) => handleInputChange('firstName', e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="middleName">Middle Name</Label>
                    <Input
                      id="middleName"
                      value={formData.middleName}
                      onChange={(e) => handleInputChange('middleName', e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="lrn">Learner Reference Number (LRN) *</Label>
                    <Input
                      id="lrn"
                      value={formData.lrn}
                      onChange={(e) => handleInputChange('lrn', e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dateOfBirth">Date of Birth *</Label>
                    <Input
                      id="dateOfBirth"
                      type="text"
                      value={formData.dateOfBirth}
                      onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                      placeholder="MM/DD/YYYY"
                      required
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="placeOfBirth">Place of Birth *</Label>
                    <Input
                      id="placeOfBirth"
                      value={formData.placeOfBirth}
                      onChange={(e) => handleInputChange('placeOfBirth', e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="gender">Gender *</Label>
                    <Select value={formData.gender} onValueChange={(value) => handleInputChange('gender', value as 'Male' | 'Female')}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Male">Male</SelectItem>
                        <SelectItem value="Female">Female</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Address */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Complete Address</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="zone">Zone</Label>
                      <Input
                        id="zone"
                        value={formData.zone}
                        onChange={(e) => handleInputChange('zone', e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="street">Street</Label>
                      <Input
                        id="street"
                        value={formData.street}
                        onChange={(e) => handleInputChange('street', e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="barangay">Barangay *</Label>
                      <Input
                        id="barangay"
                        value={formData.barangay}
                        onChange={(e) => handleInputChange('barangay', e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="city">Municipality/City *</Label>
                      <Input
                        id="city"
                        value={formData.city}
                        onChange={(e) => handleInputChange('city', e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="province">Province *</Label>
                      <Input
                        id="province"
                        value={formData.province}
                        onChange={(e) => handleInputChange('province', e.target.value)}
                        required
                      />
                    </div>
                  </div>
                </div>

                 {/* Academic Background */}
                 <div className="space-y-4">
                   <h3 className="text-lg font-semibold">Previous Academic Information</h3>
                   <div className="grid md:grid-cols-2 gap-4">
                     <div className="space-y-2">
                       <Label htmlFor="gradeLevel">Grade Level *</Label>
                       <Select value={formData.gradeLevel} onValueChange={(value) => handleInputChange('gradeLevel', value)}>
                         <SelectTrigger>
                           <SelectValue placeholder="Select grade level" />
                         </SelectTrigger>
                         <SelectContent>
                           <SelectItem value="Grade 11">Grade 11</SelectItem>
                           <SelectItem value="Grade 12">Grade 12</SelectItem>
                         </SelectContent>
                       </Select>
                     </div>
                     <div className="space-y-2">
                       <Label htmlFor="previousSection">Previous Section *</Label>
                       <Input
                         id="previousSection"
                         value={formData.previousSection}
                         onChange={(e) => handleInputChange('previousSection', e.target.value)}
                         placeholder="e.g., Rizal"
                         required
                       />
                     </div>
                   </div>

                   <div className="grid md:grid-cols-2 gap-4">
                     <div className="space-y-2">
                       <Label htmlFor="previousAdviser">Previous Adviser</Label>
                       <Input
                         id="previousAdviser"
                         value={formData.previousAdviser}
                         onChange={(e) => handleInputChange('previousAdviser', e.target.value)}
                         placeholder="e.g., Mrs. Smith"
                       />
                     </div>
                     <div className="space-y-2">
                       <Label htmlFor="generalAverage">General Average</Label>
                       <Input
                         id="generalAverage"
                         type="number"
                         step="0.01"
                         min="75"
                         max="100"
                         value={formData.generalAverage}
                         onChange={(e) => handleInputChange('generalAverage', e.target.value)}
                         placeholder="e.g., 85.50"
                       />
                     </div>
                   </div>

                   {/* Balik Aral Checkbox */}
                   <div className="flex items-center space-x-2">
                     <Checkbox
                       id="isBalikAral"
                       checked={formData.isBalikAral}
                       onCheckedChange={(checked) => handleInputChange('isBalikAral', checked as boolean)}
                     />
                     <Label htmlFor="isBalikAral">Balik-Aral</Label>
                   </div>

                   {/* Transfer Student Checkbox */}
                   <div className="flex items-center space-x-2">
                     <Checkbox
                       id="isTransferStudent"
                       checked={formData.isTransferStudent}
                       onCheckedChange={(checked) => handleInputChange('isTransferStudent', checked as boolean)}
                     />
                     <Label htmlFor="isTransferStudent">I am a Transfer Student</Label>
                   </div>

                   {/* Transfer Student Details */}
                   {formData.isTransferStudent && (
                     <div className="space-y-4 p-4 border rounded-md bg-muted/50">
                       <h4 className="font-medium">Transfer Student Information</h4>
                       <div className="grid md:grid-cols-2 gap-4">
                         <div className="space-y-2">
                           <Label htmlFor="transferSchool">Previous School</Label>
                           <Input
                             id="transferSchool"
                             value={formData.transferSchool}
                             onChange={(e) => handleInputChange('transferSchool', e.target.value)}
                             placeholder="Name of previous school"
                           />
                         </div>
                         <div className="space-y-2">
                           <Label htmlFor="transferGrade">Previous Grade</Label>
                           <Input
                             id="transferGrade"
                             value={formData.transferGrade}
                             onChange={(e) => handleInputChange('transferGrade', e.target.value)}
                             placeholder="e.g., Grade 11"
                           />
                         </div>
                         <div className="space-y-2">
                           <Label htmlFor="transferSection">Previous Section</Label>
                           <Input
                             id="transferSection"
                             value={formData.transferSection}
                             onChange={(e) => handleInputChange('transferSection', e.target.value)}
                             placeholder="e.g., Section A"
                           />
                         </div>
                         <div className="space-y-2">
                           <Label htmlFor="transferAdviser">Previous Adviser</Label>
                           <Input
                             id="transferAdviser"
                             value={formData.transferAdviser}
                             onChange={(e) => handleInputChange('transferAdviser', e.target.value)}
                             placeholder="Name of previous adviser"
                           />
                         </div>
                         <div className="space-y-2">
                           <Label htmlFor="transferAverage">General Average</Label>
                           <Input
                             id="transferAverage"
                             type="number"
                             step="0.01"
                             min="75"
                             max="100"
                             value={formData.transferAverage}
                             onChange={(e) => handleInputChange('transferAverage', e.target.value)}
                             placeholder="e.g., 85.50"
                           />
                         </div>
                       </div>
                     </div>
                   )}
                 </div>

                {/* Family Information */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Family Information</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="mothersMaidenName">Mother's Maiden Name *</Label>
                      <Input
                        id="mothersMaidenName"
                        value={formData.mothersMaidenName}
                        onChange={(e) => handleInputChange('mothersMaidenName', e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="fatherName">Father's Complete Name *</Label>
                      <Input
                        id="fatherName"
                        value={formData.fatherName}
                        onChange={(e) => handleInputChange('fatherName', e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="contactNumber">Contact Number *</Label>
                      <Input
                        id="contactNumber"
                        value={formData.contactNumber}
                        onChange={(e) => handleInputChange('contactNumber', e.target.value)}
                        placeholder="09XX-XXX-XXXX"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="religion">Religion *</Label>
                      <Input
                        id="religion"
                        value={formData.religion}
                        onChange={(e) => handleInputChange('religion', e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="is4ps"
                        checked={formData.is4ps}
                        onCheckedChange={(checked) => handleInputChange('is4ps', checked as boolean)}
                      />
                      <Label htmlFor="is4ps">4Ps Beneficiary</Label>
                    </div>
                    
                    {formData.is4ps && (
                      <div className="space-y-4 p-4 border rounded-md bg-muted/50">
                        <h4 className="font-medium">4Ps Details</h4>
                        <div className="grid md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="fourPsStudentName">Name of student:</Label>
                            <Input
                              id="fourPsStudentName"
                              value={formData.fourPsStudentName}
                              onChange={(e) => handleInputChange('fourPsStudentName', e.target.value)}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="fourPsParentName">Name of parent:</Label>
                            <Input
                              id="fourPsParentName"
                              value={formData.fourPsParentName}
                              onChange={(e) => handleInputChange('fourPsParentName', e.target.value)}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="fourPsIdNumber">4Ps ID Number:</Label>
                            <Input
                              id="fourPsIdNumber"
                              value={formData.fourPsIdNumber}
                              onChange={(e) => handleInputChange('fourPsIdNumber', e.target.value)}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="fourPsContactNumber">Contact No.:</Label>
                            <Input
                              id="fourPsContactNumber"
                              value={formData.fourPsContactNumber}
                              onChange={(e) => handleInputChange('fourPsContactNumber', e.target.value)}
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Strand Selection */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Strand Selection *</h3>
                  <Select value={formData.selectedStrand} onValueChange={(value) => handleInputChange('selectedStrand', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your preferred strand" />
                    </SelectTrigger>
                    <SelectContent>
                     {Object.entries(STRANDS).map(([category, strands]) => (
                        strands.map(strand => (
                          <SelectItem key={strand} value={strand}>
                            {strand}
                          </SelectItem>
                        ))
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                 {/* Required Documents */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Required Documents</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="birthCertificate">Birth Certificate</Label>
                      <Input
                        id="birthCertificate"
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileChange('birthCertificate', e.target.files?.[0] || null)}
                        className="file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:bg-primary file:text-primary-foreground hover:file:bg-primary/80"
                      />
                      {formData.birthCertificateName && (
                        <p className="text-sm text-muted-foreground">✓ {formData.birthCertificateName}</p>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="reportCard">Learner's Report Card</Label>
                      <Input
                        id="reportCard"
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileChange('reportCard', e.target.files?.[0] || null)}
                        className="file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:bg-primary file:text-primary-foreground hover:file:bg-primary/80"
                      />
                      {formData.reportCardName && (
                        <p className="text-sm text-muted-foreground">✓ {formData.reportCardName}</p>
                      )}
                    </div>
                  </div>
                  
                  {/* Certificate of Completion for Grade 11 */}
                  {formData.gradeLevel && formData.gradeLevel.includes('11') && (
                    <div className="mt-4">
                      <div className="space-y-2">
                        <Label htmlFor="certificateOfCompletion">Certificate of Completion (COC) *</Label>
                        <p className="text-sm text-muted-foreground">Required for incoming Grade 11 students</p>
                        <Input
                          id="certificateOfCompletion"
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleFileChange('certificateOfCompletion', e.target.files?.[0] || null)}
                          className="file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:bg-primary file:text-primary-foreground hover:file:bg-primary/80"
                        />
                        {formData.certificateOfCompletionName && (
                          <p className="text-sm text-muted-foreground">✓ {formData.certificateOfCompletionName}</p>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Account Security */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Account Security</h3>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        placeholder="Enter your email address"
                        required
                      />
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="password">Password *</Label>
                        <Input
                          id="password"
                          type="password"
                          value={formData.password}
                          onChange={(e) => handleInputChange('password', e.target.value)}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="confirmPassword">Confirm Password *</Label>
                        <Input
                          id="confirmPassword"
                          type="password"
                          value={formData.confirmPassword}
                          onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                          required
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button 
                    type="submit" 
                    className="flex-1" 
                    disabled={isLoading}
                    onClick={(e) => {
                      console.log('BUTTON CLICKED DIRECTLY!');
                      e.preventDefault();
                      handleSubmit(e as any);
                    }}
                  >
                    {isLoading ? 'Submitting...' : 'Submit Enrollment Form'}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => navigate('/student/login')}
                  >
                    Already have an account?
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};