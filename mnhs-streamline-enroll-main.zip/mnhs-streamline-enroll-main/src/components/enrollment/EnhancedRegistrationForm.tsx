import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Header } from '@/components/layout/Header';
import { checkLRNExists, setCurrentUser, getCurrentUser } from '@/lib/supabase-storage';
import { normalizeStrandForDB } from '@/lib/utils';
import { EnrollmentFormData, Student, STRANDS } from '@/types/enrollment';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import {
  User,
  MapPin,
  GraduationCap,
  Users,
  FileText,
  Upload,
  CheckCircle,
  ArrowLeft,
  ArrowRight,
  Calendar,
  Phone,
  BookOpen,
  Award
} from 'lucide-react';

interface FormStepProps {
  children: React.ReactNode;
  title: string;
  description: string;
  icon: React.ReactNode;
}

const FormStep = ({ children, title, description, icon }: FormStepProps) => (
  <Card className="shadow-card hover:shadow-card-hover transition-all duration-300 animate-fade-in">
    <CardHeader className="pb-4">
      <div className="flex items-center gap-3 mb-2">
        <div className="p-2 rounded-lg bg-primary/10 text-primary">
          {icon}
        </div>
        <div>
          <CardTitle className="text-xl font-semibold">{title}</CardTitle>
          <p className="text-sm text-muted-foreground mt-1">{description}</p>
        </div>
      </div>
    </CardHeader>
    <CardContent className="space-y-6">
      {children}
    </CardContent>
  </Card>
);

export const EnhancedRegistrationForm = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [pendingAccountId, setPendingAccountId] = useState<string | null>(null);
  const [pendingEmail, setPendingEmail] = useState<string>('');
  const [authChecked, setAuthChecked] = useState(false);
  const totalSteps = 5; // account setup is removed; signup happens before enrollment

  const [formData, setFormData] = useState<EnrollmentFormData>({
    lastName: '',
    firstName: '',
    middleName: '',
    lrn: '',
    dateOfBirth: '',
    placeOfBirth: '',
    zone: '',
    street: '',
    barangay: '',
    city: '',
    province: '',
    gender: 'Male',
    gradeLevel: '',
    previousSection: '',
    previousAdviser: '',
    generalAverage: '',
    mothersMaidenName: '',
    fatherName: '',
    contactNumber: '',
    religion: '',
    is4ps: false,
    isBalikAral: false,
    isTransferStudent: false,
    transferSchool: '',
    transferGrade: '',
    transferSection: '',
    transferAdviser: '',
    transferAverage: '',
    fourPsStudentName: '',
    fourPsParentName: '',
    fourPsIdNumber: '',
    fourPsContactNumber: '',
    selectedStrand: '',
    email: '',
    password: '',
    confirmPassword: '',
    birthCertificate: '',
    reportCard: '',
    reportCardFront: '',
    reportCardBack: '',
    birthCertificateName: '',
    reportCardName: '',
    reportCardFrontName: '',
    reportCardBackName: '',
    certificateOfCompletion: '',
    certificateOfCompletionName: ''
  });

  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  // Require a verified pending signup session before enrolling
  useEffect(() => {
    (async () => {
      const current = await getCurrentUser();
      const u: any = current?.user;
      if (!current || current.type !== 'student' || !u?.isPendingAccount || !u?.id) {
        toast({
          title: 'Account required',
          description: 'Please sign up and verify your email before enrolling.',
          variant: 'destructive',
        });
        navigate('/student/signup');
        return;
      }
      setPendingAccountId(u.id);
      setPendingEmail(u.email || '');
      setFormData((prev) => ({
        ...prev,
        firstName: u.firstName || prev.firstName,
        lastName: u.lastName || prev.lastName,
        email: u.email || prev.email,
      }));
      setAuthChecked(true);
    })();
  }, [navigate, toast]);


  const handleInputChange = (field: keyof EnrollmentFormData, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const ALLOWED_FILE_TYPES = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
  const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

  const handleFileChange = async (field: 'birthCertificate' | 'reportCardFront' | 'reportCardBack' | 'certificateOfCompletion', file: File | null) => {
    if (!file) return;

    // Validate file type
    const ext = file.name.toLowerCase().split('.').pop() || '';
    const allowedExt = ['pdf', 'jpg', 'jpeg', 'png'];
    if (!ALLOWED_FILE_TYPES.includes(file.type) && !allowedExt.includes(ext)) {
      toast({
        title: 'Invalid File Type',
        description: 'Only PDF, JPG, JPEG, and PNG files are allowed.',
        variant: 'destructive',
      });
      return;
    }

    // Validate file size
    if (file.size > MAX_FILE_SIZE) {
      toast({
        title: 'File Too Large',
        description: 'Maximum file size is 5MB. Please upload a smaller file.',
        variant: 'destructive',
      });
      return;
    }

    try {
      const fileName = `${Date.now()}_${file.name}`;
      const { data, error } = await supabase.storage
        .from('student-documents')
        .upload(fileName, file);

      if (error) {
        toast({
          title: "Upload Error",
          description: "Failed to upload file. Please try again.",
          variant: "destructive",
        });
        return;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('student-documents')
        .getPublicUrl(fileName);

      setFormData(prev => ({
        ...prev,
        [field]: publicUrl,
        [`${field}Name`]: file.name
      }));

      toast({
        title: "File Uploaded",
        description: `${file.name} uploaded successfully!`,
      });
    } catch (error) {
      console.error('File upload error:', error);
      toast({
        title: "Upload Error",
        description: "An error occurred while uploading the file.",
        variant: "destructive",
      });
    }
  };

  // Detailed validation returning a specific error message (or null)
  const getStepError = (step: number): string | null => {
    const trim = (s?: string) => (s || '').trim();
    switch (step) {
      case 1: {
        if (!trim(formData.firstName)) return 'First name is required.';
        if (trim(formData.firstName).length > 100) return 'First name must be under 100 characters.';
        if (!trim(formData.lastName)) return 'Last name is required.';
        if (trim(formData.lastName).length > 100) return 'Last name must be under 100 characters.';
        if (!/^[0-9]{12}$/.test(formData.lrn)) return 'LRN must be exactly 12 digits.';
        if (!formData.dateOfBirth) return 'Date of birth is required.';
        const dob = new Date(formData.dateOfBirth);
        if (isNaN(dob.getTime())) return 'Please enter a valid date of birth.';
        if (dob > new Date()) return 'Date of birth cannot be in the future.';
        const ageYears = (Date.now() - dob.getTime()) / (1000 * 60 * 60 * 24 * 365.25);
        if (ageYears < 10 || ageYears > 80) return 'Please enter a realistic date of birth.';
        return null;
      }
      case 2:
        if (!trim(formData.street)) return 'Street address is required.';
        if (!trim(formData.barangay)) return 'Barangay is required.';
        if (!trim(formData.city)) return 'City/Municipality is required.';
        if (!trim(formData.province)) return 'Province is required.';
        return null;
      case 3:
        if (!formData.gradeLevel) return 'Please select a grade level.';
        if (!formData.selectedStrand) return 'Please select a preferred strand.';
        if (formData.generalAverage) {
          const avg = parseFloat(formData.generalAverage);
          if (isNaN(avg) || avg < 0 || avg > 100) return 'General average must be between 0 and 100.';
        }
        return null;
      case 4:
        if (!trim(formData.mothersMaidenName)) return "Mother's maiden name is required.";
        if (!trim(formData.fatherName)) return "Father's complete name is required.";
        if (!/^[0-9]{10,15}$/.test(formData.contactNumber)) return 'Contact number must be 10–15 digits (numbers only).';
        return null;
      case 5: {
        if (!formData.birthCertificate) return 'Please upload your Birth Certificate.';
        if (!formData.reportCardFront) return 'Please upload Report Card (Front).';
        if (!formData.reportCardBack) return 'Please upload Report Card (Back).';
        if (formData.gradeLevel?.includes('11') && !formData.certificateOfCompletion) {
          return 'Certificate of Completion is required for Grade 11.';
        }
        return null;
      }
      default:
        return null;
    }
  };

  const validateStep = (step: number): boolean => getStepError(step) === null;

  const nextStep = () => {
    const err = getStepError(currentStep);
    if (!err && currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    } else if (err) {
      toast({
        title: "Please fix the form",
        description: err,
        variant: "destructive",
      });
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!pendingAccountId) {
      toast({
        title: 'Account required',
        description: 'Please sign up and verify your email before enrolling.',
        variant: 'destructive',
      });
      navigate('/student/signup');
      return;
    }

    // Validate every step before final submit
    for (let s = 1; s <= 5; s++) {
      const err = getStepError(s);
      if (err) {
        toast({ title: `Step ${s} incomplete`, description: err, variant: 'destructive' });
        setCurrentStep(s);
        return;
      }
    }

    setIsLoading(true);

    try {
      const existingStudent = await checkLRNExists(formData.lrn);
      if (existingStudent) {
        toast({
          title: "LRN Already Exists",
          description: "This LRN is already registered. Please check your LRN or contact administration.",
          variant: "destructive",
        });
        return;
      }

      // Build student row matching the `students` table schema (snake_case columns).
      const studentRow: Record<string, any> = {
        last_name: formData.lastName,
        first_name: formData.firstName,
        middle_name: formData.middleName || null,
        lrn: formData.lrn,
        date_of_birth: formData.dateOfBirth,
        place_of_birth: formData.placeOfBirth || '',
        zone: formData.zone || null,
        street: formData.street || null,
        barangay: formData.barangay || '',
        city: formData.city || '',
        province: formData.province || '',
        gender: formData.gender,
        grade_level: formData.gradeLevel || null,
        previous_grade: formData.gradeLevel || '',
        previous_section: formData.previousSection || '',
        previous_adviser: formData.previousAdviser || null,
        general_average: formData.generalAverage ? parseFloat(formData.generalAverage) : null,
        mothers_maiden_name: formData.mothersMaidenName,
        fathers_name: formData.fatherName,
        contact_number: formData.contactNumber,
        religion: formData.religion || '',
        is_4ps: !!formData.is4ps,
        four_ps_student_name: formData.fourPsStudentName || null,
        four_ps_parent_name: formData.fourPsParentName || null,
        four_ps_id_number: formData.fourPsIdNumber || null,
        four_ps_contact_number: formData.fourPsContactNumber || null,
        is_balik_aral: !!formData.isBalikAral,
        is_transfer_student: !!formData.isTransferStudent,
        transfer_school: formData.transferSchool || null,
        transfer_grade: formData.transferGrade || null,
        transfer_section: formData.transferSection || null,
        transfer_adviser: formData.transferAdviser || null,
        transfer_average: formData.transferAverage ? parseFloat(formData.transferAverage) : null,
        strand: normalizeStrandForDB(formData.selectedStrand),
        birth_certificate: formData.birthCertificate || null,
        birth_certificate_name: formData.birthCertificateName || null,
        report_card_front: formData.reportCardFront || null,
        report_card_back: formData.reportCardBack || null,
        report_card_front_name: formData.reportCardFrontName || null,
        report_card_back_name: formData.reportCardBackName || null,
        certificate_of_completion: formData.certificateOfCompletion || null,
        certificate_of_completion_name: formData.certificateOfCompletionName || null,
      };

      const { data, error } = await supabase.functions.invoke('complete-enrollment', {
        body: { pendingId: pendingAccountId, studentRow },
      });

      if (error || !data?.success) {
        const msg = data?.error || error?.message || 'Failed to submit enrollment.';
        throw new Error(msg);
      }

      const student: Student = {
        id: data.studentId,
        ...formData,
        email: pendingEmail,
        generalAverage: parseFloat(formData.generalAverage) || undefined,
        transferAverage: parseFloat(formData.transferAverage) || undefined,
        enrollmentStatus: 'Pending',
        enrollmentDate: new Date().toISOString(),
      };

      // Refresh session with the real student record (no longer pending account)
      await setCurrentUser(student, 'student');

      toast({
        title: "Registration Successful!",
        description: "Your enrollment application has been submitted.",
      });

      navigate('/confirm-registration', {
        state: {
          message: 'Registration successful! Your application is now under review.',
          student,
        },
      });
    } catch (error: any) {
      console.error('Registration error:', error);
      toast({
        title: "Registration Failed",
        description: error?.message || "An error occurred during registration. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };


  const progress = (currentStep / totalSteps) * 100;

  if (!authChecked) {
    return (
      <div className="min-h-screen school-bg flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }


  return (
    <div className="min-h-screen school-bg">
      <Header title="Student Registration" subtitle="Join Our Academic Community" showLogos={false} />
      
      <div className="container mx-auto px-4 py-8">
        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold">Step {currentStep} of {totalSteps}</h2>
            <Badge variant="outline" className="text-sm">
              {Math.round(progress)}% Complete
            </Badge>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <form onSubmit={handleSubmit} className="max-w-4xl mx-auto">
          {/* Step 1: Personal Information */}
          {currentStep === 1 && (
            <FormStep
              title="Personal Information"
              description="Tell us about yourself"
              icon={<User className="w-5 h-5" />}
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name *</Label>
                  <Input
                    id="firstName"
                    value={formData.firstName}
                    onChange={(e) => handleInputChange('firstName', e.target.value)}
                    placeholder="Enter your first name"
                    className="h-11"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name *</Label>
                  <Input
                    id="lastName"
                    value={formData.lastName}
                    onChange={(e) => handleInputChange('lastName', e.target.value)}
                    placeholder="Enter your last name"
                    className="h-11"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="middleName">Middle Name</Label>
                  <Input
                    id="middleName"
                    value={formData.middleName}
                    onChange={(e) => handleInputChange('middleName', e.target.value)}
                    placeholder="Enter your middle name"
                    className="h-11"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="lrn">Learner Reference Number (LRN) *</Label>
                  <Input
                    id="lrn"
                    value={formData.lrn}
                    onChange={(e) => handleInputChange('lrn', e.target.value)}
                    placeholder="12-digit LRN"
                    maxLength={12}
                    className="h-11"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dateOfBirth">Date of Birth *</Label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="dateOfBirth"
                      type="date"
                      value={formData.dateOfBirth}
                      onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                      className="h-11 pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="placeOfBirth">Place of Birth</Label>
                  <Input
                    id="placeOfBirth"
                    value={formData.placeOfBirth}
                    onChange={(e) => handleInputChange('placeOfBirth', e.target.value)}
                    placeholder="City, Province"
                    className="h-11"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="gender">Gender</Label>
                  <Select value={formData.gender} onValueChange={(value) => handleInputChange('gender', value)}>
                    <SelectTrigger className="h-11">
                      <SelectValue placeholder="Select your gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Male">Male</SelectItem>
                      <SelectItem value="Female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="religion">Religion</Label>
                  <Input
                    id="religion"
                    value={formData.religion}
                    onChange={(e) => handleInputChange('religion', e.target.value)}
                    placeholder="Enter your religion"
                    className="h-11"
                  />
                </div>
              </div>
            </FormStep>
          )}

          {/* Step 2: Address Information */}
          {currentStep === 2 && (
            <FormStep
              title="Address Information"
              description="Where do you live?"
              icon={<MapPin className="w-5 h-5" />}
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="street">Street Address *</Label>
                  <Input
                    id="street"
                    value={formData.street}
                    onChange={(e) => handleInputChange('street', e.target.value)}
                    placeholder="House number and street name"
                    className="h-11"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="zone">Zone/Purok</Label>
                  <Input
                    id="zone"
                    value={formData.zone}
                    onChange={(e) => handleInputChange('zone', e.target.value)}
                    placeholder="Zone or Purok"
                    className="h-11"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="barangay">Barangay *</Label>
                  <Input
                    id="barangay"
                    value={formData.barangay}
                    onChange={(e) => handleInputChange('barangay', e.target.value)}
                    placeholder="Enter barangay"
                    className="h-11"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="city">City/Municipality *</Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => handleInputChange('city', e.target.value)}
                    placeholder="Enter city or municipality"
                    className="h-11"
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="province">Province *</Label>
                  <Input
                    id="province"
                    value={formData.province}
                    onChange={(e) => handleInputChange('province', e.target.value)}
                    placeholder="Enter province"
                    className="h-11"
                  />
                </div>
              </div>
            </FormStep>
          )}

          {/* Step 3: Academic Information */}
          {currentStep === 3 && (
            <FormStep
              title="Academic Information"
              description="Your academic background"
              icon={<GraduationCap className="w-5 h-5" />}
            >
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="gradeLevel">Grade Level to Enroll *</Label>
                    <Select value={formData.gradeLevel} onValueChange={(value) => handleInputChange('gradeLevel', value)}>
                      <SelectTrigger className="h-11">
                        <SelectValue placeholder="Select grade level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Grade 11">Grade 11</SelectItem>
                        <SelectItem value="Grade 12">Grade 12</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="selectedStrand">Preferred Strand *</Label>
                    <Select value={formData.selectedStrand} onValueChange={(value) => handleInputChange('selectedStrand', value)}>
                      <SelectTrigger className="h-11">
                        <SelectValue placeholder="Select your preferred strand" />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.values(STRANDS).flat().map((strand) => (
                          <SelectItem key={strand} value={strand}>{strand}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h4 className="font-semibold flex items-center gap-2">
                    <BookOpen className="w-4 h-4" />
                    Previous Academic Information
                  </h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="previousSection">Previous Grade/Section</Label>
                      <Input
                        id="previousSection"
                        value={formData.previousSection}
                        onChange={(e) => handleInputChange('previousSection', e.target.value)}
                        placeholder="e.g., Einstein"
                        className="h-11"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="previousAdviser">Previous Adviser</Label>
                      <Input
                        id="previousAdviser"
                        value={formData.previousAdviser}
                        onChange={(e) => handleInputChange('previousAdviser', e.target.value)}
                        placeholder="Teacher's name"
                        className="h-11"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="generalAverage">General Average</Label>
                      <Input
                        id="generalAverage"
                        value={formData.generalAverage}
                        onChange={(e) => handleInputChange('generalAverage', e.target.value)}
                        placeholder="e.g., 85.5"
                        type="number"
                        step="0.01"
                        className="h-11"
                      />
                    </div>
                  </div>
                </div>

                {/* Transfer Student Section */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="isTransferStudent"
                      checked={formData.isTransferStudent}
                      onCheckedChange={(checked) => handleInputChange('isTransferStudent', checked as boolean)}
                    />
                    <Label htmlFor="isTransferStudent" className="text-sm font-medium">
                      I am a transfer student
                    </Label>
                  </div>

                  {formData.isTransferStudent && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 border rounded-lg bg-muted/30">
                      <div className="space-y-2">
                        <Label htmlFor="transferSchool">Previous School</Label>
                        <Input
                          id="transferSchool"
                          value={formData.transferSchool}
                          onChange={(e) => handleInputChange('transferSchool', e.target.value)}
                          placeholder="Name of previous school"
                          className="h-11"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="transferGrade">Previous Grade Level</Label>
                        <Input
                          id="transferGrade"
                          value={formData.transferGrade}
                          onChange={(e) => handleInputChange('transferGrade', e.target.value)}
                          placeholder="e.g., Grade 10"
                          className="h-11"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="transferSection">Previous Grade/Section</Label>
                        <Input
                          id="transferSection"
                          value={formData.transferSection}
                          onChange={(e) => handleInputChange('transferSection', e.target.value)}
                          placeholder="Section name"
                          className="h-11"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="transferAverage">Previous Average</Label>
                        <Input
                          id="transferAverage"
                          value={formData.transferAverage}
                          onChange={(e) => handleInputChange('transferAverage', e.target.value)}
                          placeholder="e.g., 87.5"
                          type="number"
                          step="0.01"
                          className="h-11"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Balik Aral Section */}
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="isBalikAral"
                    checked={formData.isBalikAral}
                    onCheckedChange={(checked) => handleInputChange('isBalikAral', checked as boolean)}
                  />
                  <Label htmlFor="isBalikAral" className="text-sm font-medium">
                    I am a Balik Aral student (returning to school)
                  </Label>
                </div>
              </div>
            </FormStep>
          )}

          {/* Step 4: Family Information */}
          {currentStep === 4 && (
            <FormStep
              title="Family Information"
              description="Tell us about your family"
              icon={<Users className="w-5 h-5" />}
            >
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="mothersMaidenName">Mother's Maiden Name *</Label>
                    <Input
                      id="mothersMaidenName"
                      value={formData.mothersMaidenName}
                      onChange={(e) => handleInputChange('mothersMaidenName', e.target.value)}
                      placeholder="Enter mother's maiden name"
                      className="h-11"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="fatherName">Father's Complete Name *</Label>
                    <Input
                      id="fatherName"
                      value={formData.fatherName}
                      onChange={(e) => handleInputChange('fatherName', e.target.value)}
                      placeholder="Enter father's full name"
                      className="h-11"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="contactNumber">Contact Number *</Label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="contactNumber"
                        value={formData.contactNumber}
                        onChange={(e) => handleInputChange('contactNumber', e.target.value)}
                        placeholder="09XXXXXXXXX"
                        className="h-11 pl-10"
                      />
                    </div>
                  </div>
                </div>

                <Separator />

                {/* 4Ps Section */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="is4ps"
                      checked={formData.is4ps}
                      onCheckedChange={(checked) => handleInputChange('is4ps', checked as boolean)}
                    />
                    <Label htmlFor="is4ps" className="text-sm font-medium">
                      4Ps beneficiary (Pantawid Pamilyang Pilipino Program)
                    </Label>
                  </div>

                  {formData.is4ps && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 border rounded-lg bg-muted/30">
                      <div className="space-y-2">
                        <Label htmlFor="fourPsStudentName">4Ps Student Name</Label>
                        <Input
                          id="fourPsStudentName"
                          value={formData.fourPsStudentName}
                          onChange={(e) => handleInputChange('fourPsStudentName', e.target.value)}
                          placeholder="Name as registered in 4Ps"
                          className="h-11"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="fourPsParentName">4Ps Parent/Guardian Name</Label>
                        <Input
                          id="fourPsParentName"
                          value={formData.fourPsParentName}
                          onChange={(e) => handleInputChange('fourPsParentName', e.target.value)}
                          placeholder="Parent/guardian name in 4Ps"
                          className="h-11"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="fourPsIdNumber">4Ps ID Number</Label>
                        <Input
                          id="fourPsIdNumber"
                          value={formData.fourPsIdNumber}
                          onChange={(e) => handleInputChange('fourPsIdNumber', e.target.value)}
                          placeholder="4Ps ID number"
                          className="h-11"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="fourPsContactNumber">4Ps Contact Number</Label>
                        <Input
                          id="fourPsContactNumber"
                          value={formData.fourPsContactNumber}
                          onChange={(e) => handleInputChange('fourPsContactNumber', e.target.value)}
                          placeholder="Contact number for 4Ps"
                          className="h-11"
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </FormStep>
          )}

          {/* Step 5: Document Upload */}
          {currentStep === 5 && (
            <FormStep
              title="Required Documents"
              description="Upload your enrollment documents"
              icon={<FileText className="w-5 h-5" />}
            >
              <div className="space-y-6">
                {/* Birth Certificate */}
                <div className="space-y-2">
                  <Label htmlFor="birthCertificate" className="flex items-center gap-2">
                    <Award className="w-4 h-4" />
                    Birth Certificate *
                  </Label>
                  <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary/50 transition-colors">
                    <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                    <div className="space-y-2">
                      <Label htmlFor="birthCertificate-upload" className="cursor-pointer text-sm font-medium text-primary hover:text-primary/80">
                        Click to upload Birth Certificate
                      </Label>
                      <Input
                        id="birthCertificate-upload"
                        type="file"
                        accept=".pdf,.jpg,.jpeg,.png"
                        onChange={(e) => handleFileChange('birthCertificate', e.target.files?.[0] || null)}
                        className="hidden"
                      />
                      <p className="text-xs text-muted-foreground">PDF, JPG, PNG (Max 5MB)</p>
                      {formData.birthCertificateName && (
                        <div className="flex items-center justify-center gap-2 mt-2 text-green-600">
                          <CheckCircle className="w-4 h-4" />
                          <span className="text-sm">{formData.birthCertificateName}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Report Card - Front */}
                <div className="space-y-2">
                  <Label htmlFor="reportCardFront" className="flex items-center gap-2">
                    <Award className="w-4 h-4" />
                    Report Card/Form 138 (Front) *
                  </Label>
                  <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary/50 transition-colors">
                    <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                    <div className="space-y-2">
                      <Label htmlFor="reportCardFront-upload" className="cursor-pointer text-sm font-medium text-primary hover:text-primary/80">
                        Click to upload Report Card (Front)
                      </Label>
                      <Input
                        id="reportCardFront-upload"
                        type="file"
                        accept=".pdf,.jpg,.jpeg,.png"
                        onChange={(e) => handleFileChange('reportCardFront', e.target.files?.[0] || null)}
                        className="hidden"
                      />
                      <p className="text-xs text-muted-foreground">PDF, JPG, PNG (Max 5MB)</p>
                      {formData.reportCardFrontName && (
                        <div className="flex items-center justify-center gap-2 mt-2 text-green-600">
                          <CheckCircle className="w-4 h-4" />
                          <span className="text-sm">{formData.reportCardFrontName}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Report Card - Back */}
                <div className="space-y-2">
                  <Label htmlFor="reportCardBack" className="flex items-center gap-2">
                    <Award className="w-4 h-4" />
                    Report Card/Form 138 (Back) *
                  </Label>
                  <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary/50 transition-colors">
                    <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                    <div className="space-y-2">
                      <Label htmlFor="reportCardBack-upload" className="cursor-pointer text-sm font-medium text-primary hover:text-primary/80">
                        Click to upload Report Card (Back)
                      </Label>
                      <Input
                        id="reportCardBack-upload"
                        type="file"
                        accept=".pdf,.jpg,.jpeg,.png"
                        onChange={(e) => handleFileChange('reportCardBack', e.target.files?.[0] || null)}
                        className="hidden"
                      />
                      <p className="text-xs text-muted-foreground">PDF, JPG, PNG (Max 5MB)</p>
                      {formData.reportCardBackName && (
                        <div className="flex items-center justify-center gap-2 mt-2 text-green-600">
                          <CheckCircle className="w-4 h-4" />
                          <span className="text-sm">{formData.reportCardBackName}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Certificate of Completion for Grade 11 */}
                {formData.gradeLevel && formData.gradeLevel.includes('11') && (
                  <div className="space-y-2">
                    <Label htmlFor="certificateOfCompletion" className="flex items-center gap-2">
                      <Award className="w-4 h-4" />
                      Certificate of Completion (COC) *
                    </Label>
                    <p className="text-sm text-muted-foreground">Required for incoming Grade 11 students</p>
                    <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary/50 transition-colors">
                      <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                      <div className="space-y-2">
                        <Label htmlFor="certificateOfCompletion-upload" className="cursor-pointer text-sm font-medium text-primary hover:text-primary/80">
                          Click to upload Certificate of Completion
                        </Label>
                        <Input
                          id="certificateOfCompletion-upload"
                          type="file"
                          accept=".pdf,.jpg,.jpeg,.png"
                          onChange={(e) => handleFileChange('certificateOfCompletion', e.target.files?.[0] || null)}
                          className="hidden"
                        />
                        <p className="text-xs text-muted-foreground">PDF, JPG, PNG (Max 5MB)</p>
                        {formData.certificateOfCompletionName && (
                          <div className="flex items-center justify-center gap-2 mt-2 text-green-600">
                            <CheckCircle className="w-4 h-4" />
                            <span className="text-sm">{formData.certificateOfCompletionName}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </FormStep>
          )}

          {/* Navigation Buttons */}
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mt-8">
            <div className="flex items-center gap-2 order-2 sm:order-1">
              {currentStep > 1 && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={prevStep}
                  className="flex items-center gap-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Previous
                </Button>
              )}
              
              <Button
                type="button"
                variant="ghost"
                onClick={() => navigate('/')}
                className="text-muted-foreground hover:text-foreground"
              >
                Back to Home
              </Button>
            </div>

            <div className="order-1 sm:order-2">
              {currentStep < totalSteps ? (
                <Button
                  type="button"
                  onClick={nextStep}
                  disabled={!validateStep(currentStep)}
                  className="flex items-center gap-2"
                  size="lg"
                >
                  Next Step
                  <ArrowRight className="w-4 h-4" />
                </Button>
              ) : (
                <Button
                  type="submit"
                  disabled={isLoading || !validateStep(5)}
                  className="flex items-center gap-2"
                  size="lg"
                >
                  {isLoading ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current"></div>
                      Submitting...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4" />
                      Complete Registration
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};