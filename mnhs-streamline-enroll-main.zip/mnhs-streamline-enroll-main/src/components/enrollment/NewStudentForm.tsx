import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Header } from '@/components/layout/Header';
import { saveStudent, setCurrentUser } from '@/lib/supabase-storage';
import { EnrollmentFormData, Student, STRANDS } from '@/types/enrollment';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface NewStudentFormProps {
  existingStudent: Student;
  onClose: () => void;
}

export const NewStudentForm = ({ existingStudent, onClose }: NewStudentFormProps) => {
  const [formData, setFormData] = useState<EnrollmentFormData>({
    lastName: existingStudent.lastName,
    firstName: existingStudent.firstName,
    middleName: existingStudent.middleName,
    lrn: existingStudent.lrn,
    dateOfBirth: existingStudent.dateOfBirth,
    placeOfBirth: existingStudent.placeOfBirth,
    zone: existingStudent.zone,
    street: existingStudent.street,
    barangay: existingStudent.barangay,
    city: existingStudent.city,
    province: existingStudent.province,
    gender: existingStudent.gender,
    gradeLevel: '',
    previousSection: '',
    previousAdviser: '',
    generalAverage: '',
    mothersMaidenName: existingStudent.mothersMaidenName,
    fatherName: existingStudent.fatherName,
    contactNumber: existingStudent.contactNumber,
    religion: existingStudent.religion,
    is4ps: existingStudent.is4ps,
    isBalikAral: false,
    isTransferStudent: false,
    transferSchool: '',
    transferGrade: '',
    transferSection: '',
    transferAdviser: '',
    transferAverage: '',
    fourPsStudentName: existingStudent.fourPsStudentName || '',
    fourPsParentName: existingStudent.fourPsParentName || '',
    fourPsIdNumber: existingStudent.fourPsIdNumber || '',
    fourPsContactNumber: existingStudent.fourPsContactNumber || '',
    selectedStrand: '',
    email: existingStudent.email,
    password: '',
    confirmPassword: '',
    birthCertificate: '',
    reportCard: '',
    reportCardFront: '',
    reportCardBack: '',
    birthCertificateName: '',
    reportCardName: '',
    reportCardFrontName: '',
    reportCardBackName: '',
    certificateOfCompletion: '',
    certificateOfCompletionName: ''
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleInputChange = (field: keyof EnrollmentFormData, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleFileChange = async (field: 'birthCertificate' | 'reportCard' | 'certificateOfCompletion', file: File | null) => {
    if (!file) return;
    
    try {
      const fileName = `${Date.now()}_${file.name}`;
      const { data, error } = await supabase.storage
        .from('student-documents')
        .upload(fileName, file);

      if (error) {
        console.error('File upload error:', error);
        toast({
          title: "Upload Error",
          description: "Failed to upload file. Please try again.",
          variant: "destructive",
        });
        return;
      }

      setFormData(prev => ({ 
        ...prev, 
        [field]: fileName,
        [`${field}Name`]: file.name
      }));

      toast({
        title: "File Uploaded",
        description: `${file.name} uploaded successfully.`,
      });
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Upload Error",
        description: "Failed to upload file. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Validation for required fields
      const requiredFields = [
        'lastName', 'firstName', 'lrn', 'dateOfBirth', 'placeOfBirth',
        'barangay', 'city', 'province', 'gradeLevel', 'mothersMaidenName', 
        'fatherName', 'contactNumber', 'religion', 'selectedStrand'
      ];

      for (const field of requiredFields) {
        const value = formData[field as keyof EnrollmentFormData];
        if (!value || (typeof value === 'string' && value.trim() === '')) {
          toast({
            title: "Missing required field",
            description: `Please fill in the ${field.replace(/([A-Z])/g, ' $1').toLowerCase()} field`,
            variant: "destructive",
          });
          setIsLoading(false);
          return;
        }
      }

      // Check COC requirement for Grade 11 students
      if (formData.gradeLevel === 'Grade 11') {
        if (!formData.certificateOfCompletion || !formData.certificateOfCompletionName) {
          toast({
            title: "Missing Certificate of Completion",
            description: "Certificate of Completion (COC) is required for Grade 11 students",
            variant: "destructive",
          });
          setIsLoading(false);
          return;
        }
      }

      // Convert date format from MM/DD/YYYY to YYYY-MM-DD for database
      let formattedDate = formData.dateOfBirth;
      if (formData.dateOfBirth.includes('/')) {
        const [month, day, year] = formData.dateOfBirth.split('/');
        formattedDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
      }

      const student: Student = {
        id: existingStudent.id, // Keep existing ID to update instead of creating new
        lastName: formData.lastName,
        firstName: formData.firstName,
        middleName: formData.middleName || '',
        lrn: formData.lrn,
        dateOfBirth: formattedDate,
        placeOfBirth: formData.placeOfBirth,
        zone: formData.zone || '',
        street: formData.street || '',
        barangay: formData.barangay,
        city: formData.city,
        province: formData.province,
        gender: formData.gender,
        gradeLevel: formData.gradeLevel,
        previousSection: formData.previousSection,
        previousAdviser: formData.previousAdviser,
        generalAverage: formData.generalAverage ? parseFloat(formData.generalAverage) : undefined,
        mothersMaidenName: formData.mothersMaidenName,
        fatherName: formData.fatherName,
        contactNumber: formData.contactNumber,
        religion: formData.religion,
        is4ps: formData.is4ps,
        isBalikAral: formData.isBalikAral,
        isTransferStudent: formData.isTransferStudent,
        transferSchool: formData.isTransferStudent ? formData.transferSchool : undefined,
        transferGrade: formData.isTransferStudent ? formData.transferGrade : undefined,
        transferSection: formData.isTransferStudent ? formData.transferSection : undefined,
        transferAdviser: formData.isTransferStudent ? formData.transferAdviser : undefined,
        transferAverage: formData.isTransferStudent && formData.transferAverage ? parseFloat(formData.transferAverage) : undefined,
        fourPsStudentName: formData.is4ps ? (formData.fourPsStudentName || '') : '',
        fourPsParentName: formData.is4ps ? (formData.fourPsParentName || '') : '',
        fourPsIdNumber: formData.is4ps ? (formData.fourPsIdNumber || '') : '',
        fourPsContactNumber: formData.is4ps ? (formData.fourPsContactNumber || '') : '',
        selectedStrand: formData.selectedStrand,
        enrollmentStatus: 'Pending',
        enrollmentDate: new Date().toISOString(),
        email: existingStudent.email, // Keep existing email
        password: existingStudent.password, // Keep existing password
        birthCertificate: formData.birthCertificate || '',
        reportCard: formData.reportCard || '',
        reportCardFront: '',
        reportCardBack: '',
        birthCertificateName: formData.birthCertificateName || '',
        reportCardName: formData.reportCardName || '',
        reportCardFrontName: '',
        reportCardBackName: '',
        certificateOfCompletion: formData.certificateOfCompletion || '',
        certificateOfCompletionName: formData.certificateOfCompletionName || ''
      };

      await saveStudent(student);
      
      toast({
        title: "New form submitted!",
        description: "Your new enrollment form has been submitted successfully.",
      });
      
      onClose();
      
    } catch (error) {
      console.error('Error submitting new form:', error);
      toast({
        title: "Submission failed",
        description: "Failed to submit new form. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const shouldShowSection = formData.selectedStrand !== 'ALS';
  const shouldShowCOC = formData.gradeLevel === 'Grade 11';

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Submit New Enrollment Form</CardTitle>
          <p className="text-muted-foreground">Update your enrollment information</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Grade Level Selection */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Academic Information</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="gradeLevel">Select Grade Level *</Label>
                  <Select value={formData.gradeLevel} onValueChange={(value) => handleInputChange('gradeLevel', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select grade level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Grade 11">Grade 11</SelectItem>
                      <SelectItem value="Grade 12">Grade 12</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="selectedStrand">Select Strand *</Label>
                  <Select value={formData.selectedStrand} onValueChange={(value) => handleInputChange('selectedStrand', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose your strand" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(STRANDS).map(([category, strands]) => 
                        strands.map(strand => (
                          <SelectItem key={strand} value={strand}>
                            {strand}
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Transfer Student and Balik-Aral Options */}
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="isTransferStudent"
                    checked={formData.isTransferStudent}
                    onCheckedChange={(checked) => handleInputChange('isTransferStudent', checked as boolean)}
                  />
                  <Label htmlFor="isTransferStudent">I am a transfer student</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="isBalikAral"
                    checked={formData.isBalikAral}
                    onCheckedChange={(checked) => handleInputChange('isBalikAral', checked as boolean)}
                  />
                  <Label htmlFor="isBalikAral">Balik-Aral</Label>
                </div>
              </div>

              {/* Transfer Student Fields */}
              {formData.isTransferStudent && (
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="transferSchool">Previous School *</Label>
                    <Input
                      id="transferSchool"
                      value={formData.transferSchool}
                      onChange={(e) => handleInputChange('transferSchool', e.target.value)}
                      required={formData.isTransferStudent}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="transferGrade">Previous Grade *</Label>
                    <Input
                      id="transferGrade"
                      value={formData.transferGrade}
                      onChange={(e) => handleInputChange('transferGrade', e.target.value)}
                      required={formData.isTransferStudent}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="transferSection">Previous Section *</Label>
                    <Input
                      id="transferSection"
                      value={formData.transferSection}
                      onChange={(e) => handleInputChange('transferSection', e.target.value)}
                      required={formData.isTransferStudent}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="transferAdviser">Previous Adviser *</Label>
                    <Input
                      id="transferAdviser"
                      value={formData.transferAdviser}
                      onChange={(e) => handleInputChange('transferAdviser', e.target.value)}
                      required={formData.isTransferStudent}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="transferAverage">General Average *</Label>
                    <Input
                      id="transferAverage"
                      type="number"
                      step="0.01"
                      min="75"
                      max="100"
                      value={formData.transferAverage}
                      onChange={(e) => handleInputChange('transferAverage', e.target.value)}
                      required={formData.isTransferStudent}
                    />
                  </div>
                </div>
              )}

              {/* Regular Previous Academic Info (if not transfer student) */}
              {!formData.isTransferStudent && shouldShowSection && (
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="previousSection">Previous Section</Label>
                    <Input
                      id="previousSection"
                      value={formData.previousSection}
                      onChange={(e) => handleInputChange('previousSection', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="previousAdviser">Previous Adviser</Label>
                    <Input
                      id="previousAdviser"
                      value={formData.previousAdviser}
                      onChange={(e) => handleInputChange('previousAdviser', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="generalAverage">General Average</Label>
                    <Input
                      id="generalAverage"
                      type="number"
                      step="0.01"
                      min="75"
                      max="100"
                      value={formData.generalAverage}
                      onChange={(e) => handleInputChange('generalAverage', e.target.value)}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Required Documents */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Required Documents</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="birthCertificate">Birth Certificate/PSA *</Label>
                  <Input
                    id="birthCertificate"
                    type="file"
                    accept="image/*,.pdf"
                    onChange={(e) => handleFileChange('birthCertificate', e.target.files?.[0] || null)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reportCard">Report Card *</Label>
                  <Input
                    id="reportCard"
                    type="file"
                    accept="image/*,.pdf"
                    onChange={(e) => handleFileChange('reportCard', e.target.files?.[0] || null)}
                    required
                  />
                </div>
                {shouldShowCOC && (
                  <div className="space-y-2">
                    <Label htmlFor="certificateOfCompletion">Certificate of Completion (COC) *</Label>
                    <Input
                      id="certificateOfCompletion"
                      type="file"
                      accept="image/*,.pdf"
                      onChange={(e) => handleFileChange('certificateOfCompletion', e.target.files?.[0] || null)}
                      required={shouldShowCOC}
                    />
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-end space-x-4">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? 'Submitting...' : 'Submit New Form'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};