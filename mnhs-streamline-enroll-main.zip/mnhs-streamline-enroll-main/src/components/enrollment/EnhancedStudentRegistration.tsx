import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Header } from '@/components/layout/Header';
import { saveStudent, checkLRNExists, setCurrentUser } from '@/lib/supabase-storage';
import { EnrollmentFormData, Student, STRANDS } from '@/types/enrollment';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

export const EnhancedStudentRegistration = () => {
  const [formData, setFormData] = useState<EnrollmentFormData>({
    lastName: '',
    firstName: '',
    middleName: '',
    lrn: '',
    dateOfBirth: '',
    placeOfBirth: '',
    zone: '',
    street: '',
    barangay: '',
    city: '',
    province: '',
    gender: 'Male',
    gradeLevel: '',
    previousSection: '',
    previousAdviser: '',
    generalAverage: '',
    mothersMaidenName: '',
    fatherName: '',
    contactNumber: '',
    religion: '',
    is4ps: false,
    isBalikAral: false,
    isTransferStudent: false,
    transferSchool: '',
    transferGrade: '',
    transferSection: '',
    transferAdviser: '',
    transferAverage: '',
    fourPsStudentName: '',
    fourPsParentName: '',
    fourPsIdNumber: '',
    fourPsContactNumber: '',
    selectedStrand: '',
    email: '',
    password: '',
    confirmPassword: '',
    birthCertificate: '',
    reportCard: '',
    reportCardFront: '',
    reportCardBack: '',
    birthCertificateName: '',
    reportCardName: '',
    reportCardFrontName: '',
    reportCardBackName: '',
    certificateOfCompletion: '',
    certificateOfCompletionName: ''
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleInputChange = (field: keyof EnrollmentFormData, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleFileChange = async (field: 'birthCertificate' | 'reportCard' | 'certificateOfCompletion', file: File | null) => {
    if (!file) return;
    
    try {
      const fileName = `${Date.now()}_${file.name}`;
      const { data, error } = await supabase.storage
        .from('student-documents')
        .upload(fileName, file);

      if (error) {
        toast({
          title: "Upload Error",
          description: "Failed to upload file. Please try again.",
          variant: "destructive",
        });
        return;
      }

      setFormData(prev => ({ 
        ...prev, 
        [field]: fileName,
        [`${field}Name`]: file.name
      }));

      toast({
        title: "File Uploaded",
        description: `${file.name} uploaded successfully.`,
      });
    } catch (error) {
      toast({
        title: "Upload Error",
        description: "Failed to upload file. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Validation for required fields
      const requiredFields = [
        'lastName', 'firstName', 'lrn', 'dateOfBirth', 'placeOfBirth',
        'barangay', 'city', 'province', 'gradeLevel', 'mothersMaidenName', 
        'fatherName', 'contactNumber', 'religion', 'selectedStrand'
      ];

      for (const field of requiredFields) {
        const value = formData[field as keyof EnrollmentFormData];
        if (!value || (typeof value === 'string' && value.trim() === '')) {
          toast({
            title: "Missing required field",
            description: `Please fill in the ${field.replace(/([A-Z])/g, ' $1').toLowerCase()} field`,
            variant: "destructive",
          });
          setIsLoading(false);
          return;
        }
      }

      // Transfer student validation
      if (formData.isTransferStudent) {
        const transferFields = ['transferSchool', 'transferGrade', 'transferSection', 'transferAdviser', 'transferAverage'];
        for (const field of transferFields) {
          const value = formData[field as keyof EnrollmentFormData];
          if (!value || (typeof value === 'string' && value.trim() === '')) {
            toast({
              title: "Missing transfer student information",
              description: `Please fill in the ${field.replace(/([A-Z])/g, ' $1').toLowerCase()} field`,
              variant: "destructive",
            });
            setIsLoading(false);
            return;
          }
        }
      }

      if (formData.password !== formData.confirmPassword) {
        toast({
          title: "Password mismatch",
          description: "Passwords do not match",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      if (formData.password.length < 6) {
        toast({
          title: "Password too short",
          description: "Password must be at least 6 characters long",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      const lrnExists = await checkLRNExists(formData.lrn);
      if (lrnExists) {
        toast({
          title: "LRN already exists",
          description: "This LRN is already registered",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      // Check COC requirement for Grade 11 students
      if (formData.gradeLevel === 'Grade 11') {
        if (!formData.certificateOfCompletion || !formData.certificateOfCompletionName) {
          toast({
            title: "Missing Certificate of Completion",
            description: "Certificate of Completion (COC) is required for Grade 11 students",
            variant: "destructive",
          });
          setIsLoading(false);
          return;
        }
      }

      // Convert date format from MM/DD/YYYY to YYYY-MM-DD for database
      let formattedDate = formData.dateOfBirth;
      if (formData.dateOfBirth.includes('/')) {
        const [month, day, year] = formData.dateOfBirth.split('/');
        formattedDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
      }

      const student: Student = {
        lastName: formData.lastName,
        firstName: formData.firstName,
        middleName: formData.middleName || '',
        lrn: formData.lrn,
        dateOfBirth: formattedDate,
        placeOfBirth: formData.placeOfBirth,
        zone: formData.zone || '',
        street: formData.street || '',
        barangay: formData.barangay,
        city: formData.city,
        province: formData.province,
        gender: formData.gender,
        gradeLevel: formData.gradeLevel,
        previousSection: formData.previousSection,
        previousAdviser: formData.previousAdviser,
        generalAverage: formData.generalAverage ? parseFloat(formData.generalAverage) : undefined,
        mothersMaidenName: formData.mothersMaidenName,
        fatherName: formData.fatherName,
        contactNumber: formData.contactNumber,
        religion: formData.religion,
        is4ps: formData.is4ps,
        isBalikAral: formData.isBalikAral,
        isTransferStudent: formData.isTransferStudent,
        transferSchool: formData.isTransferStudent ? formData.transferSchool : undefined,
        transferGrade: formData.isTransferStudent ? formData.transferGrade : undefined,
        transferSection: formData.isTransferStudent ? formData.transferSection : undefined,
        transferAdviser: formData.isTransferStudent ? formData.transferAdviser : undefined,
        transferAverage: formData.isTransferStudent && formData.transferAverage ? parseFloat(formData.transferAverage) : undefined,
        fourPsStudentName: formData.is4ps ? (formData.fourPsStudentName || '') : '',
        fourPsParentName: formData.is4ps ? (formData.fourPsParentName || '') : '',
        fourPsIdNumber: formData.is4ps ? (formData.fourPsIdNumber || '') : '',
        fourPsContactNumber: formData.is4ps ? (formData.fourPsContactNumber || '') : '',
        selectedStrand: formData.selectedStrand,
        enrollmentStatus: 'Pending',
        enrollmentDate: new Date().toISOString(),
        email: formData.email,
        password: formData.password,
        birthCertificate: formData.birthCertificate || '',
        reportCard: formData.reportCard || '',
        reportCardFront: '',
        reportCardBack: '',
        birthCertificateName: formData.birthCertificateName || '',
        reportCardName: formData.reportCardName || '',
        reportCardFrontName: '',
        reportCardBackName: '',
        certificateOfCompletion: formData.certificateOfCompletion || '',
        certificateOfCompletionName: formData.certificateOfCompletionName || ''
      };

      await saveStudent(student);
      await setCurrentUser(student, 'student');
      
      toast({
        title: "Registration successful!",
        description: "Please check your email for a confirmation link to complete your registration.",
      });
      
      navigate('/');
      
    } catch (error) {
      console.error('Registration error details:', error);
      const errorMessage = error instanceof Error ? error.message : "An error occurred during registration. Please try again.";
      toast({
        title: "Registration Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const shouldShowSection = formData.selectedStrand !== 'ALS' && !formData.isTransferStudent;
  const shouldShowCOC = formData.gradeLevel === 'Grade 11';

  return (
    <div className="min-h-screen school-bg">
      <Header title="Student Registration Form" subtitle="New Student Enrollment Form" showLogos={false} />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card className="shadow-lg">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Student Enrollment Form</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Personal Information */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Personal Information</h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name *</Label>
                      <Input
                        id="lastName"
                        value={formData.lastName}
                        onChange={(e) => handleInputChange('lastName', e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name *</Label>
                      <Input
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) => handleInputChange('firstName', e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="middleName">Middle Name</Label>
                      <Input
                        id="middleName"
                        value={formData.middleName}
                        onChange={(e) => handleInputChange('middleName', e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="lrn">Learner Reference Number (LRN) *</Label>
                      <Input
                        id="lrn"
                        value={formData.lrn}
                        onChange={(e) => handleInputChange('lrn', e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="dateOfBirth">Date of Birth *</Label>
                      <Input
                        id="dateOfBirth"
                        type="text"
                        value={formData.dateOfBirth}
                        onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                        placeholder="MM/DD/YYYY"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="placeOfBirth">Place of Birth *</Label>
                      <Input
                        id="placeOfBirth"
                        value={formData.placeOfBirth}
                        onChange={(e) => handleInputChange('placeOfBirth', e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="gender">Gender *</Label>
                      <Select value={formData.gender} onValueChange={(value) => handleInputChange('gender', value as 'Male' | 'Female')}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Male">Male</SelectItem>
                          <SelectItem value="Female">Female</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* Address */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Complete Address</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="zone">Zone</Label>
                      <Input
                        id="zone"
                        value={formData.zone}
                        onChange={(e) => handleInputChange('zone', e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="street">Street</Label>
                      <Input
                        id="street"
                        value={formData.street}
                        onChange={(e) => handleInputChange('street', e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="barangay">Barangay *</Label>
                      <Input
                        id="barangay"
                        value={formData.barangay}
                        onChange={(e) => handleInputChange('barangay', e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="city">Municipality/City *</Label>
                      <Input
                        id="city"
                        value={formData.city}
                        onChange={(e) => handleInputChange('city', e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="province">Province *</Label>
                      <Input
                        id="province"
                        value={formData.province}
                        onChange={(e) => handleInputChange('province', e.target.value)}
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* Academic Information */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Academic Information</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="gradeLevel">Select Grade Level *</Label>
                      <Select value={formData.gradeLevel} onValueChange={(value) => handleInputChange('gradeLevel', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select grade level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Grade 11">Grade 11</SelectItem>
                          <SelectItem value="Grade 12">Grade 12</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="selectedStrand">Select Strand *</Label>
                      <Select value={formData.selectedStrand} onValueChange={(value) => handleInputChange('selectedStrand', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Choose your strand" />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(STRANDS).map(([category, strands]) => 
                            strands.map(strand => (
                              <SelectItem key={strand} value={strand}>
                                {strand}
                              </SelectItem>
                            ))
                          )}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Transfer Student and Balik-Aral */}
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="isTransferStudent"
                        checked={formData.isTransferStudent}
                        onCheckedChange={(checked) => handleInputChange('isTransferStudent', checked as boolean)}
                      />
                      <Label htmlFor="isTransferStudent">I am a transfer student</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="isBalikAral"
                        checked={formData.isBalikAral}
                        onCheckedChange={(checked) => handleInputChange('isBalikAral', checked as boolean)}
                      />
                      <Label htmlFor="isBalikAral">Balik-Aral</Label>
                    </div>
                  </div>

                  {/* Transfer Student Fields */}
                  {formData.isTransferStudent && (
                    <div className="grid md:grid-cols-2 gap-4 p-4 border rounded-lg bg-muted/50">
                      <h4 className="col-span-2 font-medium">Transfer Student Information</h4>
                      <div className="space-y-2">
                        <Label htmlFor="transferSchool">Previous School *</Label>
                        <Input
                          id="transferSchool"
                          value={formData.transferSchool}
                          onChange={(e) => handleInputChange('transferSchool', e.target.value)}
                          required={formData.isTransferStudent}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="transferGrade">Previous Grade *</Label>
                        <Input
                          id="transferGrade"
                          value={formData.transferGrade}
                          onChange={(e) => handleInputChange('transferGrade', e.target.value)}
                          required={formData.isTransferStudent}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="transferSection">Previous Section *</Label>
                        <Input
                          id="transferSection"
                          value={formData.transferSection}
                          onChange={(e) => handleInputChange('transferSection', e.target.value)}
                          required={formData.isTransferStudent}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="transferAdviser">Previous Adviser *</Label>
                        <Input
                          id="transferAdviser"
                          value={formData.transferAdviser}
                          onChange={(e) => handleInputChange('transferAdviser', e.target.value)}
                          required={formData.isTransferStudent}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="transferAverage">General Average *</Label>
                        <Input
                          id="transferAverage"
                          type="number"
                          step="0.01"
                          min="75"
                          max="100"
                          value={formData.transferAverage}
                          onChange={(e) => handleInputChange('transferAverage', e.target.value)}
                          required={formData.isTransferStudent}
                        />
                      </div>
                    </div>
                  )}

                  {/* Regular Previous Academic Info */}
                  {!formData.isTransferStudent && shouldShowSection && (
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="previousSection">Previous Section</Label>
                        <Input
                          id="previousSection"
                          value={formData.previousSection}
                          onChange={(e) => handleInputChange('previousSection', e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="previousAdviser">Previous Adviser</Label>
                        <Input
                          id="previousAdviser"
                          value={formData.previousAdviser}
                          onChange={(e) => handleInputChange('previousAdviser', e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="generalAverage">General Average</Label>
                        <Input
                          id="generalAverage"
                          type="number"
                          step="0.01"
                          min="75"
                          max="100"
                          value={formData.generalAverage}
                          onChange={(e) => handleInputChange('generalAverage', e.target.value)}
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Family Information */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Family Information</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="mothersMaidenName">Mother's Maiden Name *</Label>
                      <Input
                        id="mothersMaidenName"
                        value={formData.mothersMaidenName}
                        onChange={(e) => handleInputChange('mothersMaidenName', e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="fatherName">Father's Complete Name *</Label>
                      <Input
                        id="fatherName"
                        value={formData.fatherName}
                        onChange={(e) => handleInputChange('fatherName', e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="contactNumber">Contact Number *</Label>
                      <Input
                        id="contactNumber"
                        value={formData.contactNumber}
                        onChange={(e) => handleInputChange('contactNumber', e.target.value)}
                        placeholder="09XX-XXX-XXXX"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="religion">Religion *</Label>
                      <Input
                        id="religion"
                        value={formData.religion}
                        onChange={(e) => handleInputChange('religion', e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  {/* 4Ps Information */}
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="is4ps"
                        checked={formData.is4ps}
                        onCheckedChange={(checked) => handleInputChange('is4ps', checked as boolean)}
                      />
                      <Label htmlFor="is4ps">4Ps Beneficiary</Label>
                    </div>
                    
                    {formData.is4ps && (
                      <div className="space-y-4 p-4 border rounded-md bg-muted/50">
                        <h4 className="font-medium">4Ps Details</h4>
                        <div className="grid md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="fourPsStudentName">Name of student:</Label>
                            <Input
                              id="fourPsStudentName"
                              value={formData.fourPsStudentName}
                              onChange={(e) => handleInputChange('fourPsStudentName', e.target.value)}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="fourPsParentName">Name of parent:</Label>
                            <Input
                              id="fourPsParentName"
                              value={formData.fourPsParentName}
                              onChange={(e) => handleInputChange('fourPsParentName', e.target.value)}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="fourPsIdNumber">4Ps ID Number:</Label>
                            <Input
                              id="fourPsIdNumber"
                              value={formData.fourPsIdNumber}
                              onChange={(e) => handleInputChange('fourPsIdNumber', e.target.value)}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="fourPsContactNumber">Contact No.:</Label>
                            <Input
                              id="fourPsContactNumber"
                              value={formData.fourPsContactNumber}
                              onChange={(e) => handleInputChange('fourPsContactNumber', e.target.value)}
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Required Documents */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Required Documents</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="birthCertificate">Birth Certificate/PSA *</Label>
                      <Input
                        id="birthCertificate"
                        type="file"
                        accept="image/*,.pdf"
                        onChange={(e) => handleFileChange('birthCertificate', e.target.files?.[0] || null)}
                        required
                      />
                      {formData.birthCertificateName && (
                        <p className="text-sm text-muted-foreground">✓ {formData.birthCertificateName}</p>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="reportCard">Report Card *</Label>
                      <Input
                        id="reportCard"
                        type="file"
                        accept="image/*,.pdf"
                        onChange={(e) => handleFileChange('reportCard', e.target.files?.[0] || null)}
                        required
                      />
                      {formData.reportCardName && (
                        <p className="text-sm text-muted-foreground">✓ {formData.reportCardName}</p>
                      )}
                    </div>
                    {shouldShowCOC && (
                      <div className="space-y-2">
                        <Label htmlFor="certificateOfCompletion">Certificate of Completion (COC) *</Label>
                        <p className="text-sm text-muted-foreground">Required for Grade 11 students</p>
                        <Input
                          id="certificateOfCompletion"
                          type="file"
                          accept="image/*,.pdf"
                          onChange={(e) => handleFileChange('certificateOfCompletion', e.target.files?.[0] || null)}
                          required={shouldShowCOC}
                        />
                        {formData.certificateOfCompletionName && (
                          <p className="text-sm text-muted-foreground">✓ {formData.certificateOfCompletionName}</p>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Account Security */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Account Security</h3>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        placeholder="Enter your email address"
                        required
                      />
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="password">Password *</Label>
                        <Input
                          id="password"
                          type="password"
                          value={formData.password}
                          onChange={(e) => handleInputChange('password', e.target.value)}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="confirmPassword">Confirm Password *</Label>
                        <Input
                          id="confirmPassword"
                          type="password"
                          value={formData.confirmPassword}
                          onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                          required
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button type="submit" className="flex-1" disabled={isLoading}>
                    {isLoading ? 'Submitting...' : 'Submit Enrollment Form'}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => navigate('/student/login')}
                  >
                    Already have an account?
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};