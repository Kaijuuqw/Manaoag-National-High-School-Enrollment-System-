import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Header } from '@/components/layout/Header';
import { authenticateStudent, setCurrentUser } from '@/lib/supabase-storage';
import { useToast } from '@/hooks/use-toast';
import { Eye, EyeOff } from 'lucide-react';
import { ForgotPasswordModal } from './ForgotPasswordModal';
import { supabase } from '@/integrations/supabase/client';

export const StudentLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const normalizedEmail = email.trim().toLowerCase();

      // 1) Try pending_signups first (account-only users who haven't enrolled yet)
      const { data: pendingResp } = await supabase.functions.invoke('authenticate-pending', {
        body: { email: normalizedEmail, password },
      });

      if (pendingResp?.success && pendingResp?.account) {
        const acc = pendingResp.account;
        const sessionUser: any = {
          id: acc.id,
          firstName: acc.firstName,
          lastName: acc.lastName,
          middleName: '',
          email: acc.email,
          enrollmentStatus: 'Account Created',
          enrollmentDate: new Date().toISOString(),
          isPendingAccount: true,
          lrn: '', dateOfBirth: '', placeOfBirth: '', zone: '', street: '',
          barangay: '', city: '', province: '', gender: 'Male', gradeLevel: '',
          previousSection: '', mothersMaidenName: '', fatherName: '',
          contactNumber: '', religion: '', is4ps: false, selectedStrand: '',
        };
        await setCurrentUser(sessionUser, 'student');
        toast({ title: 'Welcome back!', description: `Hi ${acc.firstName}!` });
        navigate('/student/dashboard');
        return;
      }

      if (pendingResp?.needsVerification) {
        toast({
          title: 'Email not verified',
          description: 'Please verify your email with the 6-digit code first.',
          variant: 'destructive',
        });
        navigate('/student/verify-otp', { state: { email: normalizedEmail } });
        return;
      }

      // 2) Fall back to existing students table (for already-enrolled students)
      const student = await authenticateStudent(email, password);
      if (student) {
        await setCurrentUser(student, 'student');
        toast({ title: 'Login successful', description: `Welcome back, ${student.firstName}!` });
        navigate('/student/dashboard');
      } else {
        toast({ title: 'Login failed', description: 'Invalid email or password', variant: 'destructive' });
      }
    } catch (error: any) {
      console.error('Login error:', error);
      toast({
        title: 'Error',
        description: error.message || 'An error occurred during login',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };


  return (
    <div className="min-h-screen school-bg">
      <Header title="Student Login" subtitle="Access Your Enrollment Dashboard" showLogos={false} />
      
      <div className="container mx-auto px-4 py-12 relative z-10">
        <div className="max-w-md mx-auto">
          <Card className="holographic-card neon-glow">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl neon-text">Student Login</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    placeholder="Enter your email address"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      placeholder="Enter your password"
                      className="pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4 text-muted-foreground" />
                      ) : (
                        <Eye className="h-4 w-4 text-muted-foreground" />
                      )}
                    </Button>
                  </div>
                </div>
                
                <Button 
                  type="submit" 
                  variant="neon"
                  className="w-full" 
                  disabled={isLoading}
                >
                  {isLoading ? 'Logging in...' : 'Login'}
                </Button>

                <div className="flex justify-center">
                  <Button
                    type="button"
                    variant="link"
                    onClick={() => setShowForgotPassword(true)}
                    className="text-sm text-muted-foreground"
                  >
                    Forgot Password?
                  </Button>
                </div>
              </form>
              
              <div className="mt-6 text-center space-y-2">
                <Button
                  variant="outline"
                  onClick={() => navigate('/student/signup')}
                  className="w-full"
                >
                  New Student? Sign Up
                </Button>
                <Button
                  variant="link"
                  onClick={() => navigate('/')}
                  className="text-muted-foreground"
                >
                  Back to Home
                </Button>
              </div>
              
              <ForgotPasswordModal 
                open={showForgotPassword} 
                onOpenChange={setShowForgotPassword}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};