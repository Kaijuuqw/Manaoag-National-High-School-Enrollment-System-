import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Header } from '@/components/layout/Header';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { setCurrentUser } from '@/lib/supabase-storage';

export const VerifyOtp = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const initialEmail = (location.state as any)?.email || '';
  const [email] = useState<string>(initialEmail);
  const [code, setCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isResending, setIsResending] = useState(false);

  useEffect(() => {
    if (!email) {
      navigate('/student/signup');
    }
  }, [email, navigate]);

  const handleVerify = async (otp?: string) => {
    const finalCode = otp ?? code;
    if (finalCode.length !== 6) return;

    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('verify-signup-otp', {
        body: { email, code: finalCode },
      });

      if (error) throw error;
      if (data?.error) {
        toast({ title: 'Verification failed', description: data.error, variant: 'destructive' });
        setCode('');
        return;
      }

      const account = data.account;
      // Build a minimal student-shaped session so dashboard can render.
      const sessionUser: any = {
        id: account.id,
        firstName: account.firstName,
        lastName: account.lastName,
        middleName: '',
        email: account.email,
        // Marker so dashboard knows enrollment hasn't been submitted yet
        enrollmentStatus: 'Account Created',
        enrollmentDate: new Date().toISOString(),
        isPendingAccount: true,
        // Empty placeholders so existing UI doesn't crash
        lrn: '',
        dateOfBirth: '',
        placeOfBirth: '',
        zone: '',
        street: '',
        barangay: '',
        city: '',
        province: '',
        gender: 'Male',
        gradeLevel: '',
        previousSection: '',
        mothersMaidenName: '',
        fatherName: '',
        contactNumber: '',
        religion: '',
        is4ps: false,
        selectedStrand: '',
      };

      await setCurrentUser(sessionUser, 'student');
      toast({ title: 'Email verified!', description: 'Welcome! Continue to your dashboard to enroll.' });
      navigate('/student/dashboard');
    } catch (err: any) {
      console.error('Verify error:', err);
      toast({ title: 'Error', description: err?.message || 'Verification failed.', variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleResend = async () => {
    if (!email) return;
    setIsResending(true);
    try {
      // Re-call signup endpoint requires password — instead, we tell user to go back.
      toast({
        title: 'Need a new code?',
        description: 'Please return to sign up and re-submit to receive a new code.',
      });
    } finally {
      setIsResending(false);
    }
  };

  return (
    <div className="min-h-screen school-bg">
      <Header title="Verify Your Email" subtitle="Step 2 — Enter your 6-digit code" showLogos={false} />
      <div className="container mx-auto px-4 py-12 relative z-10">
        <div className="max-w-md mx-auto">
          <Card className="holographic-card neon-glow">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl neon-text">Enter Verification Code</CardTitle>
              <p className="text-sm text-muted-foreground mt-2">
                We sent a 6-digit code to <strong>{email}</strong>. Enter it below to confirm your email.
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex justify-center">
                <InputOTP
                  maxLength={6}
                  value={code}
                  onChange={(v) => {
                    setCode(v);
                    if (v.length === 6) handleVerify(v);
                  }}
                  disabled={isLoading}
                >
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                    <InputOTPSlot index={3} />
                    <InputOTPSlot index={4} />
                    <InputOTPSlot index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>

              <Button
                variant="neon"
                className="w-full"
                disabled={isLoading || code.length !== 6}
                onClick={() => handleVerify()}
              >
                {isLoading ? 'Verifying...' : 'Verify & Continue'}
              </Button>

              <div className="text-center space-y-2">
                <Button
                  type="button"
                  variant="link"
                  onClick={() => navigate('/student/signup')}
                  disabled={isResending}
                  className="text-sm text-muted-foreground"
                >
                  Didn't receive a code? Resend
                </Button>
                <Button
                  type="button"
                  variant="link"
                  onClick={() => navigate('/student/login')}
                  className="text-sm text-muted-foreground block w-full"
                >
                  Back to Login
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
