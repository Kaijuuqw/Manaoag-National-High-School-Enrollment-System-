import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

import { authenticateAdmin, setCurrentUser } from '@/lib/supabase-storage';
import { useToast } from '@/hooks/use-toast';
import { Eye, EyeOff } from 'lucide-react';

export const AdminLogin = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [secretCode, setSecretCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showSecret, setShowSecret] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [secretRequired, setSecretRequired] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const ADMIN_SECRET_CODE = '01052006';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Step 1: username + password only — prompt for secret code
    if (!secretRequired) {
      if (!username || !password) {
        toast({
          title: "Missing credentials",
          description: "Please enter username and password",
          variant: "destructive",
        });
        return;
      }
      setSecretRequired(true);
      toast({
        title: "Admin, please input the secret code first",
        description: "Enter the admin secret code to continue",
      });
      return;
    }

    // Step 2: validate secret code
    if (secretCode !== ADMIN_SECRET_CODE) {
      toast({
        title: "Access denied",
        description: "Invalid admin secret code",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const adminData = await authenticateAdmin(username, password);

      if (adminData) {
        await setCurrentUser(adminData, 'admin');
        await new Promise(resolve => setTimeout(resolve, 100));

        toast({
          title: "Login successful",
          description: "Welcome back to the admin dashboard",
        });

        navigate('/admin/dashboard', { replace: true });
      } else {
        toast({
          title: "Login failed",
          description: "Invalid username or password",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred during login",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen school-bg flex items-center justify-center">
      <div className="container mx-auto px-4 py-12 relative z-10">
        <div className="max-w-md mx-auto">
          <Card className="holographic-card neon-glow">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl neon-text">Administrator Login</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                    placeholder="Enter admin username"
                    disabled={secretRequired}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      placeholder="Enter admin password"
                      className="pr-10"
                      disabled={secretRequired}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4 text-muted-foreground" />
                      ) : (
                        <Eye className="h-4 w-4 text-muted-foreground" />
                      )}
                    </Button>
                  </div>
                </div>

                {secretRequired && (
                  <div className="space-y-2">
                    <p className="text-sm text-primary font-medium">
                      Admin, please input the secret code first
                    </p>
                    <Label htmlFor="secretCode">Admin Secret Code</Label>
                    <div className="relative">
                      <Input
                        id="secretCode"
                        type={showSecret ? "text" : "password"}
                        value={secretCode}
                        onChange={(e) => setSecretCode(e.target.value)}
                        required
                        autoFocus
                        placeholder="Enter admin secret code"
                        className="pr-10"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                        onClick={() => setShowSecret(!showSecret)}
                      >
                        {showSecret ? (
                          <EyeOff className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <Eye className="h-4 w-4 text-muted-foreground" />
                        )}
                      </Button>
                    </div>
                  </div>
                )}

                <Button
                  type="submit"
                  variant="neon"
                  className="w-full"
                  disabled={isLoading}
                >
                  {isLoading ? 'Logging in...' : secretRequired ? 'Verify & Login' : 'Continue'}
                </Button>

                {secretRequired && (
                  <Button
                    type="button"
                    variant="link"
                    className="w-full text-muted-foreground"
                    onClick={() => {
                      setSecretRequired(false);
                      setSecretCode('');
                    }}
                  >
                    ← Back to edit username/password
                  </Button>
                )}
              </form>

            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
