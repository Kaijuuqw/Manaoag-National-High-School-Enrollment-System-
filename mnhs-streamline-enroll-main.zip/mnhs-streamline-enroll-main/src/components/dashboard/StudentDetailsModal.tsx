import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Student } from '@/types/enrollment';
import { Download, X } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface StudentDetailsModalProps {
  student: Student | null;
  isOpen: boolean;
  onClose: () => void;
  onDownloadDocuments: (student: Student) => void;
}

export const StudentDetailsModal = ({ student, isOpen, onClose, onDownloadDocuments }: StudentDetailsModalProps) => {
  if (!student) return null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Approved':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Denied':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    }
  };

  const getImageUrl = (fileName: string) => {
    if (!fileName) return null;
    
    // If it's already a full URL, return it as-is
    if (fileName.startsWith('http://') || fileName.startsWith('https://')) {
      return fileName;
    }
    
    // Otherwise, clean the filename and construct the URL
    const cleanFileName = fileName.replace(/^\/+/, '').replace(/^student-documents\//, '');
    
    const { data } = supabase.storage
      .from('student-documents')
      .getPublicUrl(cleanFileName);
    
    return data.publicUrl;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Student Details - {student.firstName} {student.lastName}</span>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Basic Information */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold border-b pb-2">Personal Information</h3>
              <div className="grid gap-3">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Full Name</label>
                  <p className="text-sm">{student.firstName} {student.middleName} {student.lastName}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">LRN</label>
                  <p className="text-sm">{student.lrn}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Date of Birth</label>
                  <p className="text-sm">{student.dateOfBirth}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Place of Birth</label>
                  <p className="text-sm">{student.placeOfBirth}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Gender</label>
                  <p className="text-sm">{student.gender}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Religion</label>
                  <p className="text-sm">{student.religion}</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold border-b pb-2">Contact Information</h3>
              <div className="grid gap-3">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Address</label>
                  <p className="text-sm">{student.zone}, {student.street}, {student.barangay}, {student.city}, {student.province}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Contact Number</label>
                  <p className="text-sm">{student.contactNumber}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Mother's Maiden Name</label>
                  <p className="text-sm">{student.mothersMaidenName}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Father's Name</label>
                  <p className="text-sm">{student.fatherName}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Academic Information */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold border-b pb-2">Academic Information</h3>
              <div className="grid gap-3">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Selected Strand</label>
                  <p className="text-sm font-medium">{student.selectedStrand}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Grade Level</label>
                  <p className="text-sm">{student.gradeLevel}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Previous Section</label>
                  <p className="text-sm">{student.previousSection}</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold border-b pb-2">Enrollment Status</h3>
              <div className="grid gap-3">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Status</label>
                  <Badge className={getStatusColor(student.enrollmentStatus)}>
                    {student.enrollmentStatus}
                  </Badge>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Enrollment Date</label>
                  <p className="text-sm">{new Date(student.enrollmentDate).toLocaleDateString()}</p>
                </div>
              </div>
            </div>
          </div>

          {/* 4Ps Information */}
          {student.is4ps && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold border-b pb-2">4Ps Beneficiary Information</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="grid gap-3">
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">4Ps Student Name</label>
                    <p className="text-sm">{student.fourPsStudentName}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">4Ps Parent Name</label>
                    <p className="text-sm">{student.fourPsParentName}</p>
                  </div>
                </div>
                <div className="grid gap-3">
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">4Ps ID Number</label>
                    <p className="text-sm">{student.fourPsIdNumber}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">4Ps Contact Number</label>
                    <p className="text-sm">{student.fourPsContactNumber}</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Documents */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold border-b pb-2">Uploaded Documents</h3>
              <Button onClick={() => onDownloadDocuments(student)} variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Download All Documents
              </Button>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h4 className="font-medium">Birth Certificate</h4>
                {student.birthCertificate && student.birthCertificateName ? (
                  <div className="border rounded-lg p-4">
                    <p className="text-sm text-muted-foreground mb-2">File: {student.birthCertificateName}</p>
                    <img 
                      src={getImageUrl(student.birthCertificate)!} 
                      alt="Birth Certificate" 
                      className="w-full h-48 object-contain border rounded"
                      onError={(e) => {
                        console.error('Failed to load birth certificate image:', student.birthCertificate);
                        const target = e.currentTarget as HTMLImageElement;
                        target.style.display = 'none';
                        const fallback = target.nextElementSibling as HTMLElement;
                        if (fallback) fallback.classList.remove('hidden');
                      }}
                    />
                    <div className="hidden p-4 bg-muted rounded text-center">
                      <p className="text-sm text-muted-foreground">Document not found in storage</p>
                      <p className="text-xs text-muted-foreground mt-1">File: {student.birthCertificateName}</p>
                      <p className="text-xs text-muted-foreground">Note: Files uploaded before storage migration may not be available</p>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">No birth certificate uploaded</p>
                )}
              </div>

              <div className="space-y-3">
                <h4 className="font-medium">Report Card - Front</h4>
                {student.reportCardFront && student.reportCardFrontName ? (
                  <div className="border rounded-lg p-4">
                    <p className="text-sm text-muted-foreground mb-2">File: {student.reportCardFrontName}</p>
                    <img 
                      src={getImageUrl(student.reportCardFront)!} 
                      alt="Report Card Front" 
                      className="w-full h-48 object-contain border rounded"
                      onError={(e) => {
                        console.error('Failed to load report card front image:', student.reportCardFront);
                        const target = e.currentTarget as HTMLImageElement;
                        target.style.display = 'none';
                        const fallback = target.nextElementSibling as HTMLElement;
                        if (fallback) fallback.classList.remove('hidden');
                      }}
                    />
                    <div className="hidden p-4 bg-muted rounded text-center">
                      <p className="text-sm text-muted-foreground">Document not found in storage</p>
                      <p className="text-xs text-muted-foreground mt-1">File: {student.reportCardFrontName}</p>
                      <p className="text-xs text-muted-foreground">Note: Files uploaded before storage migration may not be available</p>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">No report card front uploaded</p>
                )}
              </div>

              <div className="space-y-3">
                <h4 className="font-medium">Report Card - Back</h4>
                {student.reportCardBack && student.reportCardBackName ? (
                  <div className="border rounded-lg p-4">
                    <p className="text-sm text-muted-foreground mb-2">File: {student.reportCardBackName}</p>
                    <img 
                      src={getImageUrl(student.reportCardBack)!} 
                      alt="Report Card Back" 
                      className="w-full h-48 object-contain border rounded"
                      onError={(e) => {
                        console.error('Failed to load report card back image:', student.reportCardBack);
                        const target = e.currentTarget as HTMLImageElement;
                        target.style.display = 'none';
                        const fallback = target.nextElementSibling as HTMLElement;
                        if (fallback) fallback.classList.remove('hidden');
                      }}
                    />
                    <div className="hidden p-4 bg-muted rounded text-center">
                      <p className="text-sm text-muted-foreground">Document not found in storage</p>
                      <p className="text-xs text-muted-foreground mt-1">File: {student.reportCardBackName}</p>
                      <p className="text-xs text-muted-foreground">Note: Files uploaded before storage migration may not be available</p>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">No report card back uploaded</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};