import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Student, STRANDS } from '@/types/enrollment';
import { useToast } from '@/hooks/use-toast';
import { updateStudent } from '@/lib/supabase-storage';
import { Save, X } from 'lucide-react';

interface EditStudentModalProps {
  student: Student | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;
}

export const EditStudentModal = ({ student, isOpen, onClose, onSave }: EditStudentModalProps) => {
  const [editedStudent, setEditedStudent] = useState<Student | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  // Initialize edited student when modal opens
  useEffect(() => {
    if (student && isOpen) {
      setEditedStudent({ ...student });
    }
  }, [student, isOpen]);

  if (!student || !editedStudent) return null;

  const handleSave = async () => {
    setIsLoading(true);
    try {
      await updateStudent(editedStudent.id!, editedStudent);

      toast({
        title: "Student Updated",
        description: "Student information has been successfully updated.",
      });
      
      onSave();
      onClose();
    } catch (error) {
      console.error('Error updating student:', error);
      toast({
        title: "Update Failed", 
        description: `Failed to update student information: ${error instanceof Error ? error.message : 'Unknown error'}. Please try again.`,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const updateField = (field: keyof Student, value: any) => {
    setEditedStudent(prev => prev ? { ...prev, [field]: value } : null);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Edit Student - {student.firstName} {student.lastName}</span>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Personal Information */}
          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="firstName">First Name</Label>
              <Input
                id="firstName"
                value={editedStudent.firstName}
                onChange={(e) => updateField('firstName', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="middleName">Middle Name</Label>
              <Input
                id="middleName"
                value={editedStudent.middleName}
                onChange={(e) => updateField('middleName', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name</Label>
              <Input
                id="lastName"
                value={editedStudent.lastName}
                onChange={(e) => updateField('lastName', e.target.value)}
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="lrn">LRN</Label>
              <Input
                id="lrn"
                value={editedStudent.lrn}
                onChange={(e) => updateField('lrn', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="gender">Gender</Label>
              <Select value={editedStudent.gender} onValueChange={(value) => updateField('gender', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Male">Male</SelectItem>
                  <SelectItem value="Female">Female</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="dateOfBirth">Date of Birth</Label>
              <Input
                id="dateOfBirth"
                type="date"
                value={editedStudent.dateOfBirth}
                onChange={(e) => updateField('dateOfBirth', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="placeOfBirth">Place of Birth</Label>
              <Input
                id="placeOfBirth"
                value={editedStudent.placeOfBirth}
                onChange={(e) => updateField('placeOfBirth', e.target.value)}
              />
            </div>
          </div>

          {/* Address Information */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="zone">Zone</Label>
              <Input
                id="zone"
                value={editedStudent.zone}
                onChange={(e) => updateField('zone', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="street">Street</Label>
              <Input
                id="street"
                value={editedStudent.street}
                onChange={(e) => updateField('street', e.target.value)}
              />
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="barangay">Barangay</Label>
              <Input
                id="barangay"
                value={editedStudent.barangay}
                onChange={(e) => updateField('barangay', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="city">City</Label>
              <Input
                id="city"
                value={editedStudent.city}
                onChange={(e) => updateField('city', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="province">Province</Label>
              <Input
                id="province"
                value={editedStudent.province}
                onChange={(e) => updateField('province', e.target.value)}
              />
            </div>
          </div>

          {/* Academic Information */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="selectedStrand">Selected Strand</Label>
              <Select value={editedStudent.selectedStrand} onValueChange={(value) => updateField('selectedStrand', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ICT">Information and Communications Technology (ICT)</SelectItem>
                  <SelectItem value="Cookery">Cookery</SelectItem>
                  <SelectItem value="EPAS">Electrical Installation and Maintenance (EPAS)</SelectItem>
                  <SelectItem value="ABM">Accountancy, Business, and Management (ABM)</SelectItem>
                  <SelectItem value="HUMSS">Humanities and Social Sciences (HUMSS)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="enrollmentStatus">Enrollment Status</Label>
              <Select value={editedStudent.enrollmentStatus} onValueChange={(value) => updateField('enrollmentStatus', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="Approved">Approved</SelectItem>
                  <SelectItem value="Denied">Denied</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Contact Information */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="contactNumber">Contact Number</Label>
              <Input
                id="contactNumber"
                value={editedStudent.contactNumber}
                onChange={(e) => updateField('contactNumber', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="religion">Religion</Label>
              <Input
                id="religion"
                value={editedStudent.religion}
                onChange={(e) => updateField('religion', e.target.value)}
              />
            </div>
          </div>

          {/* Family Information */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="mothersMaidenName">Mother's Maiden Name</Label>
              <Input
                id="mothersMaidenName"
                value={editedStudent.mothersMaidenName}
                onChange={(e) => updateField('mothersMaidenName', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="fatherName">Father's Name</Label>
              <Input
                id="fatherName"
                value={editedStudent.fatherName}
                onChange={(e) => updateField('fatherName', e.target.value)}
              />
            </div>
          </div>

          {/* 4Ps Information */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Switch
                id="is4ps"
                checked={editedStudent.is4ps}
                onCheckedChange={(checked) => updateField('is4ps', checked)}
              />
              <Label htmlFor="is4ps">4Ps Beneficiary</Label>
            </div>

            {editedStudent.is4ps && (
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fourPsStudentName">4Ps Student Name</Label>
                  <Input
                    id="fourPsStudentName"
                    value={editedStudent.fourPsStudentName}
                    onChange={(e) => updateField('fourPsStudentName', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="fourPsParentName">4Ps Parent Name</Label>
                  <Input
                    id="fourPsParentName"
                    value={editedStudent.fourPsParentName}
                    onChange={(e) => updateField('fourPsParentName', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="fourPsIdNumber">4Ps ID Number</Label>
                  <Input
                    id="fourPsIdNumber"
                    value={editedStudent.fourPsIdNumber}
                    onChange={(e) => updateField('fourPsIdNumber', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="fourPsContactNumber">4Ps Contact Number</Label>
                  <Input
                    id="fourPsContactNumber"
                    value={editedStudent.fourPsContactNumber}
                    onChange={(e) => updateField('fourPsContactNumber', e.target.value)}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end space-x-2 pt-4 border-t">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={isLoading}>
              <Save className="w-4 h-4 mr-2" />
              {isLoading ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};