import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { Header } from '@/components/layout/Header';
import { NewStudentForm } from '@/components/enrollment/NewStudentForm';
import { getCurrentUser, logout } from '@/lib/supabase-storage';
import { Student } from '@/types/enrollment';
import { LogOut, Download, User, BookOpen, MapPin, Phone, Calendar, FileText, ChevronDown, Sparkles, Bell, CheckCircle2, XCircle, Clock } from 'lucide-react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

export const StudentDashboard = () => {
  const [student, setStudent] = useState<Student | null>(null);
  const [showNewForm, setShowNewForm] = useState(false);
  const [lastSeenStatus, setLastSeenStatus] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      const currentUser = await getCurrentUser();
      if (!currentUser || currentUser.type !== 'student') {
        navigate('/student/login');
        return;
      }
      setStudent(currentUser.user as Student);
    };
    checkAuth();
    // Poll for status updates so the bell reflects admin actions
    const interval = setInterval(checkAuth, 10000);
    return () => clearInterval(interval);
  }, [navigate]);

  // Track last-seen notification status per student in localStorage
  useEffect(() => {
    if (student?.id) {
      const key = `mnhs_seen_status_${student.id}`;
      setLastSeenStatus(localStorage.getItem(key));
    }
  }, [student?.id]);

  const markNotificationsRead = () => {
    if (student?.id) {
      const key = `mnhs_seen_status_${student.id}`;
      localStorage.setItem(key, student.enrollmentStatus);
      setLastSeenStatus(student.enrollmentStatus);
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const handleDownloadForm = () => {
    // Generate PDF or print functionality would go here
    window.print();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Approved':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Denied':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    }
  };

  if (!student) {
    return <div>Loading...</div>;
  }

  const isPendingAccount = (student as any).isPendingAccount === true || student.enrollmentStatus === ('Account Created' as any);

  return (
    <div className="min-h-screen school-bg">
      <Header title={`Welcome, ${student.firstName}!`} subtitle="Student Dashboard" />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Dashboard</h2>
          <div className="flex items-center gap-2">
            {/* Notifications */}
            <Popover onOpenChange={(open) => { if (!open) markNotificationsRead(); }}>
              <PopoverTrigger asChild>
                <button
                  className="relative flex items-center justify-center h-10 w-10 border border-border/50 hover:border-primary/50 rounded-xl bg-card/50 transition-all duration-300"
                  aria-label="Notifications"
                  onClick={() => { /* mark read after view */ }}
                >
                  <Bell className="w-4 h-4" />
                  {!isPendingAccount && lastSeenStatus !== student.enrollmentStatus && (
                    <span className="absolute -top-1 -right-1 h-4 min-w-4 px-1 rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold flex items-center justify-center">
                      1
                    </span>
                  )}
                </button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-80 p-0">
                <div className="px-4 py-3 border-b border-border/50">
                  <p className="font-semibold text-sm">Notifications</p>
                </div>
                <div className="max-h-80 overflow-y-auto">
                  {isPendingAccount ? (
                    <div className="p-4 text-sm text-muted-foreground">No notifications yet. Complete your enrollment to receive updates.</div>
                  ) : student.enrollmentStatus === 'Approved' ? (
                    <div className="p-4 flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Enrollment Approved 🎉</p>
                        <p className="text-xs text-muted-foreground mt-1">Your enrollment application has been approved by the administrator.</p>
                      </div>
                    </div>
                  ) : student.enrollmentStatus === 'Denied' ? (
                    <div className="p-4 flex items-start gap-3">
                      <XCircle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Enrollment Rejected</p>
                        <p className="text-xs text-muted-foreground mt-1">Your enrollment application was denied. Please submit a new form.</p>
                      </div>
                    </div>
                  ) : (
                    <div className="p-4 flex items-start gap-3">
                      <Clock className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Application Pending</p>
                        <p className="text-xs text-muted-foreground mt-1">Your enrollment is under review. You'll be notified once it's processed.</p>
                      </div>
                    </div>
                  )}
                </div>
              </PopoverContent>
            </Popover>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 border border-border/50 hover:border-primary/50 rounded-xl px-3 py-2 transition-all duration-300 bg-card/50">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-white text-xs font-bold">
                      {student.firstName.charAt(0)}{student.lastName.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-sm font-medium hidden sm:inline">{student.firstName} {student.lastName}</span>
                  <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <div className="px-3 py-2 border-b border-border/50">
                  <p className="text-sm font-medium">{student.firstName} {student.lastName}</p>
                  <p className="text-xs text-muted-foreground">Student</p>
                </div>
                <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive cursor-pointer mt-1">
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {isPendingAccount && (
          <Card className="mb-6 border-primary/40 bg-gradient-to-br from-primary/5 to-accent/5">
            <CardContent className="p-6 flex flex-col md:flex-row md:items-center gap-4 justify-between">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-full bg-primary/10 text-primary">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Your account is verified! 🎉</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Next step: complete your enrollment form to apply to MNHS Senior High School.
                  </p>
                </div>
              </div>
              <Button size="lg" onClick={() => navigate('/student/register')} className="shrink-0">
                <FileText className="w-4 h-4 mr-2" />
                Enroll Now
              </Button>
            </CardContent>
          </Card>
        )}

        {!isPendingAccount && (
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Enrollment Status */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center">
                <BookOpen className="w-5 h-5 mr-2" />
                Enrollment Status
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <Badge className={getStatusColor(student.enrollmentStatus)}>
                  {student.enrollmentStatus}
                </Badge>
              </div>
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">
                  <strong>Selected Strand:</strong>
                </p>
                <p className="text-sm">{student.selectedStrand}</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">
                  <strong>Enrollment Date:</strong>
                </p>
                <p className="text-sm">{new Date(student.enrollmentDate).toLocaleDateString()}</p>
              </div>
              {student.enrollmentStatus === 'Approved' && (
                <Button onClick={handleDownloadForm} className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Download Enrollment Form
                </Button>
              )}
              {student.enrollmentStatus === 'Denied' && (
                <Dialog open={showNewForm} onOpenChange={setShowNewForm}>
                  <DialogTrigger asChild>
                    <Button className="w-full">
                      <FileText className="w-4 h-4 mr-2" />
                      Submit a New Form
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
                    <NewStudentForm 
                      existingStudent={student} 
                      onClose={() => setShowNewForm(false)} 
                    />
                  </DialogContent>
                </Dialog>
              )}
            </CardContent>
          </Card>

          {/* Personal Information */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="w-5 h-5 mr-2" />
                Personal Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Full Name</p>
                    <p className="font-medium">{`${student.firstName} ${student.middleName} ${student.lastName}`}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">LRN</p>
                    <p className="font-medium">{student.lrn}</p>
                  </div>
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-2 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Date of Birth</p>
                      <p className="font-medium">{new Date(student.dateOfBirth).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Gender</p>
                    <p className="font-medium">{student.gender}</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-start">
                    <MapPin className="w-4 h-4 mr-2 text-muted-foreground mt-1" />
                    <div>
                      <p className="text-sm text-muted-foreground">Address</p>
                      <p className="font-medium text-sm">
                        {[student.zone, student.street, student.barangay, student.city, student.province]
                          .filter(Boolean)
                          .join(', ')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Phone className="w-4 h-4 mr-2 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Contact Number</p>
                      <p className="font-medium">{student.contactNumber}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Grade Level</p>
                    <p className="font-medium">{student.gradeLevel || 'Not specified'}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Family Information */}
          <Card className="lg:col-span-3">
            <CardHeader>
              <CardTitle>Family Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                <div>
                  <p className="text-sm text-muted-foreground">Mother's Maiden Name</p>
                  <p className="font-medium">{student.mothersMaidenName}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Father's Name</p>
                  <p className="font-medium">{student.fatherName}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Religion</p>
                  <p className="font-medium">{student.religion}</p>
                </div>
              </div>
              {student.is4ps && (
                <div className="mt-4 p-3 bg-accent/10 rounded-lg">
                  <p className="text-sm font-medium text-accent-foreground">4Ps Beneficiary</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        )}
      </div>
    </div>
  );
};