import { useEffect, useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Header } from '@/components/layout/Header';
import { StudentDetailsModal } from './StudentDetailsModal';
import { EditStudentModal } from './EditStudentModal';
import { getCurrentUser, logout, getStudents, saveStudent, deleteStudent, updateStudentStatus } from '@/lib/supabase-storage';
import { Student, STRANDS } from '@/types/enrollment';
import { LogOut, Search, Filter, Users, CheckCircle, XCircle, Clock, Download, ChevronDown, Trash2, Eye, Edit, TrendingUp, GraduationCap, AlertTriangle, RefreshCw, FileSpreadsheet, FileText, Usb, BarChart3, Activity, UserCircle } from 'lucide-react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useToast } from '@/hooks/use-toast';
import { saveAs } from 'file-saver';
import * as XLSX from 'xlsx';
import { Document as DocxDocument, Packer, Paragraph, Table as DocxTable, TableCell as DocxTableCell, TableRow as DocxTableRow, WidthType, AlignmentType, HeadingLevel, TextRun } from 'docx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { supabase } from '@/integrations/supabase/client';
import { motion, AnimatePresence } from 'framer-motion';

const MotionCard = motion.create(Card);

// Animated counter component
const AnimatedNumber = ({ value }: { value: number }) => {
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    const duration = 600;
    const start = performance.now();
    const from = display;
    const animate = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(Math.round(from + (value - from) * eased));
      if (progress < 1) requestAnimationFrame(animate);
    };
    requestAnimationFrame(animate);
  }, [value]);
  return <>{display}</>;
};

// Progress ring component
const ProgressRing = ({ percentage, color, size = 48 }: { percentage: number; color: string; size?: number }) => {
  const strokeWidth = 4;
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (percentage / 100) * circumference;
  
  return (
    <svg width={size} height={size} className="transform -rotate-90">
      <circle cx={size/2} cy={size/2} r={radius} fill="none" stroke="hsl(var(--muted))" strokeWidth={strokeWidth} />
      <circle 
        cx={size/2} cy={size/2} r={radius} fill="none" 
        stroke={color} strokeWidth={strokeWidth} strokeLinecap="round"
        strokeDasharray={circumference} strokeDashoffset={offset}
        className="transition-all duration-1000 ease-out"
      />
    </svg>
  );
};

export const AdminDashboard = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [filteredStudents, setFilteredStudents] = useState<Student[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [strandFilter, setStrandFilter] = useState('All');
  const [gradeLevelFilter, setGradeLevelFilter] = useState('All');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [adminName, setAdminName] = useState('Admin');
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const checkAuth = async () => {
      const currentUser = await getCurrentUser();
      if (!currentUser || currentUser.type !== 'admin') {
        navigate('/');
        return;
      }
      if ((currentUser.user as any)?.full_name) setAdminName((currentUser.user as any).full_name);
      else if ((currentUser.user as any)?.username) setAdminName((currentUser.user as any).username);
      loadStudents();
    };
    checkAuth();
    const interval = setInterval(() => loadStudents(), 3000);
    return () => clearInterval(interval);
  }, [navigate]);

  useEffect(() => {
    filterStudents();
  }, [students, searchTerm, statusFilter, strandFilter, gradeLevelFilter]);

  const loadStudents = async () => {
    try {
      const allStudents = await getStudents();
      setStudents(allStudents);
    } catch (error) {
      // Silent
    }
  };

  const refreshStudents = async () => {
    setIsRefreshing(true);
    await loadStudents();
    setTimeout(() => setIsRefreshing(false), 800);
    toast({ title: "Students refreshed", description: "Student list has been updated" });
  };

  const filterStudents = () => {
    let filtered = students;
    if (searchTerm) {
      filtered = filtered.filter(student =>
        `${student.firstName} ${student.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.lrn.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    if (statusFilter !== 'All') {
      filtered = filtered.filter(student => student.enrollmentStatus === statusFilter);
    }
    if (strandFilter !== 'All') {
      filtered = filtered.filter(student => student.selectedStrand === strandFilter);
    }
    if (gradeLevelFilter !== 'All') {
      filtered = filtered.filter(student => student.gradeLevel === gradeLevelFilter);
    }
    setFilteredStudents(filtered);
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const handleStatusUpdate = async (studentId: string, status: 'Approved' | 'Denied') => {
    setIsLoading(true);
    try {
      const student = students.find(s => s.id === studentId);
      await updateStudentStatus(studentId, status);
      if (student?.email) {
        try {
          const { error: emailError } = await supabase.functions.invoke('send-enrollment-notification', {
            body: { email: student.email, studentName: `${student.firstName} ${student.lastName}`, status: status.toLowerCase() }
          });
          if (emailError) {
            toast({ title: "Email Error", description: `Status updated but email failed: ${emailError.message}`, variant: "destructive" });
          }
        } catch (emailError: any) {
          toast({ title: "Email Error", description: `Status updated but email failed: ${emailError.message}`, variant: "destructive" });
        }
      }
      await loadStudents();
      toast({ title: `Student ${status}`, description: `Student enrollment has been ${status.toLowerCase()} and notification sent` });
    } catch (error) {
      toast({ title: "Error", description: "Failed to update student status", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteStudent = async (studentId: string) => {
    setIsLoading(true);
    try {
      await deleteStudent(studentId);
      await loadStudents();
      toast({ title: "Student deleted", description: "Student record has been removed" });
    } catch (error) {
      toast({ title: "Error", description: "Failed to delete student", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const exportApprovedPDF = () => {
    try {
      const approved = students.filter(s => s.enrollmentStatus === 'Approved');
      if (approved.length === 0) {
        toast({ title: 'No Approved Students', description: 'There are no approved enrollments to export yet.', variant: 'destructive' });
        return;
      }

      const doc = new jsPDF({ unit: 'pt', format: 'a4' });
      const pageWidth = doc.internal.pageSize.getWidth();
      const today = new Date().toLocaleDateString();

      // Cover header
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text('Manaoag National High School', pageWidth / 2, 50, { align: 'center' });
      doc.setFontSize(12);
      doc.setFont('helvetica', 'normal');
      doc.text('Senior High School - Approved Enrollment Report', pageWidth / 2, 70, { align: 'center' });
      doc.setFontSize(10);
      doc.text(`Generated: ${today}  •  Total Approved: ${approved.length}`, pageWidth / 2, 88, { align: 'center' });

      let cursorY = 110;
      const grades = ['Grade 11', 'Grade 12'];

      grades.forEach((grade, gi) => {
        const gradeStudents = approved.filter(s => s.gradeLevel === grade);
        if (gradeStudents.length === 0) return;

        if (gi > 0) {
          doc.addPage();
          cursorY = 50;
        }

        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        doc.text(`${grade}  (${gradeStudents.length})`, 40, cursorY);
        cursorY += 8;

        // Group by strand
        const strandsForGrade = Array.from(new Set(gradeStudents.map(s => s.selectedStrand))).sort();

        strandsForGrade.forEach(strand => {
          const list = gradeStudents
            .filter(s => s.selectedStrand === strand)
            .sort((a, b) => {
              const ln = a.lastName.localeCompare(b.lastName);
              return ln !== 0 ? ln : a.firstName.localeCompare(b.firstName);
            });

          autoTable(doc, {
            startY: cursorY + 12,
            head: [[`${strand} — ${list.length} student${list.length > 1 ? 's' : ''}`]],
            body: [],
            theme: 'plain',
            headStyles: { fontStyle: 'bold', fontSize: 11, fillColor: [230, 230, 240], textColor: 20 },
            margin: { left: 40, right: 40 },
          });

          autoTable(doc, {
            startY: (doc as any).lastAutoTable.finalY + 2,
            head: [['#', 'Full Name', 'LRN', 'Gender', 'Contact']],
            body: list.map((s, i) => [
              String(i + 1),
              `${s.lastName}, ${s.firstName}${s.middleName ? ' ' + s.middleName.charAt(0) + '.' : ''}`,
              s.lrn,
              s.gender,
              s.contactNumber || '—',
            ]),
            styles: { fontSize: 9, cellPadding: 4 },
            headStyles: { fillColor: [40, 40, 60], textColor: 255 },
            alternateRowStyles: { fillColor: [248, 248, 252] },
            margin: { left: 40, right: 40 },
          });

          cursorY = (doc as any).lastAutoTable.finalY + 16;
          if (cursorY > doc.internal.pageSize.getHeight() - 80) {
            doc.addPage();
            cursorY = 50;
          }
        });
      });

      // Footer page numbers
      const pageCount = (doc as any).internal.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor(120);
        doc.text(`Page ${i} of ${pageCount}`, pageWidth / 2, doc.internal.pageSize.getHeight() - 20, { align: 'center' });
      }

      doc.save(`mnhs_approved_enrollments_${new Date().toISOString().split('T')[0]}.pdf`);
      toast({ title: 'PDF Generated', description: `${approved.length} approved students exported to PDF.` });
    } catch (e: any) {
      console.error(e);
      toast({ title: 'PDF Failed', description: e?.message || 'Failed to generate PDF.', variant: 'destructive' });
    }
  };

  const exportStudents = async (format: 'excel' | 'word' | 'usb') => {
    try {
      const fileName = `mnhs_enrollments_${new Date().toISOString().split('T')[0]}`;
      
      if (format === 'excel' || format === 'usb') {
        const ws_data = [
          ['Last Name', 'First Name', 'Middle Name', 'Learners Reference Number (LRN)', 'Date of Birth', 'Place of Birth', 'Gender', 'Religion', 'Address', 'Grade Level to Enroll', 'Strand', 'Previous Grade/Section', 'Previous Adviser', 'Previous General Average', 'Transfer', 'Transfer Detail', 'Balik Aral', "Mother's Maiden Name", "Father's Complete Name", 'Contact Number', '4Ps Beneficiary', '4Ps Details', 'Enrollment Date', 'Status', 'Birth Certificate Image', 'Report Card Front Image', 'Report Card Back Image', 'Certificate Of Completion Image'],
          ...filteredStudents.map(student => {
            const address = [student.zone, student.street, student.barangay, student.city, student.province].filter(Boolean).join(', ');
            const prevGradeSection = [student.gradeLevel, student.previousSection].filter(Boolean).join(' / ');
            const isTransfer = (student as any).isTransferStudent ? 'Yes' : 'No';
            const transferDetail = (student as any).isTransferStudent ? `School: ${(student as any).transferSchool || ''}, Grade: ${(student as any).transferGrade || ''}, Section: ${(student as any).transferSection || ''}, Adviser: ${(student as any).transferAdviser || ''}, Average: ${(student as any).transferAverage || ''}` : '';
            const isBalikAral = (student as any).isBalikAral ? 'Yes' : 'No';
            return [student.lastName, student.firstName, student.middleName || '', student.lrn, student.dateOfBirth, student.placeOfBirth || '', student.gender, student.religion || '', address, student.gradeLevel || '', student.selectedStrand, prevGradeSection, (student as any).previousAdviser || '', (student as any).generalAverage ?? '', isTransfer, transferDetail, isBalikAral, student.mothersMaidenName || '', student.fatherName || '', student.contactNumber || '', student.is4ps ? 'Yes' : 'No', student.is4ps ? `Student: ${student.fourPsStudentName || ''}, Parent: ${student.fourPsParentName || ''}, ID: ${student.fourPsIdNumber || ''}, Contact: ${student.fourPsContactNumber || ''}` : '', new Date(student.enrollmentDate).toLocaleDateString(), student.enrollmentStatus, student.birthCertificate || '', student.reportCardFront || '', student.reportCardBack || '', student.certificateOfCompletion || ''];
          })
        ];
        const ws = XLSX.utils.aoa_to_sheet(ws_data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Students");
        XLSX.writeFile(wb, `${fileName}.xlsx`);
      } else if (format === 'word') {
        const tableHeaders = new DocxTableRow({
          children: ['Last Name','First Name','Middle Name','LRN','Gender','Date of Birth','Contact Number','Strand','Status','4Ps'].map((text, i) => 
            new DocxTableCell({ children: [new Paragraph({ children: [new TextRun({ text, bold: true })] })], width: { size: 10, type: WidthType.PERCENTAGE } })
          ),
        });
        const tableRows = filteredStudents.map(student =>
          new DocxTableRow({
            children: [student.lastName, student.firstName, student.middleName, student.lrn, student.gender, student.dateOfBirth, student.contactNumber, student.selectedStrand, student.enrollmentStatus, student.is4ps ? 'Yes' : 'No'].map(text =>
              new DocxTableCell({ children: [new Paragraph(text || '')] })
            ),
          })
        );
        const table = new DocxTable({ rows: [tableHeaders, ...tableRows], width: { size: 100, type: WidthType.PERCENTAGE } });
        const doc = new DocxDocument({
          sections: [{ properties: {}, children: [
            new Paragraph({ text: "Manaoag National High School, Senior High School", heading: HeadingLevel.HEADING_1, alignment: AlignmentType.CENTER }),
            new Paragraph({ text: "Student Enrollment Report", heading: HeadingLevel.HEADING_2, alignment: AlignmentType.CENTER }),
            new Paragraph({ text: `Generated on: ${new Date().toLocaleDateString()}`, alignment: AlignmentType.CENTER }),
            new Paragraph({ text: `Total Students: ${filteredStudents.length}`, alignment: AlignmentType.CENTER }),
            new Paragraph(""),
            table,
          ]}],
        });
        const buffer = await Packer.toBlob(doc);
        saveAs(buffer, `${fileName}.docx`);
      }
      toast({ title: "Export Successful", description: `${filteredStudents.length} students exported to ${format.toUpperCase()} format successfully.` });
    } catch (error) {
      toast({ title: "Export Failed", description: "Failed to export student data. Please try again.", variant: "destructive" });
    }
  };

  const downloadStudentDocuments = (student: Student) => {
    let downloadCount = 0;
    const docs = [
      { url: student.birthCertificate, name: student.birthCertificateName, label: 'Birth_Certificate' },
      { url: student.reportCardFront, name: student.reportCardFrontName, label: 'Report_Card_Front' },
      { url: student.reportCardBack, name: student.reportCardBackName, label: 'Report_Card_Back' },
    ];
    const available = docs.filter(d => d.url && d.name);
    if (available.length === 0) {
      toast({ title: "No Documents", description: "No documents available for this student", variant: "destructive" });
      return;
    }
    available.forEach(doc => {
      fetch(doc.url!).then(res => res.blob()).then(blob => {
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${student.firstName}_${student.lastName}_${doc.label}.${doc.name!.split('.').pop() || 'jpg'}`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
        downloadCount++;
        if (downloadCount === available.length) {
          toast({ title: "Documents Downloaded", description: `Downloaded ${downloadCount} document(s) for ${student.firstName} ${student.lastName}` });
        }
      }).catch(() => {
        toast({ title: "Download Error", description: `Failed to download ${doc.label}`, variant: "destructive" });
      });
    });
  };

  const handleViewStudent = (student: Student) => { setSelectedStudent(student); setIsModalOpen(true); };
  const handleEditStudent = (student: Student) => { setSelectedStudent(student); setIsEditModalOpen(true); };
  const handleCloseModal = () => { setIsModalOpen(false); setSelectedStudent(null); };
  const handleCloseEditModal = () => { setIsEditModalOpen(false); setSelectedStudent(null); };
  const handleSaveStudent = () => { loadStudents(); };

  const getStatusBadge = (status: string) => {
    const config: Record<string, { bg: string; text: string; icon: JSX.Element; glow: string }> = {
      Approved: { bg: 'bg-emerald-500/15', text: 'text-emerald-400', icon: <CheckCircle className="w-3.5 h-3.5" />, glow: 'shadow-[0_0_8px_hsl(160,60%,40%/0.3)]' },
      Denied: { bg: 'bg-red-500/15', text: 'text-red-400', icon: <XCircle className="w-3.5 h-3.5" />, glow: 'shadow-[0_0_8px_hsl(0,60%,50%/0.3)]' },
      Pending: { bg: 'bg-amber-500/15', text: 'text-amber-400', icon: <Clock className="w-3.5 h-3.5" />, glow: 'shadow-[0_0_8px_hsl(40,60%,50%/0.3)]' },
    };
    const c = config[status] || config.Pending;
    return (
      <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${c.bg} ${c.text} ${c.glow} border border-current/20`}>
        {c.icon} {status}
      </span>
    );
  };

  const stats = {
    total: students.length,
    pending: students.filter(s => s.enrollmentStatus === 'Pending').length,
    approved: students.filter(s => s.enrollmentStatus === 'Approved').length,
    denied: students.filter(s => s.enrollmentStatus === 'Denied').length,
  };

  const strandStats = {
    'TVL - ICT': students.filter(s => s.selectedStrand === 'TVL - ICT' || s.selectedStrand === 'TVL-ICT' || s.selectedStrand === 'ICT').length,
    'TVL - BPP': students.filter(s => s.selectedStrand === 'TVL - BPP' || s.selectedStrand === 'TVL-BPP' || s.selectedStrand === 'BPP').length,
    'TVL - COOKERY': students.filter(s => s.selectedStrand === 'TVL - COOKERY' || s.selectedStrand === 'TVL-COOKERY' || s.selectedStrand === 'COOKERY').length,
    'TVL - EPAS': students.filter(s => s.selectedStrand === 'TVL - EPAS' || s.selectedStrand === 'TVL-EPAS' || s.selectedStrand === 'EPAS').length,
    'ABM': students.filter(s => s.selectedStrand === 'ABM').length,
    'HUMSS': students.filter(s => s.selectedStrand === 'HUMSS').length,
    'STEM': students.filter(s => s.selectedStrand === 'STEM').length,
    'ALS': students.filter(s => s.selectedStrand === 'ALS').length,
    'balikAral': students.filter(s => s.isBalikAral).length,
    'transfer': students.filter(s => s.isTransferStudent).length,
    '4ps': students.filter(s => s.is4ps).length,
  };

  const handleStrandFilter = (strand: string) => {
    setStrandFilter(strand);
    setSearchTerm('');
    setStatusFilter('All');
  };

  const approvalRate = stats.total > 0 ? Math.round((stats.approved / stats.total) * 100) : 0;

  const statCards = [
    { label: 'Total Students', value: stats.total, icon: Users, gradient: 'from-[hsl(var(--neon-pink))] to-[hsl(var(--neon-purple))]', iconBg: 'bg-[hsl(var(--neon-pink)/0.2)]' },
    { label: 'Pending Review', value: stats.pending, icon: Clock, gradient: 'from-amber-500 to-orange-500', iconBg: 'bg-amber-500/20' },
    { label: 'Approved', value: stats.approved, icon: CheckCircle, gradient: 'from-emerald-500 to-teal-500', iconBg: 'bg-emerald-500/20' },
    { label: 'Denied', value: stats.denied, icon: XCircle, gradient: 'from-red-500 to-rose-500', iconBg: 'bg-red-500/20' },
  ];

  return (
    <div className="min-h-screen school-bg">
      <Header title="Admin Dashboard" subtitle="Enrollment Management System" showLogos={false} className="[&_h1]:text-white [&_p]:text-white/90" />
      
      <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Top Bar */}
        <motion.div 
          initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
          className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4"
        >
          <div>
            <h2 className="text-2xl font-bold bg-gradient-to-r from-[hsl(var(--neon-pink))] to-[hsl(var(--neon-cyan))] bg-clip-text text-transparent">
              Enrollment Management
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              <Activity className="w-3.5 h-3.5 inline mr-1" />
              {stats.pending > 0 ? `${stats.pending} application${stats.pending > 1 ? 's' : ''} awaiting review` : 'All applications reviewed'}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Button onClick={refreshStudents} variant="outline" size="sm" className="glass-effect border-primary/20 hover:border-primary/50">
              <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            {/* Admin Profile Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 glass-effect border border-primary/20 hover:border-primary/50 rounded-xl px-3 py-2 transition-all duration-300">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-gradient-to-br from-[hsl(var(--neon-pink))] to-[hsl(var(--neon-purple))] text-white text-xs font-bold">
                      {adminName.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-sm font-medium text-foreground hidden sm:inline">{adminName}</span>
                  <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <div className="px-3 py-2 border-b border-border/50">
                  <p className="text-sm font-medium">{adminName}</p>
                  <p className="text-xs text-muted-foreground">Administrator</p>
                </div>
                <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive cursor-pointer mt-1">
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </motion.div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {statCards.map((stat, i) => (
            <MotionCard
              key={stat.label}
              initial={{ opacity: 0, y: 20 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ delay: i * 0.1 }}
              className="glass-effect overflow-hidden group hover:scale-[1.02] transition-transform duration-300"
            >
              <CardContent className="p-5 relative">
                {/* Gradient accent line */}
                <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${stat.gradient} opacity-80`} />
                
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{stat.label}</p>
                    <p className="text-3xl font-bold text-foreground">
                      <AnimatedNumber value={stat.value} />
                    </p>
                    {stat.label === 'Total Students' && (
                      <p className="text-xs text-muted-foreground">
                        <TrendingUp className="w-3 h-3 inline mr-1 text-emerald-400" />
                        {approvalRate}% approval rate
                      </p>
                    )}
                  </div>
                  <div className={`${stat.iconBg} p-3 rounded-xl`}>
                    <stat.icon className={`w-5 h-5 bg-gradient-to-r ${stat.gradient} bg-clip-text`} style={{ color: 'inherit' }} />
                  </div>
                </div>
                
                {/* Mini progress bar */}
                {stat.label !== 'Total Students' && stats.total > 0 && (
                  <div className="mt-3">
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${(stat.value / stats.total) * 100}%` }}
                        transition={{ duration: 1, delay: 0.3 + i * 0.1 }}
                        className={`h-full rounded-full bg-gradient-to-r ${stat.gradient}`}
                      />
                    </div>
                    <p className="text-[10px] text-muted-foreground mt-1">{stats.total > 0 ? Math.round((stat.value / stats.total) * 100) : 0}% of total</p>
                  </div>
                )}
              </CardContent>
            </MotionCard>
          ))}
        </div>

        {/* Strand Statistics */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card className="glass-effect overflow-hidden">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-[hsl(var(--neon-cyan)/0.15)]">
                    <BarChart3 className="w-5 h-5 text-[hsl(var(--neon-cyan))]" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">Enrollment by Strand</CardTitle>
                    <p className="text-xs text-muted-foreground mt-0.5">Select a strand and grade level to filter</p>
                  </div>
                </div>
                {(strandFilter !== 'All' || gradeLevelFilter !== 'All' || filteredStudents.length !== students.length) && (
                  <Button variant="ghost" size="sm" onClick={() => { setStrandFilter('All'); setGradeLevelFilter('All'); setSearchTerm(''); setStatusFilter('All'); }}
                    className="text-xs text-primary hover:text-primary/80">
                    Clear Filters
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
                {[
                  { key: 'TVL - ICT', color: 'from-blue-500 to-cyan-500' },
                  { key: 'TVL - BPP', color: 'from-violet-500 to-purple-500' },
                  { key: 'TVL - COOKERY', color: 'from-orange-500 to-amber-500' },
                  { key: 'TVL - EPAS', color: 'from-teal-500 to-emerald-500' },
                  { key: 'ABM', color: 'from-pink-500 to-rose-500' },
                  { key: 'HUMSS', color: 'from-indigo-500 to-blue-500' },
                  { key: 'STEM', color: 'from-cyan-500 to-sky-500' },
                  { key: 'ALS', color: 'from-lime-500 to-green-500' },
                ].map((strand) => {
                  const isActive = strandFilter === strand.key;
                  const g11Count = students.filter(s => (s.selectedStrand === strand.key || s.selectedStrand === strand.key.replace(' - ', '-') || s.selectedStrand === strand.key.split(' - ')[1]) && s.gradeLevel === 'Grade 11').length;
                  const g12Count = students.filter(s => (s.selectedStrand === strand.key || s.selectedStrand === strand.key.replace(' - ', '-') || s.selectedStrand === strand.key.split(' - ')[1]) && s.gradeLevel === 'Grade 12').length;
                  return (
                    <DropdownMenu key={strand.key}>
                      <DropdownMenuTrigger asChild>
                        <button
                          className={`group relative flex flex-col items-center justify-center h-24 rounded-xl border transition-all duration-300 overflow-hidden w-full
                            ${isActive 
                              ? 'border-primary/60 bg-primary/10 scale-[1.02]' 
                              : 'border-border/50 bg-card/40 hover:border-primary/30 hover:bg-card/60'}
                          `}
                        >
                          <div className={`absolute inset-0 bg-gradient-to-br ${strand.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />
                          <span className={`text-3xl font-bold bg-gradient-to-r ${strand.color} bg-clip-text text-transparent`}>
                            {strandStats[strand.key as keyof typeof strandStats] || 0}
                          </span>
                          <div className="flex items-center gap-1 mt-1.5">
                            <span className="text-[11px] font-medium text-muted-foreground tracking-wide">{strand.key}</span>
                            <ChevronDown className="w-3 h-3 text-muted-foreground" />
                          </div>
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="center" className="w-44">
                        <DropdownMenuItem onClick={() => { handleStrandFilter(strand.key); setGradeLevelFilter('All'); }} className="cursor-pointer">
                          <Users className="w-3.5 h-3.5 mr-2" />
                          All ({strandStats[strand.key as keyof typeof strandStats] || 0})
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => { handleStrandFilter(strand.key); setGradeLevelFilter('Grade 11'); }} className="cursor-pointer">
                          <GraduationCap className="w-3.5 h-3.5 mr-2" />
                          Grade 11 ({g11Count})
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => { handleStrandFilter(strand.key); setGradeLevelFilter('Grade 12'); }} className="cursor-pointer">
                          <GraduationCap className="w-3.5 h-3.5 mr-2" />
                          Grade 12 ({g12Count})
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  );
                })}
                {/* Special categories */}
                {[
                  { key: 'balikAral', label: 'Balik Aral', color: 'from-[hsl(var(--neon-cyan))] to-[hsl(var(--neon-purple))]', filter: () => { setSearchTerm(''); setStatusFilter('All'); setStrandFilter('All'); setGradeLevelFilter('All'); setFilteredStudents(students.filter(s => s.isBalikAral)); }},
                  { key: 'transfer', label: 'Transfer', color: 'from-[hsl(var(--neon-purple))] to-[hsl(var(--neon-pink))]', filter: () => { setSearchTerm(''); setStatusFilter('All'); setStrandFilter('All'); setGradeLevelFilter('All'); setFilteredStudents(students.filter(s => s.isTransferStudent)); }},
                  { key: '4ps', label: "4P's", color: 'from-[hsl(var(--neon-pink))] to-[hsl(var(--neon-cyan))]', filter: () => { setSearchTerm(''); setStatusFilter('All'); setStrandFilter('All'); setGradeLevelFilter('All'); setFilteredStudents(students.filter(s => s.is4ps)); }},
                ].map((cat) => (
                  <button
                    key={cat.key}
                    onClick={cat.filter}
                    className="group relative flex flex-col items-center justify-center h-24 rounded-xl border border-dashed border-border/50 bg-card/30 hover:border-primary/30 hover:bg-card/50 transition-all duration-300 overflow-hidden"
                  >
                    <div className={`absolute inset-0 bg-gradient-to-br ${cat.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />
                    <span className={`text-3xl font-bold bg-gradient-to-r ${cat.color} bg-clip-text text-transparent`}>
                      {strandStats[cat.key as keyof typeof strandStats] || 0}
                    </span>
                    <span className="text-[11px] font-medium text-muted-foreground mt-1.5 tracking-wide">{cat.label}</span>
                  </button>
                ))}
              </div>

              {(strandFilter !== 'All' || gradeLevelFilter !== 'All' || filteredStudents.length !== students.length) && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
                  className="mt-4 flex items-center justify-between bg-primary/5 border border-primary/20 p-3 rounded-xl"
                >
                  <p className="text-sm text-muted-foreground">
                    <Filter className="w-3.5 h-3.5 inline mr-1.5 text-primary" />
                    {strandFilter !== 'All' ? <>Strand: <span className="font-semibold text-primary">{strandFilter}</span></> : 'Filtered results'}
                    {gradeLevelFilter !== 'All' && <> · <span className="font-semibold text-primary">{gradeLevelFilter}</span></>}
                    <span className="ml-2 text-xs">({filteredStudents.length} student{filteredStudents.length !== 1 ? 's' : ''})</span>
                  </p>
                </motion.div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Filters and Search */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <Card className="glass-effect">
            <CardContent className="p-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by name or LRN..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-card/50 border-border/50 focus:border-primary/50"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="bg-card/50 border-border/50"><SelectValue placeholder="Filter by status" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Status</SelectItem>
                    <SelectItem value="Pending">Pending</SelectItem>
                    <SelectItem value="Approved">Approved</SelectItem>
                    <SelectItem value="Denied">Denied</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={strandFilter} onValueChange={setStrandFilter}>
                  <SelectTrigger className="bg-card/50 border-border/50"><SelectValue placeholder="Filter by strand" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Strands</SelectItem>
                    {Object.values(STRANDS).flat().map(strand => (
                      <SelectItem key={strand} value={strand}>{strand}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="w-full bg-card/50 border-border/50 hover:border-primary/50">
                      <Download className="w-4 h-4 mr-2" />
                      Export
                      <ChevronDown className="w-4 h-4 ml-auto" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={exportApprovedPDF}>
                      <FileText className="w-4 h-4 mr-2 text-rose-500" /> Print Approved (PDF)
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => exportStudents('excel')}>
                      <FileSpreadsheet className="w-4 h-4 mr-2 text-emerald-500" /> Export to Excel
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => exportStudents('word')}>
                      <FileText className="w-4 h-4 mr-2 text-blue-500" /> Export to Word
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => exportStudents('usb')}>
                      <Usb className="w-4 h-4 mr-2 text-amber-500" /> Export to USB Drive
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Students Table */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
          <Card className="glass-effect overflow-hidden">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-primary/15">
                    <GraduationCap className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">Student Enrollments</CardTitle>
                    <p className="text-xs text-muted-foreground mt-0.5">{filteredStudents.length} of {stats.total} students shown</p>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/30 hover:bg-muted/30 border-border/30">
                      <TableHead className="font-semibold text-xs uppercase tracking-wider text-muted-foreground">Student</TableHead>
                      <TableHead className="font-semibold text-xs uppercase tracking-wider text-muted-foreground">LRN</TableHead>
                      <TableHead className="font-semibold text-xs uppercase tracking-wider text-muted-foreground">Strand</TableHead>
                      <TableHead className="font-semibold text-xs uppercase tracking-wider text-muted-foreground">Grade Level</TableHead>
                      <TableHead className="font-semibold text-xs uppercase tracking-wider text-muted-foreground">Status</TableHead>
                      <TableHead className="font-semibold text-xs uppercase tracking-wider text-muted-foreground">Enrolled</TableHead>
                      <TableHead className="font-semibold text-xs uppercase tracking-wider text-muted-foreground">Docs</TableHead>
                      <TableHead className="font-semibold text-xs uppercase tracking-wider text-muted-foreground text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <AnimatePresence>
                      {filteredStudents.map((student, index) => (
                        <motion.tr
                          key={student.id}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: 10 }}
                          transition={{ delay: index * 0.02 }}
                          className="border-b border-border/20 hover:bg-primary/5 transition-colors duration-200 group"
                        >
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[hsl(var(--neon-pink))] to-[hsl(var(--neon-purple))] flex items-center justify-center text-white text-sm font-bold shrink-0">
                                {student.firstName.charAt(0)}{student.lastName.charAt(0)}
                              </div>
                              <div>
                                <p className="font-medium text-sm">{student.firstName} {student.lastName}</p>
                                <p className="text-xs text-muted-foreground">{student.gender}</p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <code className="text-xs bg-muted/50 px-2 py-1 rounded font-mono">{student.lrn}</code>
                          </TableCell>
                          <TableCell>
                            <span className="text-sm truncate max-w-[160px] block">{student.selectedStrand}</span>
                          </TableCell>
                          <TableCell>
                            <span className="text-xs font-medium bg-muted/50 px-2 py-1 rounded-md">{student.gradeLevel || 'N/A'}</span>
                          </TableCell>
                          <TableCell>{getStatusBadge(student.enrollmentStatus)}</TableCell>
                          <TableCell>
                            <span className="text-sm text-muted-foreground">{new Date(student.enrollmentDate).toLocaleDateString()}</span>
                          </TableCell>
                          <TableCell>
                            <Button size="sm" variant="ghost" onClick={() => downloadStudentDocuments(student)}
                              className="text-xs h-8 px-2 hover:text-primary hover:bg-primary/10">
                              <Download className="w-3.5 h-3.5 mr-1" /> Files
                            </Button>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1.5 justify-end opacity-70 group-hover:opacity-100 transition-opacity">
                              <Button size="sm" variant="ghost" onClick={() => handleViewStudent(student)}
                                className="w-8 h-8 p-0 hover:text-[hsl(var(--neon-cyan))] hover:bg-[hsl(var(--neon-cyan)/0.1)]" title="View">
                                <Eye className="w-4 h-4" />
                              </Button>
                              <Button size="sm" variant="ghost" onClick={() => handleEditStudent(student)}
                                className="w-8 h-8 p-0 hover:text-[hsl(var(--neon-pink))] hover:bg-[hsl(var(--neon-pink)/0.1)]" title="Edit">
                                <Edit className="w-4 h-4" />
                              </Button>
                              {student.enrollmentStatus === 'Pending' && (
                                <>
                                  <Button size="sm" onClick={() => handleStatusUpdate(student.id!, 'Approved')} disabled={isLoading}
                                    className="h-8 px-3 text-xs bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 border border-emerald-500/30">
                                    <CheckCircle className="w-3.5 h-3.5 mr-1" /> Approve
                                  </Button>
                                  <Button size="sm" onClick={() => handleStatusUpdate(student.id!, 'Denied')} disabled={isLoading}
                                    className="h-8 px-3 text-xs bg-red-500/20 text-red-400 hover:bg-red-500/30 border border-red-500/30">
                                    <XCircle className="w-3.5 h-3.5 mr-1" /> Deny
                                  </Button>
                                </>
                              )}
                              <Button size="sm" variant="ghost" onClick={() => handleDeleteStudent(student.id!)} disabled={isLoading}
                                className="w-8 h-8 p-0 hover:text-destructive hover:bg-destructive/10" title="Delete">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </motion.tr>
                      ))}
                    </AnimatePresence>
                  </TableBody>
                </Table>
                {filteredStudents.length === 0 && (
                  <div className="text-center py-16">
                    <div className="w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
                      <Users className="w-8 h-8 text-muted-foreground/50" />
                    </div>
                    <p className="text-muted-foreground font-medium">No students found</p>
                    <p className="text-sm text-muted-foreground/60 mt-1">Try adjusting your search or filters</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <StudentDetailsModal student={selectedStudent} isOpen={isModalOpen} onClose={handleCloseModal} onDownloadDocuments={downloadStudentDocuments} />
      <EditStudentModal student={selectedStudent} isOpen={isEditModalOpen} onClose={handleCloseEditModal} onSave={handleSaveStudent} />
    </div>
  );
};
