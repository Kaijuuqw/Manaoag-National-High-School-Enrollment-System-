const mnhsLogo = '/lovable-uploads/991cce49-f6ba-47c4-99f6-2b0018498e45.png';
const shsLogo = '/lovable-uploads/b2d5c16f-5aee-4db9-9a76-5a721181b16c.png';
import { cn } from '@/lib/utils';

interface HeaderProps {
  title?: string;
  subtitle?: string;
  className?: string;
  showLogos?: boolean;
}

export const Header = ({ title, subtitle, className, showLogos = true }: HeaderProps) => {
  return (
    <header className={cn("glass-effect neon-glow border-b-2 border-primary/30 shadow-lg", className)}>
      <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-6">
        <div className={cn("flex items-center gap-3 sm:gap-4", showLogos ? "justify-between" : "justify-center")}>
          {showLogos && (
            <div className="flex-shrink-0">
              <div className="h-14 w-14 sm:h-20 sm:w-20 md:h-28 md:w-28 lg:h-32 lg:w-32 rounded-full overflow-hidden flex items-center justify-center">
                <img 
                  src={shsLogo} 
                  alt="Senior High School Logo" 
                  className="h-[85%] w-[85%] object-contain"
                />
              </div>
            </div>
          )}
          
          <div className={cn("text-center min-w-0 flex-1", showLogos && "mx-1 sm:mx-4")}>
            <h1 className="text-base sm:text-2xl md:text-3xl lg:text-4xl font-bold neon-text mb-1 sm:mb-2 leading-tight break-words">
              {title || "Manaoag National High School"}
            </h1>
            <p className="text-xs sm:text-lg md:text-xl text-foreground/90 leading-tight">
              {subtitle || "Senior High School Enrollment System"}
            </p>
          </div>
          
          {showLogos && (
            <div className="flex-shrink-0">
              <div className="h-14 w-14 sm:h-20 sm:w-20 md:h-28 md:w-28 lg:h-32 lg:w-32 rounded-full overflow-hidden flex items-center justify-center">
                <img 
                  src={mnhsLogo} 
                  alt="MNHS Logo" 
                  className="h-[85%] w-[85%] object-contain"
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};