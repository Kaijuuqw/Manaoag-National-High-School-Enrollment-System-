import { ReactNode } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { Menu } from "lucide-react";

interface MainLayoutProps {
  children: ReactNode;
  showSidebar?: boolean;
}

export function MainLayout({ children, showSidebar = true }: MainLayoutProps) {
  if (!showSidebar) {
    return <>{children}</>;
  }

  return (
    <SidebarProvider defaultOpen={true}>
      <div className="min-h-screen flex w-full relative">
        <AppSidebar />
        
        <main className="flex-1 relative">
          {/* Floating trigger button */}
          <div className="fixed top-4 left-4 z-50">
            <SidebarTrigger className="button-glow-pulse bg-card/80 backdrop-blur-md hover:bg-card border-2 p-2 rounded-lg transition-all duration-300">
              <Menu className="h-5 w-5 text-primary" />
            </SidebarTrigger>
          </div>
          
          {children}
        </main>
      </div>
    </SidebarProvider>
  );
}
