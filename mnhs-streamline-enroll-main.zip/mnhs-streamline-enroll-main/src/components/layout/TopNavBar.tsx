import { Button } from '@/components/ui/button';
import { useNavigate, NavLink } from 'react-router-dom';

export function TopNavBar() {
  const navigate = useNavigate();

  return (
    <nav className="relative z-20 flex items-center justify-between px-6 py-3 bg-[hsl(220,20%,12%)] bg-opacity-80 backdrop-blur-md border-b border-primary/30">
      <div className="flex items-center gap-8">
        {['/', '/strands', '/about', '/support'].map((path, i) => {
          const labels = ['Home', 'Strands', 'About', 'Support'];
          return (
            <NavLink
              key={path}
              to={path}
              className={({ isActive }) =>
                `text-sm font-medium transition-colors ${isActive ? 'text-primary' : 'text-foreground/80 hover:text-foreground'}`
              }
            >
              {labels[i]}
            </NavLink>
          );
        })}
      </div>
      <div className="flex items-center gap-3">
        <Button
          variant="outline"
          size="sm"
          onClick={() => navigate('/login')}
          className="border-primary/50 text-foreground hover:bg-primary/20"
        >
          Login
        </Button>
        <Button
          size="sm"
          onClick={() => navigate('/student/register')}
          className="bg-primary text-primary-foreground hover:bg-primary/80"
        >
          Enroll Now
        </Button>
      </div>
    </nav>
  );
}
