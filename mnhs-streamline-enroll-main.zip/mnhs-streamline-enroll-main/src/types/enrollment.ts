export interface Student {
  id?: string;
  lastName: string;
  firstName: string;
  middleName: string;
  lrn: string;
  dateOfBirth: string;
  placeOfBirth: string;
  zone: string;
  street: string;
  barangay: string;
  city: string;
  province: string;
  gender: 'Male' | 'Female';
  gradeLevel: string; // Changed from previousGrade to gradeLevel
  previousSection: string;
  previousAdviser?: string; // New field
  generalAverage?: number; // New field
  mothersMaidenName: string; // Changed from motherName
  fatherName: string;
  contactNumber: string;
  religion: string;
  is4ps: boolean;
  isBalikAral?: boolean; // New field
  isTransferStudent?: boolean; // New field
  transferSchool?: string; // New field
  transferGrade?: string; // New field
  transferSection?: string; // New field
  transferAdviser?: string; // New field
  transferAverage?: number; // New field
  fourPsStudentName?: string;
  fourPsParentName?: string;
  fourPsIdNumber?: string;
  fourPsContactNumber?: string;
  selectedStrand: string;
  enrollmentStatus: 'Pending' | 'Approved' | 'Denied';
  enrollmentDate: string;
  email: string;
  password: string;
  birthCertificate: string; // Base64 encoded file
  reportCard: string; // Legacy - for backwards compatibility
  reportCardFront: string; // Base64 encoded file - front
  reportCardBack: string; // Base64 encoded file - back
  birthCertificateName: string;
  reportCardName: string; // Legacy - for backwards compatibility
  reportCardFrontName: string;
  reportCardBackName: string;
  certificateOfCompletion?: string; // Base64 encoded file (for Grade 11)
  certificateOfCompletionName?: string;
  emailConfirmed?: boolean;
  confirmationToken?: string;
  confirmationSentAt?: string;
}

export interface Admin {
  username: string;
  password: string;
}

export interface EnrollmentFormData {
  lastName: string;
  firstName: string;
  middleName: string;
  lrn: string;
  dateOfBirth: string;
  placeOfBirth: string;
  zone: string;
  street: string;
  barangay: string;
  city: string;
  province: string;
  gender: 'Male' | 'Female';
  gradeLevel: string; // Changed from previousGrade
  previousSection: string;
  previousAdviser: string; // New field
  generalAverage: string; // New field
  mothersMaidenName: string; // Changed from motherName
  fatherName: string;
  contactNumber: string;
  religion: string;
  is4ps: boolean;
  isBalikAral: boolean; // New field
  isTransferStudent: boolean; // New field
  transferSchool: string; // New field
  transferGrade: string; // New field
  transferSection: string; // New field
  transferAdviser: string; // New field
  transferAverage: string; // New field
  fourPsStudentName: string;
  fourPsParentName: string;
  fourPsIdNumber: string;
  fourPsContactNumber: string;
  selectedStrand: string;
  email: string;
  password: string;
  confirmPassword: string;
  birthCertificate: string;
  reportCard: string; // Legacy - for backwards compatibility
  reportCardFront: string;
  reportCardBack: string;
  birthCertificateName: string;
  reportCardName: string; // Legacy - for backwards compatibility
  reportCardFrontName: string;
  reportCardBackName: string;
  certificateOfCompletion?: string;
  certificateOfCompletionName?: string;
}

export const STRANDS = {
  TVL: [
    'TVL - ICT',
    'TVL - EPAS', 
    'TVL - COOKERY',
    'TVL - BPP'
  ],
  Academic: [
    'ABM',
    'STEM',
    'HUMSS'
  ],
  ALS: [
    'ALS'
  ]
};