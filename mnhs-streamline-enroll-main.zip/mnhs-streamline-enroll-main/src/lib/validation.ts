import { z } from 'zod';

// Student registration validation schema
export const studentRegistrationSchema = z.object({
  email: z.string()
    .email('Invalid email format')
    .max(255, 'Email must be less than 255 characters'),
  
  lrn: z.string()
    .regex(/^[0-9]{12}$/, 'LRN must be exactly 12 digits'),
  
  password: z.string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number'),
  
  confirmPassword: z.string(),
  
  firstName: z.string()
    .trim()
    .min(1, 'First name is required')
    .max(100, 'First name must be less than 100 characters'),
  
  lastName: z.string()
    .trim()
    .min(1, 'Last name is required')
    .max(100, 'Last name must be less than 100 characters'),
  
  middleName: z.string()
    .max(100, 'Middle name must be less than 100 characters')
    .optional(),
  
  contactNumber: z.string()
    .regex(/^[0-9]{10,15}$/, 'Contact number must be 10-15 digits'),
  
  dateOfBirth: z.string()
    .min(1, 'Date of birth is required'),
  
  gender: z.enum(['Male', 'Female'], {
    errorMap: () => ({ message: 'Gender must be Male or Female' })
  }),
  
  selectedStrand: z.string()
    .min(1, 'Please select a strand'),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

// Admin login validation schema
export const adminLoginSchema = z.object({
  username: z.string()
    .trim()
    .min(1, 'Username is required')
    .max(100, 'Username must be less than 100 characters'),
  
  password: z.string()
    .min(1, 'Password is required'),
});

// Student login validation schema
export const studentLoginSchema = z.object({
  email: z.string()
    .email('Invalid email format'),
  
  password: z.string()
    .min(1, 'Password is required'),
});

// Contact number validation helper
export const validateContactNumber = (contactNumber: string): boolean => {
  return /^[0-9]{10,15}$/.test(contactNumber);
};

// Email validation helper
export const validateEmail = (email: string): boolean => {
  return /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(email);
};

// LRN validation helper
export const validateLRN = (lrn: string): boolean => {
  return /^[0-9]{12}$/.test(lrn);
};
