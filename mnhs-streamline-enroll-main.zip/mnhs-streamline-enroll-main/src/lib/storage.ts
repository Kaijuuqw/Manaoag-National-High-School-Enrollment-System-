import { Student, Admin } from '@/types/enrollment';

const DB_NAME = 'MNHS_DB';
const DB_VERSION = 2;
const STUDENTS_STORE = 'students';
const ADMIN_STORE = 'admin';
const CURRENT_USER_KEY = 'mnhs_current_user';

// IndexedDB setup
const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    console.log('Opening IndexedDB database...');
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    
    request.onerror = () => {
      console.error('IndexedDB open error:', request.error);
      reject(request.error);
    };
    request.onsuccess = () => {
      console.log('IndexedDB opened successfully');
      resolve(request.result);
    };
    
    request.onupgradeneeded = (event) => {
      console.log('Upgrading IndexedDB...');
      const db = (event.target as IDBOpenDBRequest).result;
      
      if (!db.objectStoreNames.contains(STUDENTS_STORE)) {
        console.log('Creating students store...');
        const studentsStore = db.createObjectStore(STUDENTS_STORE, { keyPath: 'id' });
        studentsStore.createIndex('lrn', 'lrn', { unique: true });
      }
      
      if (!db.objectStoreNames.contains(ADMIN_STORE)) {
        console.log('Creating admin store...');
        db.createObjectStore(ADMIN_STORE, { keyPath: 'username' });
      }
      
      if (!db.objectStoreNames.contains('session')) {
        console.log('Creating session store...');
        db.createObjectStore('session', { keyPath: 'key' });
      }
    };
  });
};

// Initialize admin credentials
export const initializeAdmin = async (): Promise<void> => {
  try {
    const db = await openDB();
    const transaction = db.transaction([ADMIN_STORE], 'readwrite');
    const store = transaction.objectStore(ADMIN_STORE);
    
    const request = store.get('admin');
    request.onsuccess = () => {
      if (!request.result) {
        const admin: Admin = {
          username: 'admin',
          password: 'admin01052006'
        };
        store.add(admin);
      }
    };
  } catch (error) {
    console.error('Error initializing admin:', error);
  }
};

// Student operations
export const saveStudent = async (student: Student): Promise<void> => {
  try {
    console.log('Attempting to save student:', student.firstName, student.lastName, student.id);
    const db = await openDB();
    const transaction = db.transaction([STUDENTS_STORE], 'readwrite');
    const store = transaction.objectStore(STUDENTS_STORE);
    
    await new Promise<void>((resolve, reject) => {
      const request = store.put(student);
      request.onsuccess = () => {
        console.log('Student saved successfully:', student.id);
        resolve();
      };
      request.onerror = () => {
        console.error('Error saving student to store:', request.error);
        reject(request.error);
      };
    });
  } catch (error) {
    console.error('Error saving student:', error);
    throw error;
  }
};

export const getStudents = async (): Promise<Student[]> => {
  try {
    console.log('Getting students from database...');
    const db = await openDB();
    const transaction = db.transaction([STUDENTS_STORE], 'readonly');
    const store = transaction.objectStore(STUDENTS_STORE);
    
    return new Promise<Student[]>((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => {
        const students = request.result || [];
        console.log('Retrieved students from database:', students.length, students);
        resolve(students);
      };
      request.onerror = () => {
        console.error('Error in getAll request:', request.error);
        reject(request.error);
      };
    });
  } catch (error) {
    console.error('Error getting students:', error);
    return [];
  }
};

export const getStudent = async (id: string): Promise<Student | null> => {
  try {
    const db = await openDB();
    const transaction = db.transaction([STUDENTS_STORE], 'readonly');
    const store = transaction.objectStore(STUDENTS_STORE);
    
    return new Promise<Student | null>((resolve, reject) => {
      const request = store.get(id);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error('Error getting student:', error);
    return null;
  }
};

export const deleteStudent = async (id: string): Promise<void> => {
  try {
    const db = await openDB();
    const transaction = db.transaction([STUDENTS_STORE], 'readwrite');
    const store = transaction.objectStore(STUDENTS_STORE);
    
    await new Promise<void>((resolve, reject) => {
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error('Error deleting student:', error);
    throw error;
  }
};

// Authentication
export const authenticateAdmin = async (username: string, password: string): Promise<boolean> => {
  try {
    const db = await openDB();
    const transaction = db.transaction([ADMIN_STORE], 'readonly');
    const store = transaction.objectStore(ADMIN_STORE);
    
    return new Promise<boolean>((resolve) => {
      const request = store.get(username);
      request.onsuccess = () => {
        const admin = request.result;
        resolve(admin && admin.password === password);
      };
      request.onerror = () => resolve(false);
    });
  } catch (error) {
    console.error('Error authenticating admin:', error);
    return false;
  }
};

export const authenticateStudent = async (lrn: string, password: string): Promise<Student | null> => {
  try {
    const students = await getStudents();
    const student = students.find(s => s.lrn === lrn && s.password === password);
    return student || null;
  } catch (error) {
    console.error('Error authenticating student:', error);
    return null;
  }
};

// Check if LRN already exists
export const checkLRNExists = async (lrn: string): Promise<boolean> => {
  try {
    const students = await getStudents();
    return students.some(s => s.lrn === lrn);
  } catch (error) {
    console.error('Error checking LRN:', error);
    return false;
  }
};

// Session management using IndexedDB
const SESSION_STORE = 'session';

export const setCurrentUser = async (user: Student | Admin, type: 'student' | 'admin'): Promise<void> => {
  try {
    const db = await openDB();
    const transaction = db.transaction(['session'], 'readwrite');
    const store = transaction.objectStore('session');
    
    await new Promise<void>((resolve, reject) => {
      const request = store.put({ key: 'current_user', user, type });
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error('Error setting current user:', error);
  }
};

export const getCurrentUser = async (): Promise<{ user: Student | Admin; type: 'student' | 'admin' } | null> => {
  try {
    const db = await openDB();
    const transaction = db.transaction(['session'], 'readonly');
    const store = transaction.objectStore('session');
    
    return new Promise<{ user: Student | Admin; type: 'student' | 'admin' } | null>((resolve) => {
      const request = store.get('current_user');
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => resolve(null);
    });
  } catch (error) {
    console.error('Error getting current user:', error);
    return null;
  }
};

export const logout = async (): Promise<void> => {
  try {
    const db = await openDB();
    const transaction = db.transaction(['session'], 'readwrite');
    const store = transaction.objectStore('session');
    
    await new Promise<void>((resolve, reject) => {
      const request = store.delete('current_user');
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error('Error during logout:', error);
  }
};

// Initialize storage
// Update student status
export const updateStudentStatus = async (id: string, status: 'Pending' | 'Approved' | 'Denied'): Promise<void> => {
  try {
    const student = await getStudent(id);
    if (student) {
      student.enrollmentStatus = status;
      await saveStudent(student);
    }
  } catch (error) {
    console.error('Error updating student status:', error);
    throw error;
  }
};

export const initializeStorage = async (): Promise<void> => {
  await initializeAdmin();
};