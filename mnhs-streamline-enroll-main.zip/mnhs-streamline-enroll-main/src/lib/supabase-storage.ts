import { supabase } from '@/integrations/supabase/client';
import { Student, Admin } from '@/types/enrollment';
import { normalizeStrandForDB, formatStrandForUI } from '@/lib/utils';

// Student operations
export const saveStudent = async (student: Student): Promise<void> => {
  try {
    const confirmationToken = crypto.randomUUID();
    
    const { error } = await supabase
      .from('students')
      .insert({
        first_name: student.firstName,
        middle_name: student.middleName || null,
        last_name: student.lastName,
        lrn: student.lrn,
        date_of_birth: student.dateOfBirth,
        place_of_birth: student.placeOfBirth || '',
        zone: student.zone || null,
        street: student.street || null,
        barangay: student.barangay || '',
        city: student.city || '',
        province: student.province || '',
        gender: student.gender,
        grade_level: student.gradeLevel || '',
        previous_grade: student.gradeLevel || '',
        previous_section: student.previousSection || '',
        mothers_maiden_name: student.mothersMaidenName || '',
        fathers_name: student.fatherName || '',
        contact_number: student.contactNumber || '',
        religion: student.religion || '',
        is_4ps: student.is4ps,
        four_ps_student_name: student.fourPsStudentName || null,
        four_ps_parent_name: student.fourPsParentName || null,
        four_ps_id_number: student.fourPsIdNumber || null,
        four_ps_contact_number: student.fourPsContactNumber || null,
        strand: normalizeStrandForDB(student.selectedStrand),
        enrollment_status: student.enrollmentStatus,
        enrollment_date: student.enrollmentDate,
        password: student.password || '',
        email: student.email || '',
        birth_certificate: student.birthCertificate || null,
        report_card_front: student.reportCardFront || null,
        report_card_back: student.reportCardBack || null,
        birth_certificate_name: student.birthCertificateName || null,
        report_card_front_name: student.reportCardFrontName || null,
        report_card_back_name: student.reportCardBackName || null,
        confirmation_token: confirmationToken,
        confirmation_sent_at: new Date().toISOString(),
        email_confirmed: false,
        is_balik_aral: student.isBalikAral || false,
        is_transfer_student: student.isTransferStudent || false,
        previous_adviser: student.previousAdviser || null,
        general_average: student.generalAverage || null,
        transfer_school: student.transferSchool || null,
        transfer_grade: student.transferGrade || null,
        transfer_section: student.transferSection || null,
        transfer_adviser: student.transferAdviser || null,
        transfer_average: student.transferAverage || null,
        certificate_of_completion: student.certificateOfCompletion || null,
        certificate_of_completion_name: student.certificateOfCompletionName || null
      });

    if (error) {
      console.error('Registration error details:', {
        message: error.message,
        details: error.details,
        hint: error.hint,
        code: error.code
      });
      throw new Error(`Registration failed: ${error.message}${error.hint ? ` (${error.hint})` : ''}`);
    }
    
    // Send confirmation email if email is provided
    if (student.email && student.email.trim()) {
      try {
        const { data: emailData, error: emailError } = await supabase.functions.invoke('send-confirmation-email', {
          body: {
            email: student.email,
            studentName: `${student.firstName} ${student.lastName}`,
            confirmationToken: confirmationToken,
            origin: window.location.origin
          }
        });
        if (emailError) {
          console.error('Failed to send confirmation email:', emailError);
        } else {
          console.log('Confirmation email sent successfully:', emailData);
        }
      } catch (emailError) {
        console.error('Error sending confirmation email:', emailError);
      }
    }

    // Notify admins of new registration
    try {
      await supabase.functions.invoke('notify-admin-registration', {
        body: {
          studentName: `${student.firstName} ${student.lastName}`,
          studentEmail: student.email || '',
          strand: student.selectedStrand,
          lrn: student.lrn,
          registrationDate: new Date().toISOString()
        }
      });
    } catch (notifyError) {
      // Admin notification failure shouldn't block registration
      console.error('Failed to notify admins:', notifyError);
    }
    
  } catch (error) {
    console.error('Save student error:', error);
    throw new Error('Registration failed. Please try again.');
  }
};

export const getStudents = async (): Promise<Student[]> => {
  try {
    const { data, error } = await supabase
      .from('students')
      .select('*')
      .order('enrollment_date', { ascending: false });

    if (error) {
      throw new Error('Failed to fetch students');
    }

    const students: Student[] = (data || []).map(row => ({
      id: row.id,
      firstName: row.first_name,
      middleName: row.middle_name || '',
      lastName: row.last_name,
      lrn: row.lrn,
      dateOfBirth: row.date_of_birth,
      placeOfBirth: row.place_of_birth,
      zone: row.zone || '',
      street: row.street || '',
      barangay: row.barangay,
      city: row.city,
      province: row.province,
      gender: row.gender as 'Male' | 'Female',
      gradeLevel: row.grade_level,
      previousSection: row.previous_section,
      mothersMaidenName: row.mothers_maiden_name,
      fatherName: row.fathers_name,
      contactNumber: row.contact_number,
      religion: row.religion,
      is4ps: row.is_4ps,
      fourPsStudentName: row.four_ps_student_name || '',
      fourPsParentName: row.four_ps_parent_name || '',
      fourPsIdNumber: row.four_ps_id_number || '',
      fourPsContactNumber: row.four_ps_contact_number || '',
      selectedStrand: formatStrandForUI(row.strand),
      enrollmentStatus: row.enrollment_status as 'Pending' | 'Approved' | 'Denied',
      enrollmentDate: row.enrollment_date,
      email: row.email || '',
      password: row.password,
      birthCertificate: row.birth_certificate || '',
      reportCard: row.report_card || '', // Legacy
      reportCardFront: row.report_card_front || '',
      reportCardBack: row.report_card_back || '',
      birthCertificateName: row.birth_certificate_name || '',
      reportCardName: row.report_card_name || '', // Legacy
      reportCardFrontName: row.report_card_front_name || '',
      reportCardBackName: row.report_card_back_name || '',
      certificateOfCompletion: row.certificate_of_completion || '',
      certificateOfCompletionName: row.certificate_of_completion_name || '',
      isBalikAral: row.is_balik_aral || false,
      isTransferStudent: row.is_transfer_student || false,
      previousAdviser: row.previous_adviser || '',
      generalAverage: row.general_average || null,
      transferSchool: row.transfer_school || '',
      transferGrade: row.transfer_grade || '',
      transferSection: row.transfer_section || '',
      transferAdviser: row.transfer_adviser || '',
      transferAverage: row.transfer_average || null
    }));

    return students;
  } catch (error) {
    return [];
  }
};

export const getStudent = async (id: string): Promise<Student | null> => {
  try {
    const { data, error } = await supabase
      .from('students')
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      return null;
    }

    if (!data) return null;

    return {
      id: data.id,
      firstName: data.first_name,
      middleName: data.middle_name || '',
      lastName: data.last_name,
      lrn: data.lrn,
      dateOfBirth: data.date_of_birth,
      placeOfBirth: data.place_of_birth,
      zone: data.zone || '',
      street: data.street || '',
      barangay: data.barangay,
      city: data.city,
      province: data.province,
      gender: data.gender as 'Male' | 'Female',
      gradeLevel: data.grade_level,
      previousSection: data.previous_section,
      mothersMaidenName: data.mothers_maiden_name,
      fatherName: data.fathers_name,
      contactNumber: data.contact_number,
      religion: data.religion,
      is4ps: data.is_4ps,
      fourPsStudentName: data.four_ps_student_name || '',
      fourPsParentName: data.four_ps_parent_name || '',
      fourPsIdNumber: data.four_ps_id_number || '',
      fourPsContactNumber: data.four_ps_contact_number || '',
      selectedStrand: formatStrandForUI(data.strand),
      enrollmentStatus: data.enrollment_status as 'Pending' | 'Approved' | 'Denied',
      enrollmentDate: data.enrollment_date,
      email: data.email || '',
      password: data.password,
      birthCertificate: data.birth_certificate || '',
      reportCard: data.report_card || '', // Legacy
      reportCardFront: data.report_card_front || '',
      reportCardBack: data.report_card_back || '',
      birthCertificateName: data.birth_certificate_name || '',
      reportCardName: data.report_card_name || '', // Legacy
      reportCardFrontName: data.report_card_front_name || '',
      reportCardBackName: data.report_card_back_name || ''
    };
  } catch (error) {
    return null;
  }
};

export const deleteStudent = async (id: string): Promise<void> => {
  try {
    const { error } = await supabase.functions.invoke('admin-delete-student', {
      body: { id },
    });

    if (error) throw new Error('Failed to delete student');
  } catch (error) {
    throw new Error('Failed to delete student');
  }
};

export const updateStudentStatus = async (id: string, status: 'Pending' | 'Approved' | 'Denied'): Promise<void> => {
  try {
    const { error } = await supabase.functions.invoke('admin-update-student-status', {
      body: { id, status },
    });

    if (error) throw new Error('Failed to update student status');
  } catch (error) {
    throw new Error('Failed to update student status');
  }
};

export const updateStudent = async (id: string, studentData: Partial<Student>): Promise<void> => {
  try {
    const updateData: any = {};
    
    // Map Student interface fields to database columns
    if (studentData.firstName !== undefined) updateData.first_name = studentData.firstName;
    if (studentData.middleName !== undefined) updateData.middle_name = studentData.middleName;
    if (studentData.lastName !== undefined) updateData.lastName = studentData.lastName;
    if (studentData.lrn !== undefined) updateData.lrn = studentData.lrn;
    if (studentData.dateOfBirth !== undefined) updateData.date_of_birth = studentData.dateOfBirth;
    if (studentData.placeOfBirth !== undefined) updateData.place_of_birth = studentData.placeOfBirth;
    if (studentData.zone !== undefined) updateData.zone = studentData.zone;
    if (studentData.street !== undefined) updateData.street = studentData.street;
    if (studentData.barangay !== undefined) updateData.barangay = studentData.barangay;
    if (studentData.city !== undefined) updateData.city = studentData.city;
    if (studentData.province !== undefined) updateData.province = studentData.province;
    if (studentData.gender !== undefined) updateData.gender = studentData.gender;
    if (studentData.gradeLevel !== undefined) updateData.grade_level = studentData.gradeLevel;
    if (studentData.previousSection !== undefined) updateData.previous_section = studentData.previousSection;
    if (studentData.mothersMaidenName !== undefined) updateData.mothers_maiden_name = studentData.mothersMaidenName;
    if (studentData.fatherName !== undefined) updateData.fathers_name = studentData.fatherName;
    if (studentData.contactNumber !== undefined) updateData.contact_number = studentData.contactNumber;
    if (studentData.religion !== undefined) updateData.religion = studentData.religion;
    if (studentData.is4ps !== undefined) updateData.is_4ps = studentData.is4ps;
    if (studentData.fourPsStudentName !== undefined) updateData.four_ps_student_name = studentData.fourPsStudentName;
    if (studentData.fourPsParentName !== undefined) updateData.four_ps_parent_name = studentData.fourPsParentName;
    if (studentData.fourPsIdNumber !== undefined) updateData.four_ps_id_number = studentData.fourPsIdNumber;
    if (studentData.fourPsContactNumber !== undefined) updateData.four_ps_contact_number = studentData.fourPsContactNumber;
    if (studentData.selectedStrand !== undefined) updateData.strand = normalizeStrandForDB(studentData.selectedStrand);
    if (studentData.email !== undefined) updateData.email = studentData.email;

    const { error } = await supabase
      .from('students')
      .update(updateData)
      .eq('id', id);

    if (error) throw new Error('Failed to update student');
  } catch (error) {
    throw new Error('Failed to update student');
  }
};

// Admin operations
export const authenticateAdmin = async (username: string, password: string): Promise<any> => {
  try {
    // Try new admin_users table (hashed passwords)
    const { data: au, error: auError } = await supabase
      .from('admin_users')
      .select('*')
      .eq('username', username)
      .maybeSingle();

    if (au && !auError) {
      // Support both ESM/CJS import shapes
      const mod = await import('bcryptjs');
      const bcrypt: any = (mod as any).default ?? mod;
      const isValid = await bcrypt.compare(password, (au as any).password_hash);

      if (isValid) {
        await supabase.rpc('set_config', {
          setting_name: 'app.current_admin_username',
          setting_value: username,
          is_local: false
        });
        return au;
      }
    }

    // Fallback to legacy admin table (plaintext passwords)
    const { data: legacy, error: legacyError } = await supabase
      .from('admin')
      .select('*')
      .eq('username', username)
      .eq('password', password)
      .maybeSingle();

    if (legacy && !legacyError) {
      await supabase.rpc('set_config', {
        setting_name: 'app.current_admin_username',
        setting_value: username,
        is_local: false
      });
      return legacy;
    }

    return null;
  } catch (error) {
    return null;
  }
};

export const authenticateStudent = async (email: string, password: string): Promise<any> => {
  try {
    // First, get student by email only
    const normalizedEmail = email.trim().toLowerCase();
     const { data, error } = await (supabase as any)
       .from('students')
       .select('*')
       .ilike('email', normalizedEmail)
       .eq('email_confirmed', true)
       .order('updated_at', { ascending: false })
       .limit(1)
       .maybeSingle();

    if (error || !data) {
      console.log('Student not found with email:', email);
      return null;
    }

    // Check if email is confirmed
    if (!(data as any).email_confirmed) {
      throw new Error('Please confirm your email before logging in');
    }

    // Check password - handle both plain text (old) and bcrypt hashed (new) passwords
    const inputPassword = password.trim();
    let passwordMatch = false;
    
    const dbPassword = String(data.password ?? '');
    // Check if password starts with bcrypt hash signature
    if (dbPassword.startsWith('$2a$') || dbPassword.startsWith('$2b$') || dbPassword.startsWith('$2y$')) {
      // It's a bcrypt hash, use compare (support both CJS and ESM shapes)
      const mod: any = await import('bcryptjs');
      const bcrypt: any = mod.default ?? mod;
      passwordMatch = await bcrypt.compare(inputPassword, dbPassword);
    } else {
      // It's plain text, direct comparison
      passwordMatch = dbPassword === inputPassword;
    }

    if (!passwordMatch) {
      // Fallback: check any other records with same email (handles duplicates)
      const { data: allRows } = await (supabase as any)
        .from('students')
        .select('id,password,email_confirmed')
        .ilike('email', normalizedEmail);

      if (Array.isArray(allRows)) {
        for (const row of allRows as any[]) {
          const dbp = String(row.password ?? '');
          let match = false;
          if (dbp.startsWith('$2a$') || dbp.startsWith('$2b$') || dbp.startsWith('$2y$')) {
            const mod: any = await import('bcryptjs');
            const bc: any = mod.default ?? mod;
            match = await bc.compare(inputPassword, dbp);
          } else {
            match = dbp === inputPassword;
          }
          if (match) {
            passwordMatch = true;
            break;
          }
        }
      }

      if (!passwordMatch) {
        console.log('Password mismatch for student:', email);
        return null;
      }
    }

    return {
      id: data.id,
      firstName: data.first_name,
      middleName: data.middle_name || '',
      lastName: data.last_name,
      lrn: data.lrn,
      dateOfBirth: data.date_of_birth,
      placeOfBirth: data.place_of_birth,
      zone: data.zone || '',
      street: data.street || '',
      barangay: data.barangay,
      city: data.city,
      province: data.province,
      gender: data.gender as 'Male' | 'Female',
      previousGrade: data.previous_grade,
      previousSection: data.previous_section,
      motherName: data.mothers_name,
      fatherName: data.fathers_name,
      contactNumber: data.contact_number,
      religion: data.religion,
      is4ps: data.is_4ps,
      fourPsStudentName: data.four_ps_student_name || '',
      fourPsParentName: data.four_ps_parent_name || '',
      fourPsIdNumber: data.four_ps_id_number || '',
      fourPsContactNumber: data.four_ps_contact_number || '',
      selectedStrand: data.strand,
      enrollmentStatus: data.enrollment_status as 'Pending' | 'Approved' | 'Denied',
      enrollmentDate: data.enrollment_date,
      email: data.email || '',
      password: data.password,
      birthCertificate: data.birth_certificate || '',
      reportCard: data.report_card || '',
      birthCertificateName: data.birth_certificate_name || '',
      reportCardName: data.report_card_name || ''
    };
  } catch (error) {
    if (error instanceof Error && error.message.includes('confirm your email')) {
      throw error;
    }
    return null;
  }
};

// Check if LRN already exists
export const checkLRNExists = async (lrn: string): Promise<boolean> => {
  try {
    const { data, error } = await supabase
      .from('students')
      .select('id')
      .eq('lrn', lrn)
      .maybeSingle();

    if (error) {
      console.error('Error checking LRN:', error);
      return false;
    }

    return !!data;
  } catch (error) {
    console.error('Error checking LRN:', error);
    return false;
  }
};

// Check if email already exists
export const checkEmailExists = async (email: string): Promise<boolean> => {
  try {
    const { data, error } = await (supabase as any)
      .from('students')
      .select('id')
      .eq('email', email)
      .maybeSingle();

    if (error && error.code !== 'PGRST116') { // PGRST116 = no rows returned
      console.error('Error checking email:', error);
      return false;
    }

    return !!data;
  } catch (error) {
    console.error('Error checking email:', error);
    return false;
  }
};

// Session management using Supabase
export const setCurrentUser = async (user: Student | Admin, type: 'student' | 'admin'): Promise<void> => {
  try {
    // Clean up expired sessions first
    await supabase.rpc('clean_expired_sessions');

    const userId = 'id' in user && user.id ? user.id : 'username' in user ? user.username : 'unknown';
    
    const { error } = await supabase
      .from('auth_sessions')
      .upsert({
        user_id: userId,
        user_type: type,
        user_data: user as any,
        expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // 30 days for longer persistence
      });

    if (error) throw error;
  } catch (error) {
    console.error('Error setting current user:', error);
  }
};

export const getCurrentUser = async (): Promise<{ user: Student | Admin; type: 'student' | 'admin' } | null> => {
  try {
    // Clean up expired sessions first
    await supabase.rpc('clean_expired_sessions');

    const { data, error } = await supabase
      .from('auth_sessions')
      .select('*')
      .gt('expires_at', new Date().toISOString())
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (error && error.code !== 'PGRST116') {
      console.error('Error getting current user:', error);
      return null;
    }

    if (!data) return null;

    return {
      user: data.user_data as any as Student | Admin,
      type: data.user_type as 'student' | 'admin'
    };
  } catch (error) {
    console.error('Error getting current user:', error);
    return null;
  }
};

export const logout = async (): Promise<void> => {
  try {
    const { error } = await supabase
      .from('auth_sessions')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000'); // Delete all sessions

    if (error) throw error;
  } catch (error) {
    console.error('Error during logout:', error);
  }
};

// Initialize storage - no longer needed with Supabase
export const initializeStorage = async (): Promise<void> => {
  // No initialization needed for Supabase
  console.log('Supabase storage initialized');
};

// Email confirmation function - uses edge function with service role to bypass RLS
export const confirmEmail = async (token: string): Promise<string> => {
  try {
    const { data, error } = await supabase.functions.invoke('confirm-email', {
      body: { token }
    });

    if (error) {
      console.error('Confirm email error:', error);
      return 'invalid';
    }

    return data?.status || 'invalid';
  } catch (error) {
    console.error('Error confirming email:', error);
    return 'invalid';
  }
};