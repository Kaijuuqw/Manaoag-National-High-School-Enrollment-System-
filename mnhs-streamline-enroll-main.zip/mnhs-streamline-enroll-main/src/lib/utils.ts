import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Strand helpers: keep UI labels pretty but store DB-safe values
export function normalizeStrandForDB(strand: string): string {
  // Convert "TVL - XYZ" to "TVL-XYZ" while leaving others intact
  if (!strand) return strand
  return strand.replace(/^TVL\s-\s/, 'TVL-')
}

export function formatStrandForUI(strand: string): string {
  // Convert "TVL-XYZ" back to "TVL - XYZ" for display/filters
  if (!strand) return strand
  return strand.replace(/^TVL-/, 'TVL - ')
}
