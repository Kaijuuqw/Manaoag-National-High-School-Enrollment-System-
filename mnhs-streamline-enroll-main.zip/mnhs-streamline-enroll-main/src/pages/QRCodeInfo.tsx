import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Header } from '@/components/layout/Header';
import { Copy, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

export const QRCodeInfo = () => {
  const [copied, setCopied] = useState(false);
  const registrationUrl = `${window.location.origin}/student/register`;

  const handleCopy = () => {
    navigator.clipboard.writeText(registrationUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen school-bg">
      <Header title="QR Code Registration Link" subtitle="For Student Registration" />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <Card className="shadow-lg">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Registration QR Code URL</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="p-6 bg-muted rounded-lg">
                <p className="text-sm text-muted-foreground mb-3">
                  Use this URL for your QR code generator:
                </p>
                <div className="flex items-center gap-2 p-3 bg-background rounded border">
                  <code className="flex-1 text-sm break-all">{registrationUrl}</code>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleCopy}
                    className="shrink-0"
                  >
                    {copied ? (
                      <CheckCircle className="h-4 w-4 text-green-500" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="font-semibold">Instructions:</h3>
                <ol className="list-decimal list-inside space-y-2 text-sm text-muted-foreground">
                  <li>Copy the URL above</li>
                  <li>Use any QR code generator (e.g., qr-code-generator.com)</li>
                  <li>Paste the URL into the generator</li>
                  <li>Generate and download your QR code</li>
                  <li>Students can scan it to go directly to the registration form</li>
                </ol>
              </div>

              <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                <p className="text-sm text-blue-900 dark:text-blue-100">
                  <strong>Note:</strong> Make sure to use the full URL (including https://) 
                  when generating your QR code. This ensures students will be directed to the 
                  correct page when they scan it.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
