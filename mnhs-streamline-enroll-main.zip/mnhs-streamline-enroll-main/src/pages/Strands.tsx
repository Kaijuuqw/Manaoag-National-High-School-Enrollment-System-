import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BookOpen, Users, GraduationCap, Award } from 'lucide-react';
import { TopNavBar } from '@/components/layout/TopNavBar';
import backgroundImg from '@/assets/background.jpeg';

export const Strands = () => {
  return (
    <div className="min-h-screen relative">
      <div className="fixed inset-0 z-0" style={{ backgroundImage: `url(${backgroundImg})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
      <div className="fixed inset-0 z-0 bg-[hsl(220,20%,8%)] opacity-50" />
      <TopNavBar />
      <div className="relative z-10 container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold neon-text mb-4">Senior High School Strands</h1>
          <p className="text-foreground/80 text-lg">Choose your path to success</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          <Card className="holographic-card neon-glow">
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <BookOpen className="w-6 h-6 text-primary" />
                <CardTitle className="text-2xl neon-text">Academic Track</CardTitle>
              </div>
              <CardDescription>Prepare for higher education and professional careers</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {['HUMSS - Humanities and Social Sciences', 'ABM - Accountancy, Business and Management', 'STEM - Science, Technology, Engineering and Mathematics'].map(s => (
                  <div key={s} className="flex items-center gap-3 p-3 bg-primary/10 rounded-lg border border-primary/20">
                    <Award className="w-5 h-5 text-primary" />
                    <span className="font-medium">{s}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="holographic-card neon-glow">
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <Users className="w-6 h-6 text-accent" />
                <CardTitle className="text-2xl text-accent">TVL Track</CardTitle>
              </div>
              <CardDescription>Technical-Vocational-Livelihood programs for immediate employment</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {['TVL-ICT - Information and Communications Technology', 'TVL-EPAS - Electrical Installation and Maintenance', 'TVL-COOKERY - Food and Beverage Services', 'TVL-BPP - Bread and Pastry Production'].map(s => (
                  <div key={s} className="flex items-center gap-3 p-3 bg-accent/10 rounded-lg border border-accent/20">
                    <Award className="w-5 h-5 text-accent" />
                    <span className="font-medium">{s}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="holographic-card neon-glow">
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <GraduationCap className="w-6 h-6 text-[hsl(var(--neon-purple))]" />
                <CardTitle className="text-2xl text-[hsl(var(--neon-purple))]">ALS Track</CardTitle>
              </div>
              <CardDescription>Alternative Learning System for flexible education</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-[hsl(var(--neon-purple))]/10 rounded-lg border border-[hsl(var(--neon-purple))]/20">
                  <Award className="w-5 h-5 text-[hsl(var(--neon-purple))]" />
                  <span className="font-medium">ALS - Alternative Learning System</span>
                </div>
                <p className="text-sm text-muted-foreground mt-4">
                  A parallel learning system that provides opportunities for out-of-school youth and adult learners.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
