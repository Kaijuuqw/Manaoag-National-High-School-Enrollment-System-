import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TopNavBar } from '@/components/layout/TopNavBar';
import backgroundImg from '@/assets/background.jpeg';


export const About = () => {
  return (
    <div className="min-h-screen relative">
      <div className="fixed inset-0 z-0" style={{ backgroundImage: `url(${backgroundImg})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
      <div className="fixed inset-0 z-0 bg-[hsl(220,20%,8%)] opacity-50" />
      <TopNavBar />
      <div className="relative z-10 container mx-auto px-4 py-12">
        <Card className="holographic-card neon-glow max-w-4xl mx-auto">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl neon-text mb-4">About Manaoag National High School</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 text-foreground/90">
            <div className="glass-effect p-6 rounded-lg">
              <h3 className="text-xl font-semibold neon-text mb-3">Republic of the Philippines</h3>
              <p className="text-lg font-semibold">Department of Education</p>
              <p className="italic">Region I</p>
              <p className="italic">Pangasinan Division II</p>
            </div>
            <div className="glass-effect p-6 rounded-lg">
              <h2 className="text-2xl font-bold neon-text mb-4">Manaoag National High School</h2>
              <p className="mb-2">Manaoag Pangasinan</p>
              <p className="text-xl font-bold text-primary">Senior-High School</p>
            </div>
            <div className="glass-effect p-6 rounded-lg">
              <h3 className="text-xl font-semibold neon-text mb-3">Excellence in Education</h3>
              <p className="leading-relaxed">
                Join our community of learners and discover your potential at Manaoag National High School - 
                Senior High School. We are committed to providing quality education and preparing our students 
                for success in their chosen paths.
              </p>
            </div>
            <div className="glass-effect p-6 rounded-lg">
              <h3 className="text-xl font-semibold neon-text mb-3">Our Mission</h3>
              <p className="leading-relaxed">
                To provide accessible, quality education that empowers students to become responsible citizens 
                and prepares them for higher education or immediate employment through our comprehensive 
                academic and technical-vocational programs.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
