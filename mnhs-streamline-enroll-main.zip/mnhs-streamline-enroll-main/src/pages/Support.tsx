import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { TopNavBar } from '@/components/layout/TopNavBar';
import { Mail, Phone, MapPin, HelpCircle } from 'lucide-react';
import backgroundImg from '@/assets/background.jpeg';

export const Support = () => {
  return (
    <div className="min-h-screen relative">
      <div className="fixed inset-0 z-0" style={{ backgroundImage: `url(${backgroundImg})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
      <div className="fixed inset-0 z-0 bg-[hsl(220,20%,8%)] opacity-50" />
      <TopNavBar />
      <div className="relative z-10 container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold neon-text mb-4">Support & Contact</h1>
          <p className="text-foreground/80 text-lg">We're here to help you</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          <Card className="holographic-card neon-glow">
            <CardHeader>
              <CardTitle className="text-2xl neon-text flex items-center gap-3">
                <Mail className="w-6 h-6" /> Email Support
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground/80">For enrollment inquiries and general questions:</p>
              <Button variant="neon" className="w-full">enrollment@mnhs.edu.ph</Button>
            </CardContent>
          </Card>

          <Card className="holographic-card neon-glow">
            <CardHeader>
              <CardTitle className="text-2xl neon-text flex items-center gap-3">
                <Phone className="w-6 h-6" /> Phone Support
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground/80">Call us during office hours (8 AM - 5 PM):</p>
              <Button variant="neon" className="w-full">(075) XXX-XXXX</Button>
            </CardContent>
          </Card>

          <Card className="holographic-card neon-glow md:col-span-2">
            <CardHeader>
              <CardTitle className="text-2xl neon-text flex items-center gap-3">
                <MapPin className="w-6 h-6" /> Visit Us
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground/80">Manaoag National High School - Senior High School</p>
              <p className="text-foreground/90 font-medium">Manaoag, Pangasinan<br />Region I - Pangasinan Division II</p>
            </CardContent>
          </Card>

          <Card className="holographic-card neon-glow md:col-span-2">
            <CardHeader>
              <CardTitle className="text-2xl neon-text flex items-center gap-3">
                <HelpCircle className="w-6 h-6" /> Frequently Asked Questions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="glass-effect p-4 rounded-lg">
                <h4 className="font-semibold text-primary mb-2">How do I enroll?</h4>
                <p className="text-foreground/80 text-sm">Click on "Enroll Now" on the homepage and fill out the registration form with your information.</p>
              </div>
              <div className="glass-effect p-4 rounded-lg">
                <h4 className="font-semibold text-primary mb-2">What documents do I need?</h4>
                <p className="text-foreground/80 text-sm">You'll need your birth certificate, report card (Form 138), and other supporting documents as specified in the enrollment form.</p>
              </div>
              <div className="glass-effect p-4 rounded-lg">
                <h4 className="font-semibold text-primary mb-2">When is the enrollment period?</h4>
                <p className="text-foreground/80 text-sm">Enrollment is typically open before the start of each school year. Check with the registrar's office for specific dates.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
