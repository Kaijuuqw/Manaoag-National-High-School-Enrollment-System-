import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { TopNavBar } from "@/components/layout/TopNavBar";
import { Download, Smartphone, Monitor, Apple, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface BeforeInstallPromptEvent extends Event {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export function Install() {
  const navigate = useNavigate();
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", handler);

    if (window.matchMedia("(display-mode: standalone)").matches) {
      setIsInstalled(true);
    }

    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") setIsInstalled(true);
    setDeferredPrompt(null);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <TopNavBar />
      <div className="container mx-auto px-4 py-12 max-w-3xl">
        <Button variant="ghost" onClick={() => navigate(-1)} className="mb-6">
          <ArrowLeft className="h-4 w-4 mr-2" /> Back
        </Button>

        <h1 className="text-3xl font-bold mb-2 text-primary">Install MNHS Enrollment App</h1>
        <p className="text-muted-foreground mb-8">
          Install this app on your device for quick access — no app store needed!
        </p>

        {isInstalled ? (
          <Card className="border-green-500/50 bg-green-500/10">
            <CardContent className="p-6 text-center">
              <p className="text-lg font-semibold text-green-400">✅ App is already installed!</p>
            </CardContent>
          </Card>
        ) : deferredPrompt ? (
          <Card className="border-primary/50 mb-8">
            <CardContent className="p-6 text-center space-y-4">
              <Download className="h-12 w-12 text-primary mx-auto" />
              <p className="text-lg">Ready to install!</p>
              <Button variant="neon" size="lg" onClick={handleInstall}>
                <Download className="h-5 w-5 mr-2" /> Install Now
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Smartphone className="h-5 w-5 text-primary" /> Android (Chrome)
                </CardTitle>
                <CardDescription>Most Android devices</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-muted-foreground">
                <p>1. Open this site in <strong className="text-foreground">Chrome</strong></p>
                <p>2. Tap the <strong className="text-foreground">⋮ menu</strong> (top right)</p>
                <p>3. Tap <strong className="text-foreground">"Install app"</strong> or <strong className="text-foreground">"Add to Home screen"</strong></p>
                <p>4. Confirm the installation</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Apple className="h-5 w-5 text-primary" /> iPhone / iPad (Safari)
                </CardTitle>
                <CardDescription>iOS devices</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-muted-foreground">
                <p>1. Open this site in <strong className="text-foreground">Safari</strong></p>
                <p>2. Tap the <strong className="text-foreground">Share button</strong> (box with arrow)</p>
                <p>3. Scroll down and tap <strong className="text-foreground">"Add to Home Screen"</strong></p>
                <p>4. Tap <strong className="text-foreground">"Add"</strong></p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Monitor className="h-5 w-5 text-primary" /> Desktop (Chrome / Edge)
                </CardTitle>
                <CardDescription>Windows, Mac, Linux</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-muted-foreground">
                <p>1. Look for the <strong className="text-foreground">install icon</strong> in the address bar</p>
                <p>2. Click <strong className="text-foreground">"Install"</strong></p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
