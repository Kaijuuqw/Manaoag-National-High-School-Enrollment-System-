import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { UserCheck, ArrowLeft } from 'lucide-react';

const mnhsLogo = '/lovable-uploads/991cce49-f6ba-47c4-99f6-2b0018498e45.png';
const shsLogo = '/lovable-uploads/b2d5c16f-5aee-4db9-9a76-5a721181b16c.png';

export const LoginSelection = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen school-bg flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        {/* Header */}
        <div className="rounded-lg p-6 mb-6">
          <div className="flex items-center justify-center gap-6 mb-4">
            <div className="w-16 h-16 rounded-full overflow-hidden flex items-center justify-center">
              <img src={mnhsLogo} alt="MNHS Logo" className="w-[85%] h-[85%] object-contain" />
            </div>
            <div className="text-center">
              <h1 className="text-2xl font-bold text-foreground">MNHS - SHS</h1>
              <p className="text-sm text-foreground/70">Enrollment Management System</p>
            </div>
            <div className="w-16 h-16 rounded-full overflow-hidden flex items-center justify-center">
              <img src={shsLogo} alt="SHS Logo" className="w-[85%] h-[85%] object-contain" />
            </div>
          </div>
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="mx-auto flex items-center gap-2 text-foreground/80 hover:text-foreground"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Button>
        </div>

        {/* Login Options */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-2">Choose Login Type</h2>
          <p className="text-foreground/70">Select your role to continue</p>
        </div>

        <div className="max-w-md mx-auto">
          <Card className="holographic-card neon-glow hover:scale-105 transition-all duration-300 cursor-pointer" onClick={() => navigate('/student/login')}>
            <CardHeader className="text-center pb-4">
              <div className="mx-auto w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mb-4">
                <UserCheck className="w-10 h-10 text-primary" />
              </div>
              <CardTitle className="text-2xl text-foreground">Student Login</CardTitle>
              <CardDescription className="text-base text-foreground/70">
                Access your enrollment status and dashboard
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <Button
                onClick={() => navigate('/student/login')}
                className="w-full"
                variant="neon"
                size="lg"
              >
                Login as Student
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
