import { useNavigate } from 'react-router-dom';
import { TopNavBar } from '@/components/layout/TopNavBar';
import QRCode from 'react-qr-code';
import backgroundImg from '@/assets/background.jpeg';

const mnhsLogo = '/lovable-uploads/991cce49-f6ba-47c4-99f6-2b0018498e45.png';
const shsLogo = '/lovable-uploads/b2d5c16f-5aee-4db9-9a76-5a721181b16c.png';

export const HomePage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Full-screen background image */}
      <div 
        className="fixed inset-0 z-0"
        style={{
          backgroundImage: `url(${backgroundImg})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
        }}
      />
      {/* Dark overlay for readability */}
      <div className="fixed inset-0 z-0 bg-[hsl(220,20%,20%)] opacity-40" />

      {/* Top Navigation Bar */}
      <TopNavBar />

      {/* Hidden QR Code - still functional */}
      <div className="hidden">
        <QRCode
          value={`${window.location.origin}/student/register`}
          size={200}
          level="H"
        />
      </div>

      {/* Hero Section */}
      <div className="relative z-10 flex flex-col items-center justify-center px-4 pt-16 pb-8">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground text-center mb-3 drop-shadow-lg"
          style={{ textShadow: '0 2px 20px rgba(0,0,0,0.7)' }}
        >
          Enrollment Management System
        </h1>
        <p className="text-base md:text-lg text-foreground/80 text-center max-w-2xl mb-12"
          style={{ textShadow: '0 1px 10px rgba(0,0,0,0.7)' }}
        >
          Welcome to our digital enrollment platform. Choose your path to academic excellence
        </p>

        {/* Decorative line */}
        <div className="w-48 h-[2px] bg-gradient-to-r from-transparent via-accent to-transparent mb-8" />

        {/* School Info with Logos */}
        <div className="flex items-center justify-center gap-8 md:gap-16 max-w-4xl w-full mb-8">
          {/* MNHS Logo */}
          <div className="w-28 h-28 md:w-40 md:h-40 lg:w-48 lg:h-48 rounded-full overflow-hidden flex items-center justify-center flex-shrink-0">
            <img
              src={mnhsLogo}
              alt="MNHS Logo"
              className="w-[90%] h-[90%] object-contain"
            />
          </div>

          {/* Center Text */}
          <div className="text-center flex-1">
            <p className="text-sm md:text-base font-semibold text-foreground mb-1" style={{ textShadow: '0 1px 8px rgba(0,0,0,0.7)' }}>
              Republic of the Philippines
            </p>
            <p className="text-sm md:text-base font-semibold text-foreground mb-1" style={{ textShadow: '0 1px 8px rgba(0,0,0,0.7)' }}>
              Department of Education
            </p>
            <p className="text-sm md:text-base text-foreground/90 mb-1" style={{ textShadow: '0 1px 8px rgba(0,0,0,0.7)' }}>
              Region I
            </p>
            <p className="text-sm md:text-base text-foreground/90 mb-2" style={{ textShadow: '0 1px 8px rgba(0,0,0,0.7)' }}>
              Pangasinan Division II
            </p>
            <p className="text-base md:text-lg font-bold text-foreground mb-1" style={{ textShadow: '0 1px 8px rgba(0,0,0,0.7)' }}>
              Manaoag National High School
            </p>
            <p className="text-sm md:text-base text-foreground/90 mb-1" style={{ textShadow: '0 1px 8px rgba(0,0,0,0.7)' }}>
              Manaoag Pangasinan
            </p>
            <p className="text-sm md:text-base font-semibold text-foreground" style={{ textShadow: '0 1px 8px rgba(0,0,0,0.7)' }}>
              Senior-High School
            </p>
          </div>

          {/* SHS Logo */}
          <div className="w-28 h-28 md:w-40 md:h-40 lg:w-48 lg:h-48 rounded-full overflow-hidden flex items-center justify-center flex-shrink-0">
            <img
              src={shsLogo}
              alt="SHS Logo"
              className="w-[90%] h-[90%] object-contain"
            />
          </div>
        </div>

        {/* Decorative line */}
        <div className="w-48 h-[2px] bg-gradient-to-r from-transparent via-accent to-transparent mb-8" />

        {/* Excellence in Education */}
        <div className="text-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3" style={{ textShadow: '0 2px 15px rgba(0,0,0,0.7)' }}>
            Excellence in Education
          </h2>
          <p className="text-sm md:text-base text-foreground/80 max-w-2xl mx-auto" style={{ textShadow: '0 1px 8px rgba(0,0,0,0.7)' }}>
            Join our community of learners and discover your potential at Manaoag National High School
          </p>
        </div>
      </div>
    </div>
  );
};
