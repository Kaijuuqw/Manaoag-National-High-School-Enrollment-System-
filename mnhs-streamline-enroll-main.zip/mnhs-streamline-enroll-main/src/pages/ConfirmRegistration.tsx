import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate, useParams, useLocation } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, XCircle, Loader2, Info } from 'lucide-react';
import { confirmEmail } from '@/lib/supabase-storage';

export const ConfirmRegistration = () => {
  const [searchParams] = useSearchParams();
  const params = useParams<{ token?: string }>();
  const location = useLocation();
  const navigate = useNavigate();
  const [status, setStatus] = useState<'loading' | 'success' | 'already_confirmed' | 'error' | 'submitted'>('loading');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const token = searchParams.get('token') || params.token || '';
    const stateMessage = (location.state as any)?.message as string | undefined;

    if (!token && stateMessage) {
      setStatus('submitted');
      setMessage(stateMessage);
      return;
    }

    if (!token) {
      // No token and no state — redirect to dashboard/home instead of showing error
      navigate('/student/dashboard', { replace: true });
      return;
    }

    const confirmEmailAsync = async () => {
      try {
        setStatus('loading');
        setMessage('Confirming your email address...');
        
        const result = await confirmEmail(token);
        
        if (result === 'success') {
          setStatus('success');
          setMessage('Your email has been confirmed successfully! You can now log in to your student dashboard.');
        } else if (result === 'already_confirmed') {
          setStatus('already_confirmed');
          setMessage('Your email has already been confirmed. You can log in to your student dashboard.');
        } else {
          setStatus('error');
          setMessage('Email confirmation failed. The link may be invalid or has already been used. Try using "Resend Confirmation" from the login page.');
        }
      } catch (error) {
        console.error('Confirmation error:', error);
        setStatus('error');
        setMessage('An error occurred during email confirmation. Please try again later.');
      }
    };

    confirmEmailAsync();
  }, [searchParams, params, location.state, navigate]);

  const handleGoToLogin = () => {
    navigate('/student/login');
  };

  const handleGoHome = () => {
    navigate('/');
  };

  return (
    <div className="min-h-screen school-bg flex items-center justify-center p-4">
      <Card className="max-w-md w-full holographic-card neon-glow">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl text-foreground">
            Registration Confirmation
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-6">
          {status === 'loading' && (
            <>
              <Loader2 className="w-12 h-12 text-primary animate-spin mx-auto" />
              <p className="text-foreground/70">Confirming your registration...</p>
            </>
          )}

          {status === 'submitted' && (
            <>
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto" />
              <div className="space-y-2">
                <p className="text-green-400 font-medium">Application Submitted!</p>
                <p className="text-sm text-foreground/70">{message}</p>
              </div>
              <div className="space-y-2">
                <Button onClick={() => navigate('/student/dashboard')} variant="neon" className="w-full">
                  Go to Dashboard
                </Button>
                <Button onClick={handleGoHome} variant="outline" className="w-full">
                  Back to Homepage
                </Button>
              </div>
            </>
          )}


          {status === 'success' && (
            <>
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto" />
              <div className="space-y-2">
                <p className="text-green-400 font-medium">{message}</p>
                <p className="text-sm text-foreground/70">
                  You can now log in to your student dashboard to check your enrollment status.
                </p>
              </div>
              <div className="space-y-2">
                <Button onClick={handleGoToLogin} variant="neon" className="w-full">
                  Go to Student Login
                </Button>
                <Button onClick={handleGoHome} variant="outline" className="w-full">
                  Back to Homepage
                </Button>
              </div>
            </>
          )}

          {status === 'already_confirmed' && (
            <>
              <Info className="w-16 h-16 text-blue-400 mx-auto" />
              <div className="space-y-2">
                <p className="text-blue-400 font-medium">Already Confirmed!</p>
                <p className="text-sm text-foreground/70">{message}</p>
              </div>
              <div className="space-y-2">
                <Button onClick={handleGoToLogin} variant="neon" className="w-full">
                  Go to Student Login
                </Button>
                <Button onClick={handleGoHome} variant="outline" className="w-full">
                  Back to Homepage
                </Button>
              </div>
            </>
          )}

          {status === 'error' && (
            <>
              <XCircle className="w-16 h-16 text-red-500 mx-auto" />
              <div className="space-y-2">
                <p className="text-red-400 font-medium">Confirmation Failed</p>
                <p className="text-sm text-foreground/70">{message}</p>
              </div>
              <div className="space-y-2">
                <Button onClick={handleGoToLogin} variant="neon" className="w-full">
                  Go to Login & Resend Confirmation
                </Button>
                <Button onClick={() => navigate('/')} variant="outline" className="w-full">
                  Back to Homepage
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
