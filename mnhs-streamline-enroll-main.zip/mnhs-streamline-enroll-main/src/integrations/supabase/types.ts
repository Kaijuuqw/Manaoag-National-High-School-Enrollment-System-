export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.12 (cd3cf9e)"
  }
  public: {
    Tables: {
      admin: {
        Row: {
          created_at: string
          id: string
          password: string
          username: string
        }
        Insert: {
          created_at?: string
          id?: string
          password: string
          username: string
        }
        Update: {
          created_at?: string
          id?: string
          password?: string
          username?: string
        }
        Relationships: []
      }
      admin_users: {
        Row: {
          created_at: string
          full_name: string
          id: string
          password_hash: string
          updated_at: string
          username: string
        }
        Insert: {
          created_at?: string
          full_name: string
          id?: string
          password_hash: string
          updated_at?: string
          username: string
        }
        Update: {
          created_at?: string
          full_name?: string
          id?: string
          password_hash?: string
          updated_at?: string
          username?: string
        }
        Relationships: []
      }
      auth_sessions: {
        Row: {
          created_at: string
          expires_at: string
          id: string
          user_data: Json
          user_id: string
          user_type: string
        }
        Insert: {
          created_at?: string
          expires_at?: string
          id?: string
          user_data: Json
          user_id: string
          user_type: string
        }
        Update: {
          created_at?: string
          expires_at?: string
          id?: string
          user_data?: Json
          user_id?: string
          user_type?: string
        }
        Relationships: []
      }
      email_notifications: {
        Row: {
          created_at: string | null
          email_type: string
          id: string
          message: string
          recipient_email: string
          recipient_name: string
          sent_at: string | null
          subject: string
        }
        Insert: {
          created_at?: string | null
          email_type: string
          id?: string
          message: string
          recipient_email: string
          recipient_name: string
          sent_at?: string | null
          subject: string
        }
        Update: {
          created_at?: string | null
          email_type?: string
          id?: string
          message?: string
          recipient_email?: string
          recipient_name?: string
          sent_at?: string | null
          subject?: string
        }
        Relationships: []
      }
      enrollment_applications: {
        Row: {
          barangay: string
          birth_certificate_name: string | null
          birth_certificate_url: string | null
          city: string
          completion_certificate_name: string | null
          completion_certificate_url: string | null
          confirmation_sent_at: string | null
          confirmation_token: string | null
          created_at: string
          date_of_birth: string
          email: string
          email_confirmed: boolean | null
          enrollment_status: string | null
          fathers_name: string
          first_name: string
          four_ps_contact_number: string | null
          four_ps_id_number: string | null
          four_ps_parents_name: string | null
          four_ps_student_name: string | null
          gender: string
          general_average: number | null
          grade_level: string | null
          id: string
          is_4ps: boolean | null
          is_balik_aral: boolean | null
          is_transfer_student: boolean | null
          last_name: string
          lrn: string
          middle_name: string | null
          mothers_maiden_name: string
          parents_contact_number: string
          password_hash: string
          place_of_birth: string
          previous_adviser: string | null
          previous_grade: string | null
          previous_section: string | null
          province: string
          religion: string | null
          report_card_name: string | null
          report_card_url: string | null
          reset_token: string | null
          reset_token_expires_at: string | null
          strand: string
          street: string | null
          transfer_adviser: string | null
          transfer_average: number | null
          transfer_grade: string | null
          transfer_school: string | null
          transfer_section: string | null
          updated_at: string
          zone: string | null
        }
        Insert: {
          barangay: string
          birth_certificate_name?: string | null
          birth_certificate_url?: string | null
          city: string
          completion_certificate_name?: string | null
          completion_certificate_url?: string | null
          confirmation_sent_at?: string | null
          confirmation_token?: string | null
          created_at?: string
          date_of_birth: string
          email: string
          email_confirmed?: boolean | null
          enrollment_status?: string | null
          fathers_name: string
          first_name: string
          four_ps_contact_number?: string | null
          four_ps_id_number?: string | null
          four_ps_parents_name?: string | null
          four_ps_student_name?: string | null
          gender: string
          general_average?: number | null
          grade_level?: string | null
          id?: string
          is_4ps?: boolean | null
          is_balik_aral?: boolean | null
          is_transfer_student?: boolean | null
          last_name: string
          lrn: string
          middle_name?: string | null
          mothers_maiden_name: string
          parents_contact_number: string
          password_hash: string
          place_of_birth: string
          previous_adviser?: string | null
          previous_grade?: string | null
          previous_section?: string | null
          province: string
          religion?: string | null
          report_card_name?: string | null
          report_card_url?: string | null
          reset_token?: string | null
          reset_token_expires_at?: string | null
          strand: string
          street?: string | null
          transfer_adviser?: string | null
          transfer_average?: number | null
          transfer_grade?: string | null
          transfer_school?: string | null
          transfer_section?: string | null
          updated_at?: string
          zone?: string | null
        }
        Update: {
          barangay?: string
          birth_certificate_name?: string | null
          birth_certificate_url?: string | null
          city?: string
          completion_certificate_name?: string | null
          completion_certificate_url?: string | null
          confirmation_sent_at?: string | null
          confirmation_token?: string | null
          created_at?: string
          date_of_birth?: string
          email?: string
          email_confirmed?: boolean | null
          enrollment_status?: string | null
          fathers_name?: string
          first_name?: string
          four_ps_contact_number?: string | null
          four_ps_id_number?: string | null
          four_ps_parents_name?: string | null
          four_ps_student_name?: string | null
          gender?: string
          general_average?: number | null
          grade_level?: string | null
          id?: string
          is_4ps?: boolean | null
          is_balik_aral?: boolean | null
          is_transfer_student?: boolean | null
          last_name?: string
          lrn?: string
          middle_name?: string | null
          mothers_maiden_name?: string
          parents_contact_number?: string
          password_hash?: string
          place_of_birth?: string
          previous_adviser?: string | null
          previous_grade?: string | null
          previous_section?: string | null
          province?: string
          religion?: string | null
          report_card_name?: string | null
          report_card_url?: string | null
          reset_token?: string | null
          reset_token_expires_at?: string | null
          strand?: string
          street?: string | null
          transfer_adviser?: string | null
          transfer_average?: number | null
          transfer_grade?: string | null
          transfer_school?: string | null
          transfer_section?: string | null
          updated_at?: string
          zone?: string | null
        }
        Relationships: []
      }
      pending_signups: {
        Row: {
          attempts: number
          created_at: string
          email: string
          email_confirmed: boolean
          enrollment_started: boolean
          first_name: string
          id: string
          last_name: string
          otp_expires_at: string | null
          otp_hash: string | null
          password_hash: string
          updated_at: string
        }
        Insert: {
          attempts?: number
          created_at?: string
          email: string
          email_confirmed?: boolean
          enrollment_started?: boolean
          first_name: string
          id?: string
          last_name: string
          otp_expires_at?: string | null
          otp_hash?: string | null
          password_hash: string
          updated_at?: string
        }
        Update: {
          attempts?: number
          created_at?: string
          email?: string
          email_confirmed?: boolean
          enrollment_started?: boolean
          first_name?: string
          id?: string
          last_name?: string
          otp_expires_at?: string | null
          otp_hash?: string | null
          password_hash?: string
          updated_at?: string
        }
        Relationships: []
      }
      students: {
        Row: {
          barangay: string
          birth_certificate: string | null
          birth_certificate_name: string | null
          certificate_of_completion: string | null
          certificate_of_completion_name: string | null
          city: string
          confirmation_sent_at: string | null
          confirmation_token: string | null
          contact_number: string
          created_at: string
          date_of_birth: string
          email: string
          email_confirmed: boolean | null
          enrollment_date: string
          enrollment_status: string
          fathers_name: string
          first_name: string
          four_ps_contact_number: string | null
          four_ps_id_number: string | null
          four_ps_parent_name: string | null
          four_ps_student_name: string | null
          gender: string
          general_average: number | null
          grade_level: string | null
          id: string
          is_4ps: boolean
          is_balik_aral: boolean | null
          is_transfer_student: boolean | null
          last_name: string
          lrn: string
          middle_name: string | null
          mothers_maiden_name: string
          password: string
          place_of_birth: string
          previous_adviser: string | null
          previous_grade: string
          previous_section: string
          province: string
          religion: string
          report_card: string | null
          report_card_back: string | null
          report_card_back_name: string | null
          report_card_front: string | null
          report_card_front_name: string | null
          report_card_name: string | null
          reset_token: string | null
          reset_token_expires_at: string | null
          section: string | null
          strand: string
          street: string | null
          transfer_adviser: string | null
          transfer_average: number | null
          transfer_grade: string | null
          transfer_school: string | null
          transfer_section: string | null
          updated_at: string
          zone: string | null
        }
        Insert: {
          barangay?: string
          birth_certificate?: string | null
          birth_certificate_name?: string | null
          certificate_of_completion?: string | null
          certificate_of_completion_name?: string | null
          city?: string
          confirmation_sent_at?: string | null
          confirmation_token?: string | null
          contact_number?: string
          created_at?: string
          date_of_birth: string
          email?: string
          email_confirmed?: boolean | null
          enrollment_date?: string
          enrollment_status?: string
          fathers_name?: string
          first_name: string
          four_ps_contact_number?: string | null
          four_ps_id_number?: string | null
          four_ps_parent_name?: string | null
          four_ps_student_name?: string | null
          gender: string
          general_average?: number | null
          grade_level?: string | null
          id?: string
          is_4ps?: boolean
          is_balik_aral?: boolean | null
          is_transfer_student?: boolean | null
          last_name: string
          lrn: string
          middle_name?: string | null
          mothers_maiden_name: string
          password?: string
          place_of_birth?: string
          previous_adviser?: string | null
          previous_grade?: string
          previous_section?: string
          province?: string
          religion?: string
          report_card?: string | null
          report_card_back?: string | null
          report_card_back_name?: string | null
          report_card_front?: string | null
          report_card_front_name?: string | null
          report_card_name?: string | null
          reset_token?: string | null
          reset_token_expires_at?: string | null
          section?: string | null
          strand: string
          street?: string | null
          transfer_adviser?: string | null
          transfer_average?: number | null
          transfer_grade?: string | null
          transfer_school?: string | null
          transfer_section?: string | null
          updated_at?: string
          zone?: string | null
        }
        Update: {
          barangay?: string
          birth_certificate?: string | null
          birth_certificate_name?: string | null
          certificate_of_completion?: string | null
          certificate_of_completion_name?: string | null
          city?: string
          confirmation_sent_at?: string | null
          confirmation_token?: string | null
          contact_number?: string
          created_at?: string
          date_of_birth?: string
          email?: string
          email_confirmed?: boolean | null
          enrollment_date?: string
          enrollment_status?: string
          fathers_name?: string
          first_name?: string
          four_ps_contact_number?: string | null
          four_ps_id_number?: string | null
          four_ps_parent_name?: string | null
          four_ps_student_name?: string | null
          gender?: string
          general_average?: number | null
          grade_level?: string | null
          id?: string
          is_4ps?: boolean
          is_balik_aral?: boolean | null
          is_transfer_student?: boolean | null
          last_name?: string
          lrn?: string
          middle_name?: string | null
          mothers_maiden_name?: string
          password?: string
          place_of_birth?: string
          previous_adviser?: string | null
          previous_grade?: string
          previous_section?: string
          province?: string
          religion?: string
          report_card?: string | null
          report_card_back?: string | null
          report_card_back_name?: string | null
          report_card_front?: string | null
          report_card_front_name?: string | null
          report_card_name?: string | null
          reset_token?: string | null
          reset_token_expires_at?: string | null
          section?: string | null
          strand?: string
          street?: string | null
          transfer_adviser?: string | null
          transfer_average?: number | null
          transfer_grade?: string | null
          transfer_school?: string | null
          transfer_section?: string | null
          updated_at?: string
          zone?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      clean_expired_sessions: { Args: never; Returns: undefined }
      is_admin_user: { Args: never; Returns: boolean }
      send_enrollment_notification: {
        Args: {
          enrollment_status?: string
          notification_type: string
          student_email: string
          student_name: string
        }
        Returns: undefined
      }
      set_config: {
        Args: {
          is_local?: boolean
          setting_name: string
          setting_value: string
        }
        Returns: undefined
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
