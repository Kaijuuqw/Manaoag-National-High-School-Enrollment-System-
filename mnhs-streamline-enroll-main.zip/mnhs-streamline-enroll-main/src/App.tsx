import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { HomePage } from "./pages/HomePage";
import { Strands } from "./pages/Strands";
import { About } from "./pages/About";
import { Support } from "./pages/Support";
import { LoginSelection } from "./pages/LoginSelection";
import { ConfirmRegistration } from "./pages/ConfirmRegistration";
import { QRCodeInfo } from "./pages/QRCodeInfo";
import { AdminLogin } from "./components/auth/AdminLogin";
import { StudentLogin } from "./components/auth/StudentLogin";
import { StudentSignup } from "./components/auth/StudentSignup";
import { VerifyOtp } from "./components/auth/VerifyOtp";
import { StudentRegistration } from "./components/enrollment/StudentRegistration";
import { EnhancedRegistrationForm } from "./components/enrollment/EnhancedRegistrationForm";
import { StudentDashboard } from "./components/dashboard/StudentDashboard";
import { AdminDashboard } from "./components/dashboard/AdminDashboard";
import { initializeStorage } from "./lib/supabase-storage";
import NotFound from "./pages/NotFound";
import ResetPassword from "./pages/ResetPassword";
import { Install } from "./pages/Install";

const queryClient = new QueryClient();

// Initialize storage on app start
initializeStorage().catch(console.error);

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/strands" element={<Strands />} />
          <Route path="/about" element={<About />} />
          <Route path="/support" element={<Support />} />
          <Route path="/login" element={<LoginSelection />} />
          <Route path="/confirm-registration" element={<ConfirmRegistration />} />
          <Route path="/confirm-registration/:token" element={<ConfirmRegistration />} />
          <Route path="/qr-code-info" element={<QRCodeInfo />} />
          <Route path="/portal-mnhs-staff-9k2x7q" element={<AdminLogin />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/student/login" element={<StudentLogin />} />
          <Route path="/student/signup" element={<StudentSignup />} />
          <Route path="/student/verify-otp" element={<VerifyOtp />} />
          <Route path="/student/reset-password" element={<ResetPassword />} />
          <Route path="/student/register" element={<EnhancedRegistrationForm />} />
          <Route path="/student/register/legacy" element={<StudentRegistration />} />
          <Route path="/student/dashboard" element={<StudentDashboard />} />
          <Route path="/install" element={<Install />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
