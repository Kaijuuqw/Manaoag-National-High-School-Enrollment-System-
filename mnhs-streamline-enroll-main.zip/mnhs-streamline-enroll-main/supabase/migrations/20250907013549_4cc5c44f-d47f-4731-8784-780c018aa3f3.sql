-- Update strand constraint to include all possible strand values
ALTER TABLE public.students 
DROP CONSTRAINT IF EXISTS students_strand_check;

-- Add updated constraint with all strand values
ALTER TABLE public.students 
ADD CONSTRAINT students_strand_check 
CHECK (strand = ANY (ARRAY[
  'ICT'::text, 
  'COOKERY'::text, 
  'EPAS'::text, 
  'BPP'::text,
  'ABM'::text, 
  'STEM'::text,
  'HUMSS'::text,
  'ALS'::text
]));

-- Also update enrollment_status constraint to use 'Denied' instead of 'Rejected'
ALTER TABLE public.students 
DROP CONSTRAINT IF EXISTS students_enrollment_status_check;

ALTER TABLE public.students 
ADD CONSTRAINT students_enrollment_status_check 
CHECK (enrollment_status = ANY (ARRAY['Pending'::text, 'Approved'::text, 'Denied'::text]));