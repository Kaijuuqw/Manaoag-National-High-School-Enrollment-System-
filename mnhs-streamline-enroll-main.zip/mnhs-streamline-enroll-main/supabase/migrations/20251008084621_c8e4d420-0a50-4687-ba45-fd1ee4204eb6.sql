-- CRITICAL SECURITY FIXES (Revised)

-- ============================================
-- 1. FIX RLS POLICIES - ADMIN TABLE
-- ============================================
DROP POLICY IF EXISTS "Admin can access their own data" ON public.admin;
DROP POLICY IF EXISTS "Anyone can access admin data" ON public.admin_users;

CREATE POLICY "Admin table not accessible from client"
ON public.admin
FOR ALL
USING (false);

CREATE POLICY "Admin users not accessible from client"
ON public.admin_users
FOR ALL
USING (false);

-- ============================================
-- 2. FIX RLS POLICIES - AUTH SESSIONS TABLE
-- ============================================
DROP POLICY IF EXISTS "Anyone can access sessions" ON public.auth_sessions;

CREATE POLICY "Sessions not accessible from client"
ON public.auth_sessions
FOR ALL
USING (false);

-- ============================================
-- 3. FIX RLS POLICIES - STUDENTS TABLE
-- ============================================
DROP POLICY IF EXISTS "Public can insert students" ON public.students;
DROP POLICY IF EXISTS "Students can view own data" ON public.students;
DROP POLICY IF EXISTS "Students can update own data" ON public.students;
DROP POLICY IF EXISTS "Admins can view all students" ON public.students;
DROP POLICY IF EXISTS "Admins can update all students" ON public.students;
DROP POLICY IF EXISTS "Admins can delete students" ON public.students;

CREATE POLICY "Allow registration inserts"
ON public.students
FOR INSERT
WITH CHECK (true);

CREATE POLICY "Restrict client access until auth fixed"
ON public.students
FOR SELECT
USING (false);

CREATE POLICY "Restrict updates until auth fixed"
ON public.students
FOR UPDATE
USING (false);

CREATE POLICY "Restrict deletes until auth fixed"
ON public.students
FOR DELETE
USING (false);

-- ============================================
-- 4. FIX STORAGE BUCKET - MAKE PRIVATE
-- ============================================
UPDATE storage.buckets 
SET public = false 
WHERE id = 'student-documents';

DROP POLICY IF EXISTS "Anyone can upload documents" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can view documents" ON storage.objects;
DROP POLICY IF EXISTS "Public access to student documents" ON storage.objects;

CREATE POLICY "Restrict document access until auth fixed"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'student-documents' AND
  false
);

-- ============================================
-- 5. ADD INPUT VALIDATION CONSTRAINTS
-- ============================================

-- Email format validation
ALTER TABLE public.students
DROP CONSTRAINT IF EXISTS students_email_format;

ALTER TABLE public.students
ADD CONSTRAINT students_email_format
CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$');

-- LRN must be 12 digits
ALTER TABLE public.students
DROP CONSTRAINT IF EXISTS students_lrn_length;

ALTER TABLE public.students
ADD CONSTRAINT students_lrn_length
CHECK (length(lrn) = 12 AND lrn ~ '^[0-9]{12}$');

-- Name length constraints
ALTER TABLE public.students
DROP CONSTRAINT IF EXISTS students_first_name_length;

ALTER TABLE public.students
ADD CONSTRAINT students_first_name_length
CHECK (length(trim(first_name)) BETWEEN 1 AND 100);

ALTER TABLE public.students
DROP CONSTRAINT IF EXISTS students_last_name_length;

ALTER TABLE public.students
ADD CONSTRAINT students_last_name_length
CHECK (length(trim(last_name)) BETWEEN 1 AND 100);

-- Gender validation
ALTER TABLE public.students
DROP CONSTRAINT IF EXISTS students_gender_check;

ALTER TABLE public.students
ADD CONSTRAINT students_gender_check
CHECK (gender IN ('Male', 'Female'));

-- Enrollment status validation
ALTER TABLE public.students
DROP CONSTRAINT IF EXISTS students_enrollment_status_check;

ALTER TABLE public.students
ADD CONSTRAINT students_enrollment_status_check
CHECK (enrollment_status IN ('Pending', 'Approved', 'Denied'));

-- Contact number validation (flexible for various formats)
ALTER TABLE public.students
DROP CONSTRAINT IF EXISTS students_contact_format;

ALTER TABLE public.students
ADD CONSTRAINT students_contact_format
CHECK (contact_number ~ '^[0-9]{10,15}$');

-- ============================================
-- 6. FIX ENROLLMENT APPLICATIONS TABLE
-- ============================================
DROP POLICY IF EXISTS "Anyone can view applications" ON public.enrollment_applications;
DROP POLICY IF EXISTS "Anyone can insert applications" ON public.enrollment_applications;
DROP POLICY IF EXISTS "Students can update their own applications" ON public.enrollment_applications;
DROP POLICY IF EXISTS "Admins can delete applications" ON public.enrollment_applications;

CREATE POLICY "Restrict enrollment apps until auth fixed"
ON public.enrollment_applications
FOR ALL
USING (false);

-- ============================================
-- 7. FIX EMAIL NOTIFICATIONS TABLE
-- ============================================
DROP POLICY IF EXISTS "Admins can manage email notifications" ON public.email_notifications;

CREATE POLICY "Email notifications server-side only"
ON public.email_notifications
FOR ALL
USING (false);