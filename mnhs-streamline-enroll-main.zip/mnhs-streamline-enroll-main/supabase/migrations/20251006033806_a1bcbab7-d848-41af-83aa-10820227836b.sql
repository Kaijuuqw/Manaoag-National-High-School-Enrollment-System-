-- Temporarily disable RLS to test
ALTER TABLE public.students DISABLE ROW LEVEL SECURITY;

-- Re-enable RLS 
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;

-- Drop and recreate the INSERT policy with explicit permissions
DROP POLICY IF EXISTS "Allow all student insertions" ON public.students;

-- Create a new INSERT policy that explicitly allows all insertions
CREATE POLICY "Public can insert students" 
ON public.students 
FOR INSERT 
TO public
WITH CHECK (true);