-- First, check existing policies and drop them properly
DO $$ 
BEGIN
    -- Drop existing policies if they exist
    DROP POLICY IF EXISTS "Allow public student registration" ON public.students;
    DROP POLICY IF EXISTS "Students can view own data" ON public.students;
    DROP POLICY IF EXISTS "Students can update own data" ON public.students;
    DROP POLICY IF EXISTS "Admins can view all students" ON public.students;
    DROP POLICY IF EXISTS "Admins can update all students" ON public.students;
    DROP POLICY IF EXISTS "Admins can delete students" ON public.students;
    
    -- Drop the old overly permissive policies
    DROP POLICY IF EXISTS "Anyone can delete students" ON public.students;
    DROP POLICY IF EXISTS "Anyone can insert students" ON public.students;  
    DROP POLICY IF EXISTS "Anyone can update students" ON public.students;
    DROP POLICY IF EXISTS "Anyone can view students" ON public.students;
END $$;

-- Create security definer function to check if user is admin
CREATE OR REPLACE FUNCTION public.is_admin_user()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.admin_users 
    WHERE username = current_setting('app.current_admin_username', true)
  ) OR EXISTS (
    SELECT 1 FROM public.admin 
    WHERE username = current_setting('app.current_admin_username', true)
  );
$$;

-- Create secure RLS policies for students table
-- Allow public insertion for enrollment process (new registrations)
CREATE POLICY "Allow public student registration" 
ON public.students 
FOR INSERT 
WITH CHECK (true);

-- Students can view only their own data (using email for identification)
CREATE POLICY "Students can view own data" 
ON public.students 
FOR SELECT 
USING (email = current_setting('app.current_user_email', true));

-- Students can update only their own data
CREATE POLICY "Students can update own data" 
ON public.students 
FOR UPDATE 
USING (email = current_setting('app.current_user_email', true));

-- Admins can view all student data
CREATE POLICY "Admins can view all students" 
ON public.students 
FOR SELECT 
USING (public.is_admin_user());

-- Admins can update all student data
CREATE POLICY "Admins can update all students" 
ON public.students 
FOR UPDATE 
USING (public.is_admin_user());

-- Admins can delete student data
CREATE POLICY "Admins can delete students" 
ON public.students 
FOR DELETE 
USING (public.is_admin_user());