-- Drop and recreate the INSERT policy to ensure it works properly
DROP POLICY IF EXISTS "students_insert_policy" ON public.students;

-- Create a simple INSERT policy that allows all insertions
CREATE POLICY "Allow all student insertions" 
ON public.students 
FOR INSERT 
WITH CHECK (true);

-- Check if there are any constraints that might be causing issues
-- Let's also make sure the table structure is correct