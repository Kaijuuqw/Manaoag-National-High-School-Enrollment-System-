-- Add separate columns for report card front and back
ALTER TABLE public.students 
  ADD COLUMN IF NOT EXISTS report_card_front TEXT,
  ADD COLUMN IF NOT EXISTS report_card_back TEXT,
  ADD COLUMN IF NOT EXISTS report_card_front_name TEXT,
  ADD COLUMN IF NOT EXISTS report_card_back_name TEXT;

-- Copy existing report_card data to report_card_front for backwards compatibility
UPDATE public.students 
SET report_card_front = report_card,
    report_card_front_name = report_card_name
WHERE report_card IS NOT NULL AND report_card_front IS NULL;

-- Note: report_card and report_card_name columns are kept for backwards compatibility with legacy forms