-- Fix RLS policy for student registration to ensure public access
DROP POLICY IF EXISTS "Allow public student registration" ON public.students;

CREATE POLICY "Allow public student registration" 
ON public.students 
FOR INSERT 
WITH CHECK (true);

-- Also ensure the policy is permissive (not restrictive)
ALTER POLICY "Allow public student registration" ON public.students RENAME TO "Public student registration allowed";