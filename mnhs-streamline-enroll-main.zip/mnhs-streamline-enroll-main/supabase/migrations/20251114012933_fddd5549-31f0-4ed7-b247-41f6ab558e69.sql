-- Fix strand constraint to match all current UI values
ALTER TABLE public.students DROP CONSTRAINT IF EXISTS students_strand_check;

ALTER TABLE public.students ADD CONSTRAINT students_strand_check 
CHECK (
  strand = ANY (ARRAY[
    -- Legacy single values
    'ICT'::text, 'COOKERY'::text, 'EPAS'::text, 'BPP'::text,
    'ABM'::text, 'STEM'::text, 'HUMSS'::text, 'ALS'::text,
    -- TVL variants with hyphen (matching normalized format from UI)
    'TVL-ICT'::text, 'TVL-EPAS'::text, 'TVL-COOKERY'::text, 'TVL-BPP'::text,
    'TVL-HE'::text, 'GAS'::text
  ])
);