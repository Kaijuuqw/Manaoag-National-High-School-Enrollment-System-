-- Add email confirmation fields to students table
ALTER TABLE public.students 
ADD COLUMN email_confirmed boolean DEFAULT false,
ADD COLUMN confirmation_token text,
ADD COLUMN confirmation_sent_at timestamp with time zone;