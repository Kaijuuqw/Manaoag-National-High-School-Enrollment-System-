-- Add missing columns to students table to match the existing data structure
ALTER TABLE public.students 
ADD COLUMN IF NOT EXISTS place_of_birth text NOT NULL DEFAULT '',
ADD COLUMN IF NOT EXISTS zone text,
ADD COLUMN IF NOT EXISTS street text,
ADD COLUMN IF NOT EXISTS barangay text NOT NULL DEFAULT '',
ADD COLUMN IF NOT EXISTS city text NOT NULL DEFAULT '',
ADD COLUMN IF NOT EXISTS province text NOT NULL DEFAULT '',
ADD COLUMN IF NOT EXISTS previous_grade text NOT NULL DEFAULT '',
ADD COLUMN IF NOT EXISTS previous_section text NOT NULL DEFAULT '',
ADD COLUMN IF NOT EXISTS fathers_name text NOT NULL DEFAULT '',
ADD COLUMN IF NOT EXISTS contact_number text NOT NULL DEFAULT '',
ADD COLUMN IF NOT EXISTS religion text NOT NULL DEFAULT '',
ADD COLUMN IF NOT EXISTS is_4ps boolean NOT NULL DEFAULT false,
ADD COLUMN IF NOT EXISTS four_ps_student_name text,
ADD COLUMN IF NOT EXISTS four_ps_parent_name text,
ADD COLUMN IF NOT EXISTS four_ps_id_number text,
ADD COLUMN IF NOT EXISTS four_ps_contact_number text,
ADD COLUMN IF NOT EXISTS enrollment_date timestamp with time zone NOT NULL DEFAULT now(),
ADD COLUMN IF NOT EXISTS password text NOT NULL DEFAULT '',
ADD COLUMN IF NOT EXISTS birth_certificate text,
ADD COLUMN IF NOT EXISTS report_card text,
ADD COLUMN IF NOT EXISTS birth_certificate_name text,
ADD COLUMN IF NOT EXISTS report_card_name text;

-- Create admin table for admin authentication
CREATE TABLE IF NOT EXISTS public.admin (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  username text NOT NULL UNIQUE,
  password text NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on admin table
ALTER TABLE public.admin ENABLE ROW LEVEL SECURITY;

-- Create policy for admin access
CREATE POLICY "Admin can access their own data" 
ON public.admin 
FOR ALL 
USING (true);

-- Insert default admin if it doesn't exist
INSERT INTO public.admin (username, password) 
VALUES ('admin', 'admin01052006')
ON CONFLICT (username) DO NOTHING;

-- Create user session table for authentication
CREATE TABLE IF NOT EXISTS public.user_sessions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id text NOT NULL,
  user_type text NOT NULL CHECK (user_type IN ('student', 'admin')),
  user_data jsonb NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  expires_at timestamp with time zone NOT NULL DEFAULT (now() + interval '7 days')
);

-- Enable RLS on sessions table  
ALTER TABLE public.user_sessions ENABLE ROW LEVEL SECURITY;

-- Create policy for session access
CREATE POLICY "Users can access their own sessions" 
ON public.user_sessions 
FOR ALL 
USING (true);

-- Add RLS policies for UPDATE and DELETE on students table
CREATE POLICY "Anyone can update students" 
ON public.students 
FOR UPDATE 
USING (true);

CREATE POLICY "Anyone can delete students" 
ON public.students 
FOR DELETE 
USING (true);

-- Create function to clean expired sessions
CREATE OR REPLACE FUNCTION public.clean_expired_sessions()
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  DELETE FROM public.user_sessions 
  WHERE expires_at < now();
END;
$$;