-- Update students.strand constraint to allow legacy and new values
ALTER TABLE public.students DROP CONSTRAINT IF EXISTS students_strand_check;

ALTER TABLE public.students ADD CONSTRAINT students_strand_check 
CHECK (
  strand = ANY (ARRAY[
    -- Legacy values
    'ICT'::text, 'COOKERY'::text, 'EPAS'::text, 'BPP'::text,
    'ABM'::text, 'STEM'::text, 'HUMSS'::text, 'ALS'::text,
    -- New normalized values
    'TVL-ICT'::text, 'TVL-HE'::text, 'GAS'::text
  ])
);
