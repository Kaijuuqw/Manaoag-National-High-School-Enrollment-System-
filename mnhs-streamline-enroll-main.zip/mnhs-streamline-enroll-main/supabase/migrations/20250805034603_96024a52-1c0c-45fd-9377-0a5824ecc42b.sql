-- Add email column to students table
ALTER TABLE public.students 
ADD COLUMN email text NOT NULL DEFAULT '';