-- Add reset token fields to students table
ALTER TABLE public.students 
ADD COLUMN IF NOT EXISTS reset_token text,
ADD COLUMN IF NOT EXISTS reset_token_expires_at timestamp with time zone;

-- Create index for faster token lookups
CREATE INDEX IF NOT EXISTS idx_students_reset_token ON public.students(reset_token);