-- Add new fields to students table for enhanced enrollment functionality
ALTER TABLE public.students 
ADD COLUMN IF NOT EXISTS is_balik_aral boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS is_transfer_student boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS previous_adviser text,
ADD COLUMN IF NOT EXISTS general_average numeric,
ADD COLUMN IF NOT EXISTS transfer_school text,
ADD COLUMN IF NOT EXISTS transfer_grade text,
ADD COLUMN IF NOT EXISTS transfer_section text,
ADD COLUMN IF NOT EXISTS transfer_adviser text,
ADD COLUMN IF NOT EXISTS transfer_average numeric,
ADD COLUMN IF NOT EXISTS grade_level text,
ADD COLUMN IF NOT EXISTS certificate_of_completion text,
ADD COLUMN IF NOT EXISTS certificate_of_completion_name text;

-- Update mothers_name column to mothers_maiden_name (rename)
ALTER TABLE public.students 
RENAME COLUMN mothers_name TO mothers_maiden_name;

-- Add new fields to enrollment_applications table as well
ALTER TABLE public.enrollment_applications
ADD COLUMN IF NOT EXISTS previous_adviser text,
ADD COLUMN IF NOT EXISTS general_average numeric;