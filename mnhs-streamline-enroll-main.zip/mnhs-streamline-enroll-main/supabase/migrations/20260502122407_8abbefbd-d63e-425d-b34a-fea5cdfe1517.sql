-- Remove all unverified accounts from the system
DELETE FROM public.students WHERE email_confirmed IS NOT TRUE;
DELETE FROM public.enrollment_applications WHERE email_confirmed IS NOT TRUE;
DELETE FROM public.pending_signups WHERE email_confirmed IS NOT TRUE;