-- Make the student-documents bucket public so files can be accessed via public URLs
UPDATE storage.buckets 
SET public = true 
WHERE id = 'student-documents';

-- Drop the restrictive policy that blocks all access
DROP POLICY IF EXISTS "Restrict document access until auth fixed" ON storage.objects;

-- Ensure the public read policy exists and is correct
DROP POLICY IF EXISTS "Anyone can view student documents" ON storage.objects;
CREATE POLICY "Public read access for student documents"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'student-documents');