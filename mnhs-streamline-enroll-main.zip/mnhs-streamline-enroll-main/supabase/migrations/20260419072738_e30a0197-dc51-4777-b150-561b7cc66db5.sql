
CREATE TABLE IF NOT EXISTS public.pending_signups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  password_hash text NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  otp_hash text,
  otp_expires_at timestamptz,
  attempts integer NOT NULL DEFAULT 0,
  email_confirmed boolean NOT NULL DEFAULT false,
  enrollment_started boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pending_signups_email_format CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
  CONSTRAINT pending_signups_first_name_length CHECK (length(trim(first_name)) BETWEEN 1 AND 100),
  CONSTRAINT pending_signups_last_name_length CHECK (length(trim(last_name)) BETWEEN 1 AND 100)
);

CREATE INDEX IF NOT EXISTS idx_pending_signups_email_lower ON public.pending_signups (lower(email));

ALTER TABLE public.pending_signups ENABLE ROW LEVEL SECURITY;

-- Server-side only: clients cannot read or write directly. Edge functions use service role.
CREATE POLICY "pending_signups_no_client_access" ON public.pending_signups FOR ALL USING (false) WITH CHECK (false);

CREATE TRIGGER pending_signups_set_updated_at
BEFORE UPDATE ON public.pending_signups
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
