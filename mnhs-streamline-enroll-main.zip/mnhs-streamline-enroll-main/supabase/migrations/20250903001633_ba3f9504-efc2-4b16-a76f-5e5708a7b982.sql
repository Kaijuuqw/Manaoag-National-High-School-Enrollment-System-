-- Fix the clean_expired_sessions function to use the correct table name
CREATE OR REPLACE FUNCTION public.clean_expired_sessions()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  DELETE FROM public.auth_sessions 
  WHERE expires_at < now();
END;
$function$;