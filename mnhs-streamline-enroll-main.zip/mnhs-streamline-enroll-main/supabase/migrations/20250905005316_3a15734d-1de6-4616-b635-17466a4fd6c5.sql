-- Drop all existing INSERT policies and recreate a simple one
DROP POLICY IF EXISTS "Public student registration allowed" ON public.students;
DROP POLICY IF EXISTS "Allow public student registration" ON public.students;
DROP POLICY IF EXISTS "Anyone can insert students" ON public.students;

-- Create a clean, simple INSERT policy that allows anyone to register
CREATE POLICY "students_insert_policy" 
ON public.students 
FOR INSERT 
WITH CHECK (true);

-- Verify RLS is enabled
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;