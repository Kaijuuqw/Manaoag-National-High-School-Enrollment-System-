-- Create storage bucket for student documents
INSERT INTO storage.buckets (id, name, public) VALUES ('student-documents', 'student-documents', true);

-- Create policies for student documents bucket
CREATE POLICY "Anyone can view student documents" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'student-documents');

CREATE POLICY "Anyone can upload student documents" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'student-documents');

CREATE POLICY "Anyone can update student documents" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'student-documents');