import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "npm:resend@2.0.0";
import bcrypt from "npm:bcryptjs@2.4.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { email, password, firstName, lastName } = await req.json();

    // Validation
    const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
    if (!email || !emailRegex.test(String(email))) {
      return json({ error: "Invalid email address" }, 400);
    }
    if (!password || String(password).length < 6) {
      return json({ error: "Password must be at least 6 characters" }, 400);
    }
    if (!firstName || !String(firstName).trim() || String(firstName).trim().length > 100) {
      return json({ error: "First name is required (max 100 chars)" }, 400);
    }
    if (!lastName || !String(lastName).trim() || String(lastName).trim().length > 100) {
      return json({ error: "Last name is required (max 100 chars)" }, 400);
    }

    const normalizedEmail = String(email).trim().toLowerCase();
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Block if a confirmed student account already exists with this email
    const { data: existingStudent } = await supabase
      .from("students")
      .select("id, email_confirmed")
      .ilike("email", normalizedEmail)
      .maybeSingle();
    if (existingStudent?.email_confirmed) {
      return json({ error: "An account with this email already exists. Please log in." }, 409);
    }

    // Generate 6-digit OTP
    const otp = String(Math.floor(100000 + Math.random() * 900000));
    const otpHash = await bcrypt.hash(otp, 10);
    const passwordHash = await bcrypt.hash(String(password), 10);
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();

    // Upsert pending signup (resend OTP scenario)
    const { error: upsertError } = await supabase
      .from("pending_signups")
      .upsert(
        {
          email: normalizedEmail,
          password_hash: passwordHash,
          first_name: String(firstName).trim(),
          last_name: String(lastName).trim(),
          otp_hash: otpHash,
          otp_expires_at: expiresAt,
          attempts: 0,
          email_confirmed: false,
          enrollment_started: false,
        },
        { onConflict: "email" }
      );

    if (upsertError) {
      console.error("Upsert error:", upsertError);
      return json({ error: "Failed to create signup. Please try again." }, 500);
    }

    // Send OTP via Resend
    const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
    const studentName = `${String(firstName).trim()} ${String(lastName).trim()}`;
    await resend.emails.send({
      from: "MNHS Enrollment <noreply@mnhs-shs.work.gd>",
      to: [normalizedEmail],
      subject: `Your MNHS verification code: ${otp}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="text-align: center; margin-bottom: 24px;">
            <h1 style="color: #1a365d; margin-bottom: 4px;">Manaoag National High School</h1>
            <h2 style="color: #2d5aa0; margin: 0;">Enrollment System</h2>
          </div>
          <div style="background: #f8f9fa; padding: 28px; border-radius: 10px;">
            <p style="font-size: 16px; margin: 0 0 12px;">Hi ${studentName},</p>
            <p style="font-size: 14px; line-height: 1.6; margin: 0 0 20px;">
              Use the 6-digit verification code below to confirm your email and continue to your student dashboard:
            </p>
            <div style="text-align: center; margin: 24px 0;">
              <div style="display: inline-block; padding: 18px 32px; background: #2d5aa0; color: #fff; font-size: 34px; letter-spacing: 10px; font-weight: bold; border-radius: 8px;">
                ${otp}
              </div>
            </div>
            <p style="font-size: 13px; color: #555; margin: 0;">
              This code expires in <strong>15 minutes</strong>. If you didn't request this, you can safely ignore this email.
            </p>
          </div>
          <p style="text-align: center; color: #888; font-size: 12px; margin-top: 20px;">
            MNHS Senior High School — Excellence in Education
          </p>
        </div>
      `,
    });

    return json({ success: true, message: "Verification code sent to your email." });
  } catch (error: any) {
    console.error("signup-send-otp error:", error);
    return json({ error: error?.message || "Internal error" }, 500);
  }
});
