import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import bcrypt from "npm:bcryptjs@2.4.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { email, password } = await req.json();
    if (!email || !password) return json({ error: "Email and password are required" }, 400);

    const normalizedEmail = String(email).trim().toLowerCase();
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: pending } = await supabase
      .from("pending_signups")
      .select("*")
      .ilike("email", normalizedEmail)
      .maybeSingle();

    if (!pending) return json({ error: "Account not found" }, 404);

    if (!pending.email_confirmed) {
      return json({ error: "Please verify your email first.", needsVerification: true }, 403);
    }

    const ok = await bcrypt.compare(String(password), pending.password_hash);
    if (!ok) return json({ error: "Incorrect password" }, 401);

    return json({
      success: true,
      account: {
        id: pending.id,
        email: pending.email,
        firstName: pending.first_name,
        lastName: pending.last_name,
        enrollmentStarted: pending.enrollment_started,
      },
    });
  } catch (error: any) {
    console.error("authenticate-pending error:", error);
    return json({ error: error?.message || "Internal error" }, 500);
  }
});
