import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface NotificationRequest {
  email: string;
  studentName: string;
  status: 'approved' | 'denied';
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email, studentName, status }: NotificationRequest = await req.json();

    let subject: string;
    let htmlContent: string;

    if (status === 'approved') {
      subject = "Your Enrollment Form is Approved";
      htmlContent = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background-color: #22c55e; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;">
            <h1 style="margin: 0; font-size: 24px;">Enrollment Approved!</h1>
          </div>
          <div style="background-color: #f9fafb; padding: 30px; border-radius: 0 0 8px 8px;">
            <h2 style="color: #1f2937; margin-top: 0;">Hi ${studentName}!</h2>
            <p style="color: #4b5563; font-size: 16px; line-height: 1.6;">
              Great news! Your enrollment form has been <strong>approved</strong> by Manaoag National High School Senior High School Enrollment System.
            </p>
            <p style="color: #4b5563; font-size: 16px; line-height: 1.6;">
              You can now log in to your student dashboard to download your enrollment form and access other important information.
            </p>
            <div style="margin: 30px 0; padding: 20px; background-color: #dcfce7; border-left: 4px solid #22c55e; border-radius: 4px;">
              <p style="margin: 0; color: #15803d; font-weight: 500;">
                Welcome to Manaoag National High School Senior High School!
              </p>
            </div>
            <p style="color: #6b7280; font-size: 14px; margin-bottom: 0;">
              If you have any questions, please contact the school administration.
            </p>
          </div>
        </div>
      `;
    } else {
      subject = "Your Enrollment Form is Denied";
      htmlContent = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background-color: #ef4444; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;">
            <h1 style="margin: 0; font-size: 24px;">Enrollment Update</h1>
          </div>
          <div style="background-color: #f9fafb; padding: 30px; border-radius: 0 0 8px 8px;">
            <h2 style="color: #1f2937; margin-top: 0;">Hi ${studentName}!</h2>
            <p style="color: #4b5563; font-size: 16px; line-height: 1.6;">
              We regret to inform you that your enrollment form has been <strong>denied</strong> by Manaoag National High School Senior High School Enrollment System.
            </p>
            <p style="color: #4b5563; font-size: 16px; line-height: 1.6;">
              You need to submit a new enrollment form. Please log in to your student dashboard and use the "Submit a New Form" feature to reapply.
            </p>
            <div style="margin: 30px 0; padding: 20px; background-color: #fef3c7; border-left: 4px solid #f59e0b; border-radius: 4px;">
              <p style="margin: 0; color: #92400e; font-weight: 500;">
                Please review your information carefully before resubmitting.
              </p>
            </div>
            <p style="color: #6b7280; font-size: 14px; margin-bottom: 0;">
              If you have any questions about the denial or need assistance, please contact the school administration.
            </p>
          </div>
        </div>
      `;
    }

    const emailResponse = await resend.emails.send({
      from: "MNHS Enrollment <onboarding@resend.dev>",
      to: [email],
      subject: subject,
      html: htmlContent,
    });

    console.log("Enrollment notification sent successfully:", emailResponse);

    return new Response(JSON.stringify(emailResponse), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error in send-enrollment-notification function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);