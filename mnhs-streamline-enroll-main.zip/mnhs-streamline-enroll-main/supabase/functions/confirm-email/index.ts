import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { token } = await req.json();
    if (!token) {
      return new Response(JSON.stringify({ status: "invalid", error: "Missing token" }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL") as string;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") as string;
    const supabase = createClient(supabaseUrl, serviceKey);

    // Check students table
    const { data: student } = await supabase
      .from("students")
      .select("id, email, email_confirmed")
      .eq("confirmation_token", token)
      .maybeSingle();

    if (student) {
      if (student.email_confirmed) {
        return new Response(JSON.stringify({ status: "already_confirmed" }), {
          headers: { "Content-Type": "application/json", ...corsHeaders },
        });
      }

      const { error: updateError } = await supabase
        .from("students")
        .update({ email_confirmed: true, confirmation_token: null })
        .eq("id", student.id);

      if (updateError) {
        console.error("Update error:", updateError);
        return new Response(JSON.stringify({ status: "invalid", error: updateError.message }), {
          status: 500,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        });
      }

      console.log("Email confirmed for student:", student.email);
      return new Response(JSON.stringify({ status: "success" }), {
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    // Check enrollment_applications table
    const { data: appStudent } = await supabase
      .from("enrollment_applications")
      .select("id, email, email_confirmed")
      .eq("confirmation_token", token)
      .maybeSingle();

    if (appStudent) {
      if (appStudent.email_confirmed) {
        return new Response(JSON.stringify({ status: "already_confirmed" }), {
          headers: { "Content-Type": "application/json", ...corsHeaders },
        });
      }

      await supabase
        .from("enrollment_applications")
        .update({ email_confirmed: true, confirmation_token: null })
        .eq("id", appStudent.id);

      return new Response(JSON.stringify({ status: "success" }), {
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    // Token not found - check if student already confirmed (token was cleared)
    return new Response(JSON.stringify({ status: "invalid" }), {
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error("Exception in confirm-email:", error);
    return new Response(JSON.stringify({ status: "invalid", error: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  }
});
