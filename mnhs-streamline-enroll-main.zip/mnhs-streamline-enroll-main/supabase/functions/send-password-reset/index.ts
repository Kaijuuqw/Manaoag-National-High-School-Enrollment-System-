import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface PasswordResetRequest {
  email: string;
  resetUrl: string;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email, resetUrl }: PasswordResetRequest = await req.json();

    console.log("Password reset requested for:", email);

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Find student by email
    const { data: student, error: studentError } = await supabase
      .from("students")
      .select("id, first_name, last_name, email")
      .eq("email", email)
      .single();

    if (studentError || !student) {
      console.log("Student not found with email:", email);
      // Don't reveal if email exists or not for security
      return new Response(
        JSON.stringify({ success: true, message: "If the email exists, a reset link will be sent" }),
        {
          status: 200,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    // Generate reset token
    const resetToken = crypto.randomUUID();
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    // Store reset token
    const { error: updateError } = await supabase
      .from("students")
      .update({
        reset_token: resetToken,
        reset_token_expires_at: expiresAt.toISOString(),
      })
      .eq("id", student.id);

    if (updateError) {
      console.error("Error updating reset token:", updateError);
      throw new Error("Failed to generate reset token");
    }

    const fullResetUrl = `${resetUrl}?token=${resetToken}`;
    const studentName = `${student.first_name} ${student.last_name}`;

    // Send email
    const emailResponse = await resend.emails.send({
      from: "MNHS Enrollment System <onboarding@resend.dev>",
      to: [email],
      subject: "Password Reset Request - MNHS Enrollment System",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Password Reset Request</h2>
          <p>Hi ${studentName},</p>
          <p>If this is you, please click the button below to change your password:</p>
          <div style="margin: 30px 0;">
            <a href="${fullResetUrl}" 
               style="background-color: #4F46E5; color: white; padding: 12px 24px; 
                      text-decoration: none; border-radius: 5px; display: inline-block;">
              Reset Password
            </a>
          </div>
          <p>Or copy and paste this link into your browser:</p>
          <p style="word-break: break-all; color: #666;">${fullResetUrl}</p>
          <p style="margin-top: 30px; color: #666; font-size: 14px;">
            If this wasn't you, please ignore this email. This link will expire in 1 hour.
          </p>
          <hr style="margin: 30px 0; border: none; border-top: 1px solid #ddd;">
          <p style="color: #999; font-size: 12px;">
            Manaoag National High School - Senior High School Enrollment System
          </p>
        </div>
      `,
    });

    console.log("Password reset email sent successfully:", emailResponse);

    return new Response(
      JSON.stringify({ success: true, message: "Password reset email sent" }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  } catch (error: any) {
    console.error("Error in send-password-reset function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
