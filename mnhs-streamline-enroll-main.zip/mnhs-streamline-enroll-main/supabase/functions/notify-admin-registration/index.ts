import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface AdminNotificationRequest {
  studentName: string;
  studentEmail: string;
  strand: string;
  lrn: string;
  registrationDate: string;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const payload: AdminNotificationRequest = await req.json();
    const { studentName, studentEmail, strand, lrn, registrationDate } = payload;
    
    console.log("Notifying admins of new registration:", studentName);

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get all admin emails
    const { data: admins, error: adminError } = await supabase
      .from("admin_users")
      .select("username, full_name");

    if (adminError) {
      console.error("Error fetching admins:", adminError);
      throw new Error("Failed to fetch admin users");
    }

    if (!admins || admins.length === 0) {
      console.log("No admin users found to notify");
      return new Response(
        JSON.stringify({ message: "No admins to notify" }),
        {
          status: 200,
          headers: {
            "Content-Type": "application/json",
            ...corsHeaders,
          },
        }
      );
    }

    // Extract admin emails (assuming username is email)
    const adminEmails = admins
      .map(admin => admin.username)
      .filter(email => email && email.includes('@'));

    if (adminEmails.length === 0) {
      console.log("No valid admin emails found");
      return new Response(
        JSON.stringify({ message: "No valid admin emails" }),
        {
          status: 200,
          headers: {
            "Content-Type": "application/json",
            ...corsHeaders,
          },
        }
      );
    }

    // Format registration date
    const formattedDate = new Date(registrationDate).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });

    // Send notification email to all admins
    const emailPromises = adminEmails.map(adminEmail =>
      resend.emails.send({
        from: "MNHS Registration System <noreply@mnhs-shs.work.gd>",
        to: [adminEmail],
        subject: "New Student Registration - Pending Review",
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="text-align: center; margin-bottom: 30px;">
              <h1 style="color: #1a365d; margin-bottom: 10px;">Manaoag National High School</h1>
              <h2 style="color: #2d5aa0; margin-bottom: 20px;">Senior High School</h2>
              <h3 style="color: #e91e63; margin-top: 20px;">New Student Registration</h3>
            </div>
            
            <div style="background-color: #f8f9fa; padding: 30px; border-radius: 10px; margin-bottom: 30px;">
              <p style="margin-bottom: 20px; line-height: 1.6;">
                A new student has registered for enrollment and requires your review.
              </p>
              
              <div style="background-color: white; padding: 20px; border-radius: 5px; margin: 20px 0;">
                <h3 style="color: #1a365d; margin-bottom: 15px; border-bottom: 2px solid #2d5aa0; padding-bottom: 10px;">
                  Student Information
                </h3>
                <table style="width: 100%; border-collapse: collapse;">
                  <tr>
                    <td style="padding: 8px 0; color: #666; font-weight: bold;">Name:</td>
                    <td style="padding: 8px 0; color: #333;">${studentName}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; color: #666; font-weight: bold;">Email:</td>
                    <td style="padding: 8px 0; color: #333;">${studentEmail}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; color: #666; font-weight: bold;">LRN:</td>
                    <td style="padding: 8px 0; color: #333;">${lrn}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; color: #666; font-weight: bold;">Strand:</td>
                    <td style="padding: 8px 0; color: #333;">${strand}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; color: #666; font-weight: bold;">Registration Date:</td>
                    <td style="padding: 8px 0; color: #333;">${formattedDate}</td>
                  </tr>
                </table>
              </div>
              
              <p style="margin-top: 25px; margin-bottom: 20px; line-height: 1.6;">
                Please log in to the admin dashboard to review this application and update the enrollment status.
              </p>
              
              <div style="text-align: center; margin: 30px 0;">
                <a href="${Deno.env.get("SUPABASE_URL")?.replace('supabase.co', 'lovable.app') || 'https://mnhs-enrollment.lovable.app'}/admin/dashboard" 
                   style="background-color: #2d5aa0; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
                  Go to Admin Dashboard
                </a>
              </div>
            </div>
            
            <div style="border-top: 1px solid #e2e8f0; padding-top: 20px; text-align: center; color: #6b7280; font-size: 14px;">
              <p>This is an automated notification from the MNHS Enrollment System.</p>
              <p style="margin-top: 15px;">
                <strong>Manaoag National High School - Senior High School</strong><br>
                Excellence in Education
              </p>
            </div>
          </div>
        `,
      })
    );

    const results = await Promise.allSettled(emailPromises);
    
    const successCount = results.filter(r => r.status === 'fulfilled').length;
    const failureCount = results.filter(r => r.status === 'rejected').length;

    console.log(`Admin notifications sent: ${successCount} success, ${failureCount} failed`);

    return new Response(
      JSON.stringify({ 
        success: true,
        notified: successCount,
        failed: failureCount 
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders,
        },
      }
    );
  } catch (error: any) {
    console.error("Error in notify-admin-registration function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
