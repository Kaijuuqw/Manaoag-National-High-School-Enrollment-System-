import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface DeleteRequest {
  id: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { id }: DeleteRequest = await req.json();
    if (!id) {
      return new Response(JSON.stringify({ error: 'Missing id' }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL') as string;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') as string;
    const supabase = createClient(supabaseUrl, serviceKey);

    console.log('Deleting student', { id });

    // Fetch student info for cleanup and email notification
    const { data: student, error: fetchError } = await supabase
      .from('students')
      .select('birth_certificate, report_card, certificate_of_completion, email, first_name, last_name')
      .eq('id', id)
      .maybeSingle();

    if (fetchError) {
      console.error('Fetch student before delete error:', fetchError);
    }

    // Attempt to remove storage files if they look like storage paths
    try {
      const filesToRemove: string[] = [];
      const addIfStoragePath = (val?: string | null) => {
        if (val && !val.startsWith('http')) filesToRemove.push(val);
      };
      addIfStoragePath(student?.birth_certificate as string | undefined);
      addIfStoragePath(student?.report_card as string | undefined);
      addIfStoragePath(student?.certificate_of_completion as string | undefined);

      if (filesToRemove.length > 0) {
        const { error: removeErr } = await supabase.storage
          .from('student-documents')
          .remove(filesToRemove);
        if (removeErr) console.error('Storage remove error:', removeErr);
      }
    } catch (storageErr) {
      console.error('Storage cleanup exception:', storageErr);
    }

    const { error } = await supabase
      .from('students')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Delete row error:', error);
      return new Response(JSON.stringify({ error: error.message }), {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    // Send deletion notification email
    if (student?.email) {
      try {
        const { Resend } = await import("npm:resend@2.0.0");
        const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
        const studentName = `${student.first_name} ${student.last_name}`;
        await resend.emails.send({
          from: "MNHS Enrollment <onboarding@resend.dev>",
          to: [student.email],
          subject: "Your Enrollment Data Has Been Deleted",
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
              <div style="background-color: #ef4444; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;">
                <h1 style="margin: 0; font-size: 24px;">Enrollment Data Deleted</h1>
              </div>
              <div style="background-color: #f9fafb; padding: 30px; border-radius: 0 0 8px 8px;">
                <h2 style="color: #1f2937; margin-top: 0;">Hi ${studentName}!</h2>
                <p style="color: #4b5563; font-size: 16px; line-height: 1.6;">
                  Your Enrollment Form, Email, Account, and uploaded documents (Birth Certificate/PSA, Report Card, and Certificate of Completion) have been <strong>deleted</strong> from Manaoag National High School Senior High School Enrollment System.
                </p>
                <p style="color: #6b7280; font-size: 14px;">
                  If you believe this was done in error, please contact the school administration.
                </p>
              </div>
            </div>
          `,
        });
        console.log("Deletion notification sent to:", student.email);
      } catch (emailErr) {
        console.error("Failed to send deletion email:", emailErr);
      }
    }

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error('Exception in admin-delete-student:', error);
    return new Response(JSON.stringify({ error: error.message || 'Unknown error' }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  }
});