import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface ResendConfirmationRequest {
  email: string;
  origin?: string;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email, origin }: ResendConfirmationRequest = await req.json();
    console.log("Resending confirmation email to:", email);

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Check if student exists and is not already confirmed
    const { data: student, error: fetchError } = await supabase
      .from("students")
      .select("id, first_name, last_name, email, email_confirmed")
      .eq("email", email)
      .single();

    if (fetchError || !student) {
      console.error("Student not found:", fetchError);
      return new Response(
        JSON.stringify({ error: "Email address not found in our records" }),
        {
          status: 404,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    if (student.email_confirmed) {
      return new Response(
        JSON.stringify({ error: "Email already confirmed. You can log in now." }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    // Generate new confirmation token
    const confirmationToken = crypto.randomUUID();
    
    // Update student with new token
    const { error: updateError } = await supabase
      .from("students")
      .update({
        confirmation_token: confirmationToken,
        confirmation_sent_at: new Date().toISOString(),
      })
      .eq("id", student.id);

    if (updateError) {
      console.error("Error updating confirmation token:", updateError);
      throw new Error("Failed to update confirmation token");
    }

    const baseUrl = origin || "http://localhost:5173";
    const confirmationUrl = `${baseUrl}/confirm-registration?token=${confirmationToken}`;

    // Send confirmation email
    const emailResponse = await resend.emails.send({
      from: "MNHS Registration <noreply@mnhs-shs.work.gd>",
      to: [email],
      subject: "Confirm Your MNHS Enrollment Registration",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #1a365d; margin-bottom: 10px;">Manaoag National High School</h1>
            <h2 style="color: #2d5aa0; margin-bottom: 20px;">Senior High School</h2>
          </div>
          
          <div style="background-color: #f8f9fa; padding: 30px; border-radius: 10px; margin-bottom: 30px;">
            <h2 style="color: #1a365d; margin-bottom: 20px;">Dear ${student.first_name} ${student.last_name},</h2>
            
            <p style="margin-bottom: 20px; line-height: 1.6;">
              We're resending your confirmation email. Please confirm your email address by clicking the button below:
            </p>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="${confirmationUrl}" 
                 style="background-color: #2d5aa0; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
                Confirm Registration
              </a>
            </div>
            
            <p style="margin-bottom: 20px; line-height: 1.6;">
              Once confirmed, you will be able to log in to your student dashboard.
            </p>
            
            <p style="margin-bottom: 20px; line-height: 1.6;">
              If you cannot click the button above, copy and paste this link into your browser:
            </p>
            <p style="word-break: break-all; margin-bottom: 20px; color: #2d5aa0;">
              ${confirmationUrl}
            </p>
          </div>
          
          <div style="border-top: 1px solid #e2e8f0; padding-top: 20px; text-align: center; color: #6b7280; font-size: 14px;">
            <p>If you didn't request this email, you can safely ignore it.</p>
            <p style="margin-top: 15px;">
              <strong>Manaoag National High School - Senior High School</strong><br>
              Excellence in Education
            </p>
          </div>
        </div>
      `,
    });

    console.log("Confirmation email resent successfully:", emailResponse);

    return new Response(
      JSON.stringify({ 
        success: true,
        message: "Confirmation email has been resent. Please check your inbox." 
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders,
        },
      }
    );
  } catch (error: any) {
    console.error("Error in resend-confirmation function:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Failed to resend confirmation email" }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
