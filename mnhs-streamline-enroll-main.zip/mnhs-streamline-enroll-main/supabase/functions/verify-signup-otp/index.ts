import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import bcrypt from "npm:bcryptjs@2.4.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });

const MAX_ATTEMPTS = 5;

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { email, code } = await req.json();
    if (!email || !code || !/^\d{6}$/.test(String(code))) {
      return json({ error: "Invalid email or code format" }, 400);
    }

    const normalizedEmail = String(email).trim().toLowerCase();
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: pending, error: fetchError } = await supabase
      .from("pending_signups")
      .select("*")
      .ilike("email", normalizedEmail)
      .maybeSingle();

    if (fetchError || !pending) {
      return json({ error: "No pending signup found for this email." }, 404);
    }

    if (pending.email_confirmed) {
      return json({
        success: true,
        alreadyConfirmed: true,
        account: {
          id: pending.id,
          email: pending.email,
          firstName: pending.first_name,
          lastName: pending.last_name,
        },
      });
    }

    if (pending.attempts >= MAX_ATTEMPTS) {
      return json({ error: "Too many attempts. Please request a new code." }, 429);
    }

    if (!pending.otp_hash || !pending.otp_expires_at || new Date(pending.otp_expires_at) < new Date()) {
      return json({ error: "Verification code has expired. Please request a new one." }, 410);
    }

    const valid = await bcrypt.compare(String(code), pending.otp_hash);
    if (!valid) {
      await supabase
        .from("pending_signups")
        .update({ attempts: (pending.attempts ?? 0) + 1 })
        .eq("id", pending.id);
      return json({ error: "Incorrect verification code." }, 400);
    }

    // Mark confirmed and clear OTP
    const { error: updateError } = await supabase
      .from("pending_signups")
      .update({
        email_confirmed: true,
        otp_hash: null,
        otp_expires_at: null,
        attempts: 0,
      })
      .eq("id", pending.id);

    if (updateError) {
      console.error("Update error:", updateError);
      return json({ error: "Failed to confirm email." }, 500);
    }

    return json({
      success: true,
      account: {
        id: pending.id,
        email: pending.email,
        firstName: pending.first_name,
        lastName: pending.last_name,
      },
    });
  } catch (error: any) {
    console.error("verify-signup-otp error:", error);
    return json({ error: error?.message || "Internal error" }, 500);
  }
});
