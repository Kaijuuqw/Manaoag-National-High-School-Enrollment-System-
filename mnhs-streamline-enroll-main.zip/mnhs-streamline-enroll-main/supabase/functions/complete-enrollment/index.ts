import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { pendingId, studentRow } = await req.json();
    if (!pendingId || !studentRow || typeof studentRow !== "object") {
      return json({ error: "Missing pendingId or studentRow" }, 400);
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Look up the pending signup
    const { data: pending, error: pendingError } = await supabase
      .from("pending_signups")
      .select("*")
      .eq("id", pendingId)
      .maybeSingle();

    if (pendingError || !pending) {
      return json({ error: "Pending signup not found." }, 404);
    }
    if (!pending.email_confirmed) {
      return json({ error: "Email is not verified. Please verify first." }, 403);
    }

    // Insert student using pending account's email + password hash
    const insertPayload = {
      ...studentRow,
      email: pending.email,
      password: pending.password_hash, // bcrypt hash — login compares with bcrypt
      email_confirmed: true,
      confirmation_token: null,
      enrollment_status: "Pending",
      enrollment_date: new Date().toISOString(),
    };

    const { data: inserted, error: insertError } = await supabase
      .from("students")
      .insert(insertPayload)
      .select("id")
      .single();

    if (insertError) {
      console.error("Insert student error:", insertError);
      return json(
        { error: insertError.message, details: insertError.details, hint: insertError.hint },
        400
      );
    }

    // Clean up pending row
    await supabase.from("pending_signups").delete().eq("id", pendingId);

    return json({ success: true, studentId: inserted.id });
  } catch (error: any) {
    console.error("complete-enrollment error:", error);
    return json({ error: error?.message || "Internal error" }, 500);
  }
});
