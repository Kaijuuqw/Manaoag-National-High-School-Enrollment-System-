import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface ConfirmationEmailRequest {
  email: string;
  studentName: string;
  confirmationToken: string;
  origin?: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const payload: ConfirmationEmailRequest = await req.json();
    const { email, studentName, confirmationToken, origin } = payload;
    console.log("Sending confirmation email to:", email);

    const baseUrl = origin || req.headers.get('origin') || 'http://localhost:5173';
    const confirmationUrl = `${baseUrl}/confirm-registration?token=${confirmationToken}`;

    const emailResponse = await resend.emails.send({
      from: "MNHS Registration <noreply@mnhs-shs.work.gd>",
      to: [email],
      subject: "Confirm Your MNHS Enrollment Registration",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #1a365d; margin-bottom: 10px;">Manaoag National High School</h1>
            <h2 style="color: #2d5aa0; margin-bottom: 20px;">Senior High School</h2>
          </div>
          
          <div style="background-color: #f8f9fa; padding: 30px; border-radius: 10px; margin-bottom: 30px;">
            <h2 style="color: #1a365d; margin-bottom: 20px;">Dear ${studentName},</h2>
            
            <p style="margin-bottom: 20px; line-height: 1.6;">
              Thank you for submitting your enrollment application to Manaoag National High School - Senior High School.
            </p>
            
            <p style="margin-bottom: 25px; line-height: 1.6;">
              To complete your registration, please confirm your email address by clicking the button below:
            </p>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="${confirmationUrl}" 
                 style="background-color: #2d5aa0; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
                Confirm Registration
              </a>
            </div>
            
            <p style="margin-bottom: 20px; line-height: 1.6;">
              Once confirmed, you will be able to log in to your student dashboard and check your enrollment status.
            </p>
            
            <p style="margin-bottom: 20px; line-height: 1.6;">
              If you cannot click the button above, copy and paste this link into your browser:
            </p>
            <p style="word-break: break-all; margin-bottom: 20px; color: #2d5aa0;">
              ${confirmationUrl}
            </p>
          </div>
          
          <div style="border-top: 1px solid #e2e8f0; padding-top: 20px; text-align: center; color: #6b7280; font-size: 14px;">
            <p>If you didn't create this account, you can safely ignore this email.</p>
            <p style="margin-top: 15px;">
              <strong>Manaoag National High School - Senior High School</strong><br>
              Excellence in Education
            </p>
          </div>
        </div>
      `,
    });

    console.log("Email sent successfully:", emailResponse);

    return new Response(JSON.stringify(emailResponse), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error in send-confirmation-email function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);